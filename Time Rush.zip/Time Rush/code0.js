gdjs.Main_32menuCode = {};
gdjs.Main_32menuCode.GDCursorObjects1= [];
gdjs.Main_32menuCode.GDCursorObjects2= [];
gdjs.Main_32menuCode.GDCursorObjects3= [];
gdjs.Main_32menuCode.GDBackgroundObjects1= [];
gdjs.Main_32menuCode.GDBackgroundObjects2= [];
gdjs.Main_32menuCode.GDBackgroundObjects3= [];
gdjs.Main_32menuCode.GDFanObjects1= [];
gdjs.Main_32menuCode.GDFanObjects2= [];
gdjs.Main_32menuCode.GDFanObjects3= [];
gdjs.Main_32menuCode.GDDecorationObjects1= [];
gdjs.Main_32menuCode.GDDecorationObjects2= [];
gdjs.Main_32menuCode.GDDecorationObjects3= [];
gdjs.Main_32menuCode.GDDecoration2Objects1= [];
gdjs.Main_32menuCode.GDDecoration2Objects2= [];
gdjs.Main_32menuCode.GDDecoration2Objects3= [];
gdjs.Main_32menuCode.GDDecoration1Objects1= [];
gdjs.Main_32menuCode.GDDecoration1Objects2= [];
gdjs.Main_32menuCode.GDDecoration1Objects3= [];
gdjs.Main_32menuCode.GDDecoration3Objects1= [];
gdjs.Main_32menuCode.GDDecoration3Objects2= [];
gdjs.Main_32menuCode.GDDecoration3Objects3= [];
gdjs.Main_32menuCode.GDDecoration4Objects1= [];
gdjs.Main_32menuCode.GDDecoration4Objects2= [];
gdjs.Main_32menuCode.GDDecoration4Objects3= [];
gdjs.Main_32menuCode.GDDecoration5Objects1= [];
gdjs.Main_32menuCode.GDDecoration5Objects2= [];
gdjs.Main_32menuCode.GDDecoration5Objects3= [];
gdjs.Main_32menuCode.GDDecoration6Objects1= [];
gdjs.Main_32menuCode.GDDecoration6Objects2= [];
gdjs.Main_32menuCode.GDDecoration6Objects3= [];
gdjs.Main_32menuCode.GDDecoration7Objects1= [];
gdjs.Main_32menuCode.GDDecoration7Objects2= [];
gdjs.Main_32menuCode.GDDecoration7Objects3= [];
gdjs.Main_32menuCode.GDDecoration8Objects1= [];
gdjs.Main_32menuCode.GDDecoration8Objects2= [];
gdjs.Main_32menuCode.GDDecoration8Objects3= [];
gdjs.Main_32menuCode.GDDecoration9Objects1= [];
gdjs.Main_32menuCode.GDDecoration9Objects2= [];
gdjs.Main_32menuCode.GDDecoration9Objects3= [];
gdjs.Main_32menuCode.GDDecoration10Objects1= [];
gdjs.Main_32menuCode.GDDecoration10Objects2= [];
gdjs.Main_32menuCode.GDDecoration10Objects3= [];
gdjs.Main_32menuCode.GDDecoration11Objects1= [];
gdjs.Main_32menuCode.GDDecoration11Objects2= [];
gdjs.Main_32menuCode.GDDecoration11Objects3= [];
gdjs.Main_32menuCode.GDDecoration12Objects1= [];
gdjs.Main_32menuCode.GDDecoration12Objects2= [];
gdjs.Main_32menuCode.GDDecoration12Objects3= [];
gdjs.Main_32menuCode.GDDecoration13Objects1= [];
gdjs.Main_32menuCode.GDDecoration13Objects2= [];
gdjs.Main_32menuCode.GDDecoration13Objects3= [];
gdjs.Main_32menuCode.GDDecoration14Objects1= [];
gdjs.Main_32menuCode.GDDecoration14Objects2= [];
gdjs.Main_32menuCode.GDDecoration14Objects3= [];
gdjs.Main_32menuCode.GDDecoration15Objects1= [];
gdjs.Main_32menuCode.GDDecoration15Objects2= [];
gdjs.Main_32menuCode.GDDecoration15Objects3= [];
gdjs.Main_32menuCode.GDDecoration16Objects1= [];
gdjs.Main_32menuCode.GDDecoration16Objects2= [];
gdjs.Main_32menuCode.GDDecoration16Objects3= [];
gdjs.Main_32menuCode.GDDecoration17Objects1= [];
gdjs.Main_32menuCode.GDDecoration17Objects2= [];
gdjs.Main_32menuCode.GDDecoration17Objects3= [];
gdjs.Main_32menuCode.GDDecoration18Objects1= [];
gdjs.Main_32menuCode.GDDecoration18Objects2= [];
gdjs.Main_32menuCode.GDDecoration18Objects3= [];
gdjs.Main_32menuCode.GDDecoration19Objects1= [];
gdjs.Main_32menuCode.GDDecoration19Objects2= [];
gdjs.Main_32menuCode.GDDecoration19Objects3= [];
gdjs.Main_32menuCode.GDDecoration20Objects1= [];
gdjs.Main_32menuCode.GDDecoration20Objects2= [];
gdjs.Main_32menuCode.GDDecoration20Objects3= [];
gdjs.Main_32menuCode.GDDecoration22Objects1= [];
gdjs.Main_32menuCode.GDDecoration22Objects2= [];
gdjs.Main_32menuCode.GDDecoration22Objects3= [];
gdjs.Main_32menuCode.GDDecoration24Objects1= [];
gdjs.Main_32menuCode.GDDecoration24Objects2= [];
gdjs.Main_32menuCode.GDDecoration24Objects3= [];
gdjs.Main_32menuCode.GDDecoration25Objects1= [];
gdjs.Main_32menuCode.GDDecoration25Objects2= [];
gdjs.Main_32menuCode.GDDecoration25Objects3= [];
gdjs.Main_32menuCode.GDDecoration28Objects1= [];
gdjs.Main_32menuCode.GDDecoration28Objects2= [];
gdjs.Main_32menuCode.GDDecoration28Objects3= [];
gdjs.Main_32menuCode.GDSpikeObjects1= [];
gdjs.Main_32menuCode.GDSpikeObjects2= [];
gdjs.Main_32menuCode.GDSpikeObjects3= [];
gdjs.Main_32menuCode.GDSpike2Objects1= [];
gdjs.Main_32menuCode.GDSpike2Objects2= [];
gdjs.Main_32menuCode.GDSpike2Objects3= [];
gdjs.Main_32menuCode.GDSpike3Objects1= [];
gdjs.Main_32menuCode.GDSpike3Objects2= [];
gdjs.Main_32menuCode.GDSpike3Objects3= [];
gdjs.Main_32menuCode.GDSpike4Objects1= [];
gdjs.Main_32menuCode.GDSpike4Objects2= [];
gdjs.Main_32menuCode.GDSpike4Objects3= [];
gdjs.Main_32menuCode.GDTV_95TUBEObjects1= [];
gdjs.Main_32menuCode.GDTV_95TUBEObjects2= [];
gdjs.Main_32menuCode.GDTV_95TUBEObjects3= [];
gdjs.Main_32menuCode.GDPortalObjects1= [];
gdjs.Main_32menuCode.GDPortalObjects2= [];
gdjs.Main_32menuCode.GDPortalObjects3= [];
gdjs.Main_32menuCode.GDPlayerObjects1= [];
gdjs.Main_32menuCode.GDPlayerObjects2= [];
gdjs.Main_32menuCode.GDPlayerObjects3= [];
gdjs.Main_32menuCode.GDDustObjects1= [];
gdjs.Main_32menuCode.GDDustObjects2= [];
gdjs.Main_32menuCode.GDDustObjects3= [];
gdjs.Main_32menuCode.GDBullet_95EffectObjects1= [];
gdjs.Main_32menuCode.GDBullet_95EffectObjects2= [];
gdjs.Main_32menuCode.GDBullet_95EffectObjects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITIONObjects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITIONObjects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITIONObjects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION2Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION2Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION2Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION3Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION3Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION3Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION4Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION4Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION4Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION5Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION5Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION5Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION6Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION6Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION6Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION7Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION7Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION7Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION8Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION8Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION8Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION9Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION9Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION9Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION10Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION10Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION10Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION11Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION11Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION11Objects3= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION12Objects1= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION12Objects2= [];
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION12Objects3= [];
gdjs.Main_32menuCode.GDterminalObjects1= [];
gdjs.Main_32menuCode.GDterminalObjects2= [];
gdjs.Main_32menuCode.GDterminalObjects3= [];
gdjs.Main_32menuCode.GDterminal5Objects1= [];
gdjs.Main_32menuCode.GDterminal5Objects2= [];
gdjs.Main_32menuCode.GDterminal5Objects3= [];
gdjs.Main_32menuCode.GDterminal3Objects1= [];
gdjs.Main_32menuCode.GDterminal3Objects2= [];
gdjs.Main_32menuCode.GDterminal3Objects3= [];
gdjs.Main_32menuCode.GDterminal4Objects1= [];
gdjs.Main_32menuCode.GDterminal4Objects2= [];
gdjs.Main_32menuCode.GDterminal4Objects3= [];
gdjs.Main_32menuCode.GDGame_95OverObjects1= [];
gdjs.Main_32menuCode.GDGame_95OverObjects2= [];
gdjs.Main_32menuCode.GDGame_95OverObjects3= [];
gdjs.Main_32menuCode.GDPlatformObjects1= [];
gdjs.Main_32menuCode.GDPlatformObjects2= [];
gdjs.Main_32menuCode.GDPlatformObjects3= [];
gdjs.Main_32menuCode.GDPlatform_95BossObjects1= [];
gdjs.Main_32menuCode.GDPlatform_95BossObjects2= [];
gdjs.Main_32menuCode.GDPlatform_95BossObjects3= [];
gdjs.Main_32menuCode.GDPlatform_95DoorObjects1= [];
gdjs.Main_32menuCode.GDPlatform_95DoorObjects2= [];
gdjs.Main_32menuCode.GDPlatform_95DoorObjects3= [];
gdjs.Main_32menuCode.GDPlatform_95Door2Objects1= [];
gdjs.Main_32menuCode.GDPlatform_95Door2Objects2= [];
gdjs.Main_32menuCode.GDPlatform_95Door2Objects3= [];
gdjs.Main_32menuCode.GDPlatform_95that_95get_95destroyedObjects1= [];
gdjs.Main_32menuCode.GDPlatform_95that_95get_95destroyedObjects2= [];
gdjs.Main_32menuCode.GDPlatform_95that_95get_95destroyedObjects3= [];
gdjs.Main_32menuCode.GDPlatform_95JumpThroughObjects1= [];
gdjs.Main_32menuCode.GDPlatform_95JumpThroughObjects2= [];
gdjs.Main_32menuCode.GDPlatform_95JumpThroughObjects3= [];
gdjs.Main_32menuCode.GDPlatform_95MovingObjects1= [];
gdjs.Main_32menuCode.GDPlatform_95MovingObjects2= [];
gdjs.Main_32menuCode.GDPlatform_95MovingObjects3= [];
gdjs.Main_32menuCode.GDPlatform_95edgesObjects1= [];
gdjs.Main_32menuCode.GDPlatform_95edgesObjects2= [];
gdjs.Main_32menuCode.GDPlatform_95edgesObjects3= [];
gdjs.Main_32menuCode.GDGame_95Over_95BGObjects1= [];
gdjs.Main_32menuCode.GDGame_95Over_95BGObjects2= [];
gdjs.Main_32menuCode.GDGame_95Over_95BGObjects3= [];
gdjs.Main_32menuCode.GDDeathObjects1= [];
gdjs.Main_32menuCode.GDDeathObjects2= [];
gdjs.Main_32menuCode.GDDeathObjects3= [];
gdjs.Main_32menuCode.GDText_95Game_95OverObjects1= [];
gdjs.Main_32menuCode.GDText_95Game_95OverObjects2= [];
gdjs.Main_32menuCode.GDText_95Game_95OverObjects3= [];
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95againObjects1= [];
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95againObjects2= [];
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95againObjects3= [];
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95again2Objects1= [];
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95again2Objects2= [];
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95again2Objects3= [];
gdjs.Main_32menuCode.GDTimerObjects1= [];
gdjs.Main_32menuCode.GDTimerObjects2= [];
gdjs.Main_32menuCode.GDTimerObjects3= [];
gdjs.Main_32menuCode.GDShield_95CountObjects1= [];
gdjs.Main_32menuCode.GDShield_95CountObjects2= [];
gdjs.Main_32menuCode.GDShield_95CountObjects3= [];
gdjs.Main_32menuCode.GDShield_95CapsuleObjects1= [];
gdjs.Main_32menuCode.GDShield_95CapsuleObjects2= [];
gdjs.Main_32menuCode.GDShield_95CapsuleObjects3= [];
gdjs.Main_32menuCode.GDTime_95CapsuleObjects1= [];
gdjs.Main_32menuCode.GDTime_95CapsuleObjects2= [];
gdjs.Main_32menuCode.GDTime_95CapsuleObjects3= [];
gdjs.Main_32menuCode.GDLeftObjects1= [];
gdjs.Main_32menuCode.GDLeftObjects2= [];
gdjs.Main_32menuCode.GDLeftObjects3= [];
gdjs.Main_32menuCode.GDRightObjects1= [];
gdjs.Main_32menuCode.GDRightObjects2= [];
gdjs.Main_32menuCode.GDRightObjects3= [];
gdjs.Main_32menuCode.GDLeft_95ControlObjects1= [];
gdjs.Main_32menuCode.GDLeft_95ControlObjects2= [];
gdjs.Main_32menuCode.GDLeft_95ControlObjects3= [];
gdjs.Main_32menuCode.GDRight_95ControlObjects1= [];
gdjs.Main_32menuCode.GDRight_95ControlObjects2= [];
gdjs.Main_32menuCode.GDRight_95ControlObjects3= [];
gdjs.Main_32menuCode.GDBullet_95EnemyObjects1= [];
gdjs.Main_32menuCode.GDBullet_95EnemyObjects2= [];
gdjs.Main_32menuCode.GDBullet_95EnemyObjects3= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_952Objects1= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_952Objects2= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_952Objects3= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_953Objects1= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_953Objects2= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_953Objects3= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_951Objects1= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_951Objects2= [];
gdjs.Main_32menuCode.GDBullet_95Enemy_951Objects3= [];
gdjs.Main_32menuCode.GDBulletObjects1= [];
gdjs.Main_32menuCode.GDBulletObjects2= [];
gdjs.Main_32menuCode.GDBulletObjects3= [];
gdjs.Main_32menuCode.GDHealth_95barObjects1= [];
gdjs.Main_32menuCode.GDHealth_95barObjects2= [];
gdjs.Main_32menuCode.GDHealth_95barObjects3= [];
gdjs.Main_32menuCode.GDG_95ControlObjects1= [];
gdjs.Main_32menuCode.GDG_95ControlObjects2= [];
gdjs.Main_32menuCode.GDG_95ControlObjects3= [];
gdjs.Main_32menuCode.GDF_95ControlObjects1= [];
gdjs.Main_32menuCode.GDF_95ControlObjects2= [];
gdjs.Main_32menuCode.GDF_95ControlObjects3= [];
gdjs.Main_32menuCode.GDDown_95ControlObjects1= [];
gdjs.Main_32menuCode.GDDown_95ControlObjects2= [];
gdjs.Main_32menuCode.GDDown_95ControlObjects3= [];
gdjs.Main_32menuCode.GDSpace_95ControlObjects1= [];
gdjs.Main_32menuCode.GDSpace_95ControlObjects2= [];
gdjs.Main_32menuCode.GDSpace_95ControlObjects3= [];
gdjs.Main_32menuCode.GDShield_95SkillObjects1= [];
gdjs.Main_32menuCode.GDShield_95SkillObjects2= [];
gdjs.Main_32menuCode.GDShield_95SkillObjects3= [];
gdjs.Main_32menuCode.GDMove_95To_95BlockObjects1= [];
gdjs.Main_32menuCode.GDMove_95To_95BlockObjects2= [];
gdjs.Main_32menuCode.GDMove_95To_95BlockObjects3= [];
gdjs.Main_32menuCode.GDMove_95To_95Block2Objects1= [];
gdjs.Main_32menuCode.GDMove_95To_95Block2Objects2= [];
gdjs.Main_32menuCode.GDMove_95To_95Block2Objects3= [];
gdjs.Main_32menuCode.GDMove_95To_95Block3Objects1= [];
gdjs.Main_32menuCode.GDMove_95To_95Block3Objects2= [];
gdjs.Main_32menuCode.GDMove_95To_95Block3Objects3= [];
gdjs.Main_32menuCode.GDMove_95To_95Block4Objects1= [];
gdjs.Main_32menuCode.GDMove_95To_95Block4Objects2= [];
gdjs.Main_32menuCode.GDMove_95To_95Block4Objects3= [];
gdjs.Main_32menuCode.GDMove_95To_95Block5Objects1= [];
gdjs.Main_32menuCode.GDMove_95To_95Block5Objects2= [];
gdjs.Main_32menuCode.GDMove_95To_95Block5Objects3= [];
gdjs.Main_32menuCode.GDMove_95To_95Block6Objects1= [];
gdjs.Main_32menuCode.GDMove_95To_95Block6Objects2= [];
gdjs.Main_32menuCode.GDMove_95To_95Block6Objects3= [];
gdjs.Main_32menuCode.GDMove_95To_95Block7Objects1= [];
gdjs.Main_32menuCode.GDMove_95To_95Block7Objects2= [];
gdjs.Main_32menuCode.GDMove_95To_95Block7Objects3= [];
gdjs.Main_32menuCode.GDVirus_952Objects1= [];
gdjs.Main_32menuCode.GDVirus_952Objects2= [];
gdjs.Main_32menuCode.GDVirus_952Objects3= [];
gdjs.Main_32menuCode.GDVirus_952_95WallObjects1= [];
gdjs.Main_32menuCode.GDVirus_952_95WallObjects2= [];
gdjs.Main_32menuCode.GDVirus_952_95WallObjects3= [];
gdjs.Main_32menuCode.GDVirus_952_95FlippedObjects1= [];
gdjs.Main_32menuCode.GDVirus_952_95FlippedObjects2= [];
gdjs.Main_32menuCode.GDVirus_952_95FlippedObjects3= [];
gdjs.Main_32menuCode.GDShoot_95FromObjects1= [];
gdjs.Main_32menuCode.GDShoot_95FromObjects2= [];
gdjs.Main_32menuCode.GDShoot_95FromObjects3= [];
gdjs.Main_32menuCode.GDShoot_95From2Objects1= [];
gdjs.Main_32menuCode.GDShoot_95From2Objects2= [];
gdjs.Main_32menuCode.GDShoot_95From2Objects3= [];
gdjs.Main_32menuCode.GDShoot_95From3Objects1= [];
gdjs.Main_32menuCode.GDShoot_95From3Objects2= [];
gdjs.Main_32menuCode.GDShoot_95From3Objects3= [];
gdjs.Main_32menuCode.GDFalling_95WallObjects1= [];
gdjs.Main_32menuCode.GDFalling_95WallObjects2= [];
gdjs.Main_32menuCode.GDFalling_95WallObjects3= [];
gdjs.Main_32menuCode.GDFalling_95Wall_95ChainObjects1= [];
gdjs.Main_32menuCode.GDFalling_95Wall_95ChainObjects2= [];
gdjs.Main_32menuCode.GDFalling_95Wall_95ChainObjects3= [];
gdjs.Main_32menuCode.GDBossObjects1= [];
gdjs.Main_32menuCode.GDBossObjects2= [];
gdjs.Main_32menuCode.GDBossObjects3= [];
gdjs.Main_32menuCode.GDTutorial_95BossObjects1= [];
gdjs.Main_32menuCode.GDTutorial_95BossObjects2= [];
gdjs.Main_32menuCode.GDTutorial_95BossObjects3= [];
gdjs.Main_32menuCode.GDMM_95BGObjects1= [];
gdjs.Main_32menuCode.GDMM_95BGObjects2= [];
gdjs.Main_32menuCode.GDMM_95BGObjects3= [];
gdjs.Main_32menuCode.GDStartObjects1= [];
gdjs.Main_32menuCode.GDStartObjects2= [];
gdjs.Main_32menuCode.GDStartObjects3= [];
gdjs.Main_32menuCode.GDOptionsObjects1= [];
gdjs.Main_32menuCode.GDOptionsObjects2= [];
gdjs.Main_32menuCode.GDOptionsObjects3= [];
gdjs.Main_32menuCode.GDAboutObjects1= [];
gdjs.Main_32menuCode.GDAboutObjects2= [];
gdjs.Main_32menuCode.GDAboutObjects3= [];
gdjs.Main_32menuCode.GDExitObjects1= [];
gdjs.Main_32menuCode.GDExitObjects2= [];
gdjs.Main_32menuCode.GDExitObjects3= [];
gdjs.Main_32menuCode.GDBackObjects1= [];
gdjs.Main_32menuCode.GDBackObjects2= [];
gdjs.Main_32menuCode.GDBackObjects3= [];
gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects1= [];
gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects2= [];
gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects3= [];
gdjs.Main_32menuCode.GDYesObjects1= [];
gdjs.Main_32menuCode.GDYesObjects2= [];
gdjs.Main_32menuCode.GDYesObjects3= [];
gdjs.Main_32menuCode.GDNoObjects1= [];
gdjs.Main_32menuCode.GDNoObjects2= [];
gdjs.Main_32menuCode.GDNoObjects3= [];
gdjs.Main_32menuCode.GDBuilding_95BlocksObjects1= [];
gdjs.Main_32menuCode.GDBuilding_95BlocksObjects2= [];
gdjs.Main_32menuCode.GDBuilding_95BlocksObjects3= [];
gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects1= [];
gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects2= [];
gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects3= [];
gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1= [];
gdjs.Main_32menuCode.GDCharacter_95SelectorObjects2= [];
gdjs.Main_32menuCode.GDCharacter_95SelectorObjects3= [];
gdjs.Main_32menuCode.GDMusic_95ONObjects1= [];
gdjs.Main_32menuCode.GDMusic_95ONObjects2= [];
gdjs.Main_32menuCode.GDMusic_95ONObjects3= [];
gdjs.Main_32menuCode.GDMusic_95OFFObjects1= [];
gdjs.Main_32menuCode.GDMusic_95OFFObjects2= [];
gdjs.Main_32menuCode.GDMusic_95OFFObjects3= [];


gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDStartObjects1Objects = Hashtable.newFrom({"Start": gdjs.Main_32menuCode.GDStartObjects1});
gdjs.Main_32menuCode.asyncCallback16191572 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial level", false);
}}
gdjs.Main_32menuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16191572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDOptionsObjects1Objects = Hashtable.newFrom({"Options": gdjs.Main_32menuCode.GDOptionsObjects1});
gdjs.Main_32menuCode.asyncCallback16194588 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32menuCode.GDBackObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Selector"), gdjs.Main_32menuCode.GDCharacter_95SelectorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Main_32menuCode.GDLeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("Music_OFF"), gdjs.Main_32menuCode.GDMusic_95OFFObjects3);
gdjs.copyArray(runtimeScene.getObjects("Music_ON"), gdjs.Main_32menuCode.GDMusic_95ONObjects3);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Main_32menuCode.GDRightObjects3);
{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDLeftObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDLeftObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDRightObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDRightObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95ONObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95ONObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95OFFObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95OFFObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDBackObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackObjects3[i].hide(false);
}
}}
gdjs.Main_32menuCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16194588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.asyncCallback16191324 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32menuCode.GDAboutObjects2);
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32menuCode.GDExitObjects2);
gdjs.copyArray(runtimeScene.getObjects("MM_BG"), gdjs.Main_32menuCode.GDMM_95BGObjects2);
gdjs.copyArray(asyncObjectsList.getObjects("Options"), gdjs.Main_32menuCode.GDOptionsObjects2);

gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32menuCode.GDStartObjects2);
{for(var i = 0, len = gdjs.Main_32menuCode.GDMM_95BGObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMM_95BGObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDStartObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDStartObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDOptionsObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDOptionsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDAboutObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAboutObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDExitObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDExitObjects2[i].hide();
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Main_32menuCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Main_32menuCode.GDOptionsObjects1) asyncObjectsList.addObject("Options", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16191324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDAboutObjects1Objects = Hashtable.newFrom({"About": gdjs.Main_32menuCode.GDAboutObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.Main_32menuCode.GDExitObjects1});
gdjs.Main_32menuCode.asyncCallback16199932 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Are_you_sure_about_that"), gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects3);
gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Main_32menuCode.GDNoObjects3);
gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Main_32menuCode.GDYesObjects3);
{for(var i = 0, len = gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDYesObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDYesObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDNoObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDNoObjects3[i].hide(false);
}
}}
gdjs.Main_32menuCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16199932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.asyncCallback16199412 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32menuCode.GDAboutObjects2);
gdjs.copyArray(asyncObjectsList.getObjects("Exit"), gdjs.Main_32menuCode.GDExitObjects2);

gdjs.copyArray(runtimeScene.getObjects("MM_BG"), gdjs.Main_32menuCode.GDMM_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Options"), gdjs.Main_32menuCode.GDOptionsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32menuCode.GDStartObjects2);
{for(var i = 0, len = gdjs.Main_32menuCode.GDMM_95BGObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMM_95BGObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDStartObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDStartObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDOptionsObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDOptionsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDAboutObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAboutObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDExitObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDExitObjects2[i].hide();
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Main_32menuCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Main_32menuCode.GDExitObjects1) asyncObjectsList.addObject("Exit", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16199412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDYesObjects1Objects = Hashtable.newFrom({"Yes": gdjs.Main_32menuCode.GDYesObjects1});
gdjs.Main_32menuCode.asyncCallback16202516 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}
gdjs.Main_32menuCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16202516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs.Main_32menuCode.GDBackObjects1});
gdjs.Main_32menuCode.asyncCallback16204020 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32menuCode.GDAboutObjects3);
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32menuCode.GDExitObjects3);
gdjs.copyArray(runtimeScene.getObjects("MM_BG"), gdjs.Main_32menuCode.GDMM_95BGObjects3);
gdjs.copyArray(runtimeScene.getObjects("Options"), gdjs.Main_32menuCode.GDOptionsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32menuCode.GDStartObjects3);
{for(var i = 0, len = gdjs.Main_32menuCode.GDMM_95BGObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMM_95BGObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDStartObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDStartObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDAboutObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAboutObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDOptionsObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDOptionsObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDExitObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDExitObjects3[i].hide(false);
}
}}
gdjs.Main_32menuCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16204020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.asyncCallback16204604 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Back"), gdjs.Main_32menuCode.GDBackObjects2);

gdjs.copyArray(runtimeScene.getObjects("Character_Selector"), gdjs.Main_32menuCode.GDCharacter_95SelectorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Main_32menuCode.GDLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Music_OFF"), gdjs.Main_32menuCode.GDMusic_95OFFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Music_ON"), gdjs.Main_32menuCode.GDMusic_95ONObjects2);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Main_32menuCode.GDRightObjects2);
{for(var i = 0, len = gdjs.Main_32menuCode.GDBackObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95ONObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95ONObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDLeftObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDRightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95OFFObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95OFFObjects2[i].hide();
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Main_32menuCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Main_32menuCode.GDBackObjects1) asyncObjectsList.addObject("Back", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16204604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDNoObjects1Objects = Hashtable.newFrom({"No": gdjs.Main_32menuCode.GDNoObjects1});
gdjs.Main_32menuCode.asyncCallback16208420 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32menuCode.GDAboutObjects3);
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32menuCode.GDExitObjects3);
gdjs.copyArray(runtimeScene.getObjects("MM_BG"), gdjs.Main_32menuCode.GDMM_95BGObjects3);
gdjs.copyArray(runtimeScene.getObjects("Options"), gdjs.Main_32menuCode.GDOptionsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32menuCode.GDStartObjects3);
{for(var i = 0, len = gdjs.Main_32menuCode.GDMM_95BGObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMM_95BGObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDStartObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDStartObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDAboutObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAboutObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDOptionsObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDOptionsObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDExitObjects3.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDExitObjects3[i].hide(false);
}
}}
gdjs.Main_32menuCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16208420(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.asyncCallback16207876 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Are_you_sure_about_that"), gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects2);
gdjs.copyArray(asyncObjectsList.getObjects("No"), gdjs.Main_32menuCode.GDNoObjects2);

gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Main_32menuCode.GDYesObjects2);
{for(var i = 0, len = gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDYesObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDYesObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDNoObjects2.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDNoObjects2[i].hide();
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Main_32menuCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Main_32menuCode.GDNoObjects1) asyncObjectsList.addObject("No", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback16207876(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDLeftObjects1Objects = Hashtable.newFrom({"Left": gdjs.Main_32menuCode.GDLeftObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDRightObjects1Objects = Hashtable.newFrom({"Right": gdjs.Main_32menuCode.GDRightObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDMusic_9595ONObjects1Objects = Hashtable.newFrom({"Music_ON": gdjs.Main_32menuCode.GDMusic_95ONObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDMusic_9595OFFObjects1Objects = Hashtable.newFrom({"Music_OFF": gdjs.Main_32menuCode.GDMusic_95OFFObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDStartObjects1Objects = Hashtable.newFrom({"Start": gdjs.Main_32menuCode.GDStartObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDStartObjects1Objects = Hashtable.newFrom({"Start": gdjs.Main_32menuCode.GDStartObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDOptionsObjects1Objects = Hashtable.newFrom({"Options": gdjs.Main_32menuCode.GDOptionsObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDOptionsObjects1Objects = Hashtable.newFrom({"Options": gdjs.Main_32menuCode.GDOptionsObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.Main_32menuCode.GDExitObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.Main_32menuCode.GDExitObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDAboutObjects1Objects = Hashtable.newFrom({"About": gdjs.Main_32menuCode.GDAboutObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDAboutObjects1Objects = Hashtable.newFrom({"About": gdjs.Main_32menuCode.GDAboutObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDYesObjects1Objects = Hashtable.newFrom({"Yes": gdjs.Main_32menuCode.GDYesObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDYesObjects1Objects = Hashtable.newFrom({"Yes": gdjs.Main_32menuCode.GDYesObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDNoObjects1Objects = Hashtable.newFrom({"No": gdjs.Main_32menuCode.GDNoObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDNoObjects1Objects = Hashtable.newFrom({"No": gdjs.Main_32menuCode.GDNoObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs.Main_32menuCode.GDBackObjects1});
gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs.Main_32menuCode.GDBackObjects1});
gdjs.Main_32menuCode.eventsList10 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Main_32menuCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Main_32menuCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("MM_BG"), gdjs.Main_32menuCode.GDMM_95BGObjects1);
gdjs.copyArray(runtimeScene.getObjects("TV_TUBE"), gdjs.Main_32menuCode.GDTV_95TUBEObjects1);
{for(var i = 0, len = gdjs.Main_32menuCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCursorObjects1[i].setScale(3);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCursorObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackgroundObjects1[i].setYOffset(gdjs.Main_32menuCode.GDBackgroundObjects1[i].getYOffset() + (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDTV_95TUBEObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDTV_95TUBEObjects1[i].setYOffset(gdjs.Main_32menuCode.GDTV_95TUBEObjects1[i].getYOffset() + (-(50) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Main_32menuCode.GDMM_95BGObjects1.length !== 0 ? gdjs.Main_32menuCode.GDMM_95BGObjects1[0] : null), true, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Are_you_sure_about_that"), gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32menuCode.GDBackObjects1);
gdjs.copyArray(runtimeScene.getObjects("Character_Selector"), gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Main_32menuCode.GDLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Music_OFF"), gdjs.Main_32menuCode.GDMusic_95OFFObjects1);
gdjs.copyArray(runtimeScene.getObjects("Music_ON"), gdjs.Main_32menuCode.GDMusic_95ONObjects1);
gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Main_32menuCode.GDNoObjects1);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Main_32menuCode.GDRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Main_32menuCode.GDYesObjects1);
{for(var i = 0, len = gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDYesObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDYesObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDNoObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDNoObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDLeftObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDRightObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDRightObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95ONObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95ONObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95OFFObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95OFFObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95OFFObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95OFFObjects1[i].setOpacity(100);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32menuCode.GDAboutObjects1);
gdjs.copyArray(runtimeScene.getObjects("Are_you_sure_about_that"), gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32menuCode.GDBackObjects1);
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Main_32menuCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Character_Selector"), gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Main_32menuCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration"), gdjs.Main_32menuCode.GDDecorationObjects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration1"), gdjs.Main_32menuCode.GDDecoration1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration10"), gdjs.Main_32menuCode.GDDecoration10Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration11"), gdjs.Main_32menuCode.GDDecoration11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration12"), gdjs.Main_32menuCode.GDDecoration12Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration2"), gdjs.Main_32menuCode.GDDecoration2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration3"), gdjs.Main_32menuCode.GDDecoration3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration4"), gdjs.Main_32menuCode.GDDecoration4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration5"), gdjs.Main_32menuCode.GDDecoration5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration6"), gdjs.Main_32menuCode.GDDecoration6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration7"), gdjs.Main_32menuCode.GDDecoration7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration9"), gdjs.Main_32menuCode.GDDecoration9Objects1);
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32menuCode.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("MM_BG"), gdjs.Main_32menuCode.GDMM_95BGObjects1);
gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Main_32menuCode.GDNoObjects1);
gdjs.copyArray(runtimeScene.getObjects("Options"), gdjs.Main_32menuCode.GDOptionsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Main_32menuCode.GDSpikeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Main_32menuCode.GDSpike2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Main_32menuCode.GDSpike3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Main_32menuCode.GDSpike4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32menuCode.GDStartObjects1);
gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Main_32menuCode.GDYesObjects1);
{for(var i = 0, len = gdjs.Main_32menuCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCursorObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDStartObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAboutObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDOptionsObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDOptionsObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDExitObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDYesObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDYesObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDNoObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDNoObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMM_95BGObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMM_95BGObjects1[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackgroundObjects1[i].setZOrder(-(2));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDSpikeObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDSpikeObjects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDSpike2Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDSpike2Objects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDSpike3Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDSpike3Objects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDSpike4Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDSpike4Objects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecorationObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecorationObjects1[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration1Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration1Objects1[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration2Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration2Objects1[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration3Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration3Objects1[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration4Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration4Objects1[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration5Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration5Objects1[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration6Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration6Objects1[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration7Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration7Objects1[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration9Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration9Objects1[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration10Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration10Objects1[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration11Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration11Objects1[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration12Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration12Objects1[i].setZOrder(-(1));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Building_Blocks"), gdjs.Main_32menuCode.GDBuilding_95BlocksObjects1);
gdjs.copyArray(runtimeScene.getObjects("Building_Blocks_1"), gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration"), gdjs.Main_32menuCode.GDDecorationObjects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration1"), gdjs.Main_32menuCode.GDDecoration1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration10"), gdjs.Main_32menuCode.GDDecoration10Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration11"), gdjs.Main_32menuCode.GDDecoration11Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration12"), gdjs.Main_32menuCode.GDDecoration12Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration2"), gdjs.Main_32menuCode.GDDecoration2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration3"), gdjs.Main_32menuCode.GDDecoration3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration4"), gdjs.Main_32menuCode.GDDecoration4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration5"), gdjs.Main_32menuCode.GDDecoration5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration6"), gdjs.Main_32menuCode.GDDecoration6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration7"), gdjs.Main_32menuCode.GDDecoration7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration8"), gdjs.Main_32menuCode.GDDecoration8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Decoration9"), gdjs.Main_32menuCode.GDDecoration9Objects1);
{for(var i = 0, len = gdjs.Main_32menuCode.GDBuilding_95BlocksObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBuilding_95BlocksObjects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecorationObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecorationObjects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration12Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration12Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration1Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration1Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration2Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration2Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration3Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration3Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration4Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration4Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration5Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration5Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration6Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration6Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration6Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration6Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration7Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration7Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration8Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration8Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration9Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration9Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration10Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration10Objects1[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDDecoration11Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDDecoration11Objects1[i].setColor("0;0;0");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16187836);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Main_32menuCode.GDCursorObjects1);
{for(var i = 0, len = gdjs.Main_32menuCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCursorObjects1[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16188916);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Main_32menuCode.GDCursorObjects1);
{for(var i = 0, len = gdjs.Main_32menuCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCursorObjects1[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCursorObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32menuCode.GDStartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDStartObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDStartObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDStartObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDStartObjects1[k] = gdjs.Main_32menuCode.GDStartObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDStartObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16190652);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDStartObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDStartObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Options"), gdjs.Main_32menuCode.GDOptionsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDOptionsObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDOptionsObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDOptionsObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDOptionsObjects1[k] = gdjs.Main_32menuCode.GDOptionsObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDOptionsObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16192940);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDOptionsObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDOptionsObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDOptionsObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32menuCode.GDAboutObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDAboutObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDAboutObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDAboutObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDAboutObjects1[k] = gdjs.Main_32menuCode.GDAboutObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDAboutObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16196420);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDAboutObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAboutObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32menuCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDExitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDExitObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDExitObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDExitObjects1[k] = gdjs.Main_32menuCode.GDExitObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDExitObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16198260);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDExitObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDExitObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Main_32menuCode.GDYesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDYesObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDYesObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDYesObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDYesObjects1[k] = gdjs.Main_32menuCode.GDYesObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDYesObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16201404);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDYesObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDYesObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDYesObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32menuCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDBackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDBackObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDBackObjects1[k] = gdjs.Main_32menuCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDBackObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16203500);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDBackObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Main_32menuCode.GDNoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDNoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDNoObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDNoObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDNoObjects1[k] = gdjs.Main_32menuCode.GDNoObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDNoObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16204532);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDNoObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDNoObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDNoObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Main_32menuCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Main_32menuCode.GDLeftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDLeftObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDLeftObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDLeftObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDLeftObjects1[k] = gdjs.Main_32menuCode.GDLeftObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDLeftObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16210236);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Character_Selector"), gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1);
/* Reuse gdjs.Main_32menuCode.GDLeftObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDLeftObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDLeftObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].setAnimation(gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].getAnimation() - (1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Main_32menuCode.GDRightObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDRightObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDRightObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDRightObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDRightObjects1[k] = gdjs.Main_32menuCode.GDRightObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDRightObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16212780);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Character_Selector"), gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1);
/* Reuse gdjs.Main_32menuCode.GDRightObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDRightObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDRightObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].setAnimation(gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].getAnimation() + (1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character_Selector"), gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].getAnimation() == 5 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[k] = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Music_ON"), gdjs.Main_32menuCode.GDMusic_95ONObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDMusic_9595ONObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDMusic_95ONObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDMusic_95ONObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDMusic_95ONObjects1[k] = gdjs.Main_32menuCode.GDMusic_95ONObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDMusic_95ONObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16215588);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Music_OFF"), gdjs.Main_32menuCode.GDMusic_95OFFObjects1);
/* Reuse gdjs.Main_32menuCode.GDMusic_95ONObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95ONObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95ONObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(1), true);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95OFFObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95OFFObjects1[i].setOpacity(100);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95ONObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95ONObjects1[i].setOpacity(255);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Music_OFF"), gdjs.Main_32menuCode.GDMusic_95OFFObjects1);
gdjs.copyArray(runtimeScene.getObjects("Music_ON"), gdjs.Main_32menuCode.GDMusic_95ONObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDMusic_9595OFFObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDMusic_95ONObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDMusic_95ONObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32menuCode.GDMusic_95ONObjects1[k] = gdjs.Main_32menuCode.GDMusic_95ONObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDMusic_95ONObjects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16218436);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDMusic_95OFFObjects1 */
/* Reuse gdjs.Main_32menuCode.GDMusic_95ONObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95OFFObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95OFFObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(1), false);
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95ONObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95ONObjects1[i].setOpacity(100);
}
}{for(var i = 0, len = gdjs.Main_32menuCode.GDMusic_95OFFObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDMusic_95OFFObjects1[i].setOpacity(255);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32menuCode.GDStartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDStartObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16220612);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDStartObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDStartObjects1[i].setColor("248;231;28");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32menuCode.GDStartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDStartObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16221388);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDStartObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDStartObjects1[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Options"), gdjs.Main_32menuCode.GDOptionsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDOptionsObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16222164);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDOptionsObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDOptionsObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDOptionsObjects1[i].setColor("248;231;28");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Options"), gdjs.Main_32menuCode.GDOptionsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDOptionsObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16222940);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDOptionsObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDOptionsObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDOptionsObjects1[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32menuCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDExitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16223716);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDExitObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDExitObjects1[i].setColor("248;231;28");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32menuCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDExitObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16224492);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDExitObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDExitObjects1[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32menuCode.GDAboutObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDAboutObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16225268);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDAboutObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAboutObjects1[i].setColor("248;231;28");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32menuCode.GDAboutObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDAboutObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16226044);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDAboutObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDAboutObjects1[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Main_32menuCode.GDYesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDYesObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16226820);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDYesObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDYesObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDYesObjects1[i].setColor("248;231;28");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Main_32menuCode.GDYesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDYesObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16227836);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDYesObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDYesObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDYesObjects1[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Main_32menuCode.GDNoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDNoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16228380);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDNoObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDNoObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDNoObjects1[i].setColor("248;231;28");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Main_32menuCode.GDNoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDNoObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16229180);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDNoObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDNoObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDNoObjects1[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32menuCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDBackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16229980);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDBackObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackObjects1[i].setColor("248;231;28");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32menuCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32menuCode.mapOfGDgdjs_46Main_9532menuCode_46GDBackObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16230780);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32menuCode.GDBackObjects1 */
{for(var i = 0, len = gdjs.Main_32menuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDBackObjects1[i].setColor("255;255;255");
}
}}

}


};

gdjs.Main_32menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32menuCode.GDCursorObjects1.length = 0;
gdjs.Main_32menuCode.GDCursorObjects2.length = 0;
gdjs.Main_32menuCode.GDCursorObjects3.length = 0;
gdjs.Main_32menuCode.GDBackgroundObjects1.length = 0;
gdjs.Main_32menuCode.GDBackgroundObjects2.length = 0;
gdjs.Main_32menuCode.GDBackgroundObjects3.length = 0;
gdjs.Main_32menuCode.GDFanObjects1.length = 0;
gdjs.Main_32menuCode.GDFanObjects2.length = 0;
gdjs.Main_32menuCode.GDFanObjects3.length = 0;
gdjs.Main_32menuCode.GDDecorationObjects1.length = 0;
gdjs.Main_32menuCode.GDDecorationObjects2.length = 0;
gdjs.Main_32menuCode.GDDecorationObjects3.length = 0;
gdjs.Main_32menuCode.GDDecoration2Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration2Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration2Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration1Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration1Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration1Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration3Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration3Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration3Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration4Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration4Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration4Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration5Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration5Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration5Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration6Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration6Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration6Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration7Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration7Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration7Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration8Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration8Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration8Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration9Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration9Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration9Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration10Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration10Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration10Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration11Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration11Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration11Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration12Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration12Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration12Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration13Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration13Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration13Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration14Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration14Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration14Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration15Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration15Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration15Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration16Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration16Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration16Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration17Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration17Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration17Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration18Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration18Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration18Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration19Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration19Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration19Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration20Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration20Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration20Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration22Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration22Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration22Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration24Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration24Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration24Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration25Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration25Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration25Objects3.length = 0;
gdjs.Main_32menuCode.GDDecoration28Objects1.length = 0;
gdjs.Main_32menuCode.GDDecoration28Objects2.length = 0;
gdjs.Main_32menuCode.GDDecoration28Objects3.length = 0;
gdjs.Main_32menuCode.GDSpikeObjects1.length = 0;
gdjs.Main_32menuCode.GDSpikeObjects2.length = 0;
gdjs.Main_32menuCode.GDSpikeObjects3.length = 0;
gdjs.Main_32menuCode.GDSpike2Objects1.length = 0;
gdjs.Main_32menuCode.GDSpike2Objects2.length = 0;
gdjs.Main_32menuCode.GDSpike2Objects3.length = 0;
gdjs.Main_32menuCode.GDSpike3Objects1.length = 0;
gdjs.Main_32menuCode.GDSpike3Objects2.length = 0;
gdjs.Main_32menuCode.GDSpike3Objects3.length = 0;
gdjs.Main_32menuCode.GDSpike4Objects1.length = 0;
gdjs.Main_32menuCode.GDSpike4Objects2.length = 0;
gdjs.Main_32menuCode.GDSpike4Objects3.length = 0;
gdjs.Main_32menuCode.GDTV_95TUBEObjects1.length = 0;
gdjs.Main_32menuCode.GDTV_95TUBEObjects2.length = 0;
gdjs.Main_32menuCode.GDTV_95TUBEObjects3.length = 0;
gdjs.Main_32menuCode.GDPortalObjects1.length = 0;
gdjs.Main_32menuCode.GDPortalObjects2.length = 0;
gdjs.Main_32menuCode.GDPortalObjects3.length = 0;
gdjs.Main_32menuCode.GDPlayerObjects1.length = 0;
gdjs.Main_32menuCode.GDPlayerObjects2.length = 0;
gdjs.Main_32menuCode.GDPlayerObjects3.length = 0;
gdjs.Main_32menuCode.GDDustObjects1.length = 0;
gdjs.Main_32menuCode.GDDustObjects2.length = 0;
gdjs.Main_32menuCode.GDDustObjects3.length = 0;
gdjs.Main_32menuCode.GDBullet_95EffectObjects1.length = 0;
gdjs.Main_32menuCode.GDBullet_95EffectObjects2.length = 0;
gdjs.Main_32menuCode.GDBullet_95EffectObjects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITIONObjects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITIONObjects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITIONObjects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION2Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION2Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION2Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION3Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION3Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION3Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION4Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION4Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION4Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION5Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION5Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION5Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION6Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION6Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION6Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION7Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION7Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION7Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION8Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION8Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION8Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION9Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION9Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION9Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION10Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION10Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION10Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION11Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION11Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION11Objects3.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION12Objects1.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION12Objects2.length = 0;
gdjs.Main_32menuCode.GDCAMERA_95TRANSITION12Objects3.length = 0;
gdjs.Main_32menuCode.GDterminalObjects1.length = 0;
gdjs.Main_32menuCode.GDterminalObjects2.length = 0;
gdjs.Main_32menuCode.GDterminalObjects3.length = 0;
gdjs.Main_32menuCode.GDterminal5Objects1.length = 0;
gdjs.Main_32menuCode.GDterminal5Objects2.length = 0;
gdjs.Main_32menuCode.GDterminal5Objects3.length = 0;
gdjs.Main_32menuCode.GDterminal3Objects1.length = 0;
gdjs.Main_32menuCode.GDterminal3Objects2.length = 0;
gdjs.Main_32menuCode.GDterminal3Objects3.length = 0;
gdjs.Main_32menuCode.GDterminal4Objects1.length = 0;
gdjs.Main_32menuCode.GDterminal4Objects2.length = 0;
gdjs.Main_32menuCode.GDterminal4Objects3.length = 0;
gdjs.Main_32menuCode.GDGame_95OverObjects1.length = 0;
gdjs.Main_32menuCode.GDGame_95OverObjects2.length = 0;
gdjs.Main_32menuCode.GDGame_95OverObjects3.length = 0;
gdjs.Main_32menuCode.GDPlatformObjects1.length = 0;
gdjs.Main_32menuCode.GDPlatformObjects2.length = 0;
gdjs.Main_32menuCode.GDPlatformObjects3.length = 0;
gdjs.Main_32menuCode.GDPlatform_95BossObjects1.length = 0;
gdjs.Main_32menuCode.GDPlatform_95BossObjects2.length = 0;
gdjs.Main_32menuCode.GDPlatform_95BossObjects3.length = 0;
gdjs.Main_32menuCode.GDPlatform_95DoorObjects1.length = 0;
gdjs.Main_32menuCode.GDPlatform_95DoorObjects2.length = 0;
gdjs.Main_32menuCode.GDPlatform_95DoorObjects3.length = 0;
gdjs.Main_32menuCode.GDPlatform_95Door2Objects1.length = 0;
gdjs.Main_32menuCode.GDPlatform_95Door2Objects2.length = 0;
gdjs.Main_32menuCode.GDPlatform_95Door2Objects3.length = 0;
gdjs.Main_32menuCode.GDPlatform_95that_95get_95destroyedObjects1.length = 0;
gdjs.Main_32menuCode.GDPlatform_95that_95get_95destroyedObjects2.length = 0;
gdjs.Main_32menuCode.GDPlatform_95that_95get_95destroyedObjects3.length = 0;
gdjs.Main_32menuCode.GDPlatform_95JumpThroughObjects1.length = 0;
gdjs.Main_32menuCode.GDPlatform_95JumpThroughObjects2.length = 0;
gdjs.Main_32menuCode.GDPlatform_95JumpThroughObjects3.length = 0;
gdjs.Main_32menuCode.GDPlatform_95MovingObjects1.length = 0;
gdjs.Main_32menuCode.GDPlatform_95MovingObjects2.length = 0;
gdjs.Main_32menuCode.GDPlatform_95MovingObjects3.length = 0;
gdjs.Main_32menuCode.GDPlatform_95edgesObjects1.length = 0;
gdjs.Main_32menuCode.GDPlatform_95edgesObjects2.length = 0;
gdjs.Main_32menuCode.GDPlatform_95edgesObjects3.length = 0;
gdjs.Main_32menuCode.GDGame_95Over_95BGObjects1.length = 0;
gdjs.Main_32menuCode.GDGame_95Over_95BGObjects2.length = 0;
gdjs.Main_32menuCode.GDGame_95Over_95BGObjects3.length = 0;
gdjs.Main_32menuCode.GDDeathObjects1.length = 0;
gdjs.Main_32menuCode.GDDeathObjects2.length = 0;
gdjs.Main_32menuCode.GDDeathObjects3.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95OverObjects1.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95OverObjects2.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95OverObjects3.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95againObjects1.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95againObjects2.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95againObjects3.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95again2Objects1.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95again2Objects2.length = 0;
gdjs.Main_32menuCode.GDText_95Game_95Over_95Play_95again2Objects3.length = 0;
gdjs.Main_32menuCode.GDTimerObjects1.length = 0;
gdjs.Main_32menuCode.GDTimerObjects2.length = 0;
gdjs.Main_32menuCode.GDTimerObjects3.length = 0;
gdjs.Main_32menuCode.GDShield_95CountObjects1.length = 0;
gdjs.Main_32menuCode.GDShield_95CountObjects2.length = 0;
gdjs.Main_32menuCode.GDShield_95CountObjects3.length = 0;
gdjs.Main_32menuCode.GDShield_95CapsuleObjects1.length = 0;
gdjs.Main_32menuCode.GDShield_95CapsuleObjects2.length = 0;
gdjs.Main_32menuCode.GDShield_95CapsuleObjects3.length = 0;
gdjs.Main_32menuCode.GDTime_95CapsuleObjects1.length = 0;
gdjs.Main_32menuCode.GDTime_95CapsuleObjects2.length = 0;
gdjs.Main_32menuCode.GDTime_95CapsuleObjects3.length = 0;
gdjs.Main_32menuCode.GDLeftObjects1.length = 0;
gdjs.Main_32menuCode.GDLeftObjects2.length = 0;
gdjs.Main_32menuCode.GDLeftObjects3.length = 0;
gdjs.Main_32menuCode.GDRightObjects1.length = 0;
gdjs.Main_32menuCode.GDRightObjects2.length = 0;
gdjs.Main_32menuCode.GDRightObjects3.length = 0;
gdjs.Main_32menuCode.GDLeft_95ControlObjects1.length = 0;
gdjs.Main_32menuCode.GDLeft_95ControlObjects2.length = 0;
gdjs.Main_32menuCode.GDLeft_95ControlObjects3.length = 0;
gdjs.Main_32menuCode.GDRight_95ControlObjects1.length = 0;
gdjs.Main_32menuCode.GDRight_95ControlObjects2.length = 0;
gdjs.Main_32menuCode.GDRight_95ControlObjects3.length = 0;
gdjs.Main_32menuCode.GDBullet_95EnemyObjects1.length = 0;
gdjs.Main_32menuCode.GDBullet_95EnemyObjects2.length = 0;
gdjs.Main_32menuCode.GDBullet_95EnemyObjects3.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_952Objects1.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_952Objects2.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_952Objects3.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_953Objects1.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_953Objects2.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_953Objects3.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_951Objects1.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_951Objects2.length = 0;
gdjs.Main_32menuCode.GDBullet_95Enemy_951Objects3.length = 0;
gdjs.Main_32menuCode.GDBulletObjects1.length = 0;
gdjs.Main_32menuCode.GDBulletObjects2.length = 0;
gdjs.Main_32menuCode.GDBulletObjects3.length = 0;
gdjs.Main_32menuCode.GDHealth_95barObjects1.length = 0;
gdjs.Main_32menuCode.GDHealth_95barObjects2.length = 0;
gdjs.Main_32menuCode.GDHealth_95barObjects3.length = 0;
gdjs.Main_32menuCode.GDG_95ControlObjects1.length = 0;
gdjs.Main_32menuCode.GDG_95ControlObjects2.length = 0;
gdjs.Main_32menuCode.GDG_95ControlObjects3.length = 0;
gdjs.Main_32menuCode.GDF_95ControlObjects1.length = 0;
gdjs.Main_32menuCode.GDF_95ControlObjects2.length = 0;
gdjs.Main_32menuCode.GDF_95ControlObjects3.length = 0;
gdjs.Main_32menuCode.GDDown_95ControlObjects1.length = 0;
gdjs.Main_32menuCode.GDDown_95ControlObjects2.length = 0;
gdjs.Main_32menuCode.GDDown_95ControlObjects3.length = 0;
gdjs.Main_32menuCode.GDSpace_95ControlObjects1.length = 0;
gdjs.Main_32menuCode.GDSpace_95ControlObjects2.length = 0;
gdjs.Main_32menuCode.GDSpace_95ControlObjects3.length = 0;
gdjs.Main_32menuCode.GDShield_95SkillObjects1.length = 0;
gdjs.Main_32menuCode.GDShield_95SkillObjects2.length = 0;
gdjs.Main_32menuCode.GDShield_95SkillObjects3.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95BlockObjects1.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95BlockObjects2.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95BlockObjects3.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block2Objects1.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block2Objects2.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block2Objects3.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block3Objects1.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block3Objects2.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block3Objects3.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block4Objects1.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block4Objects2.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block4Objects3.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block5Objects1.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block5Objects2.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block5Objects3.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block6Objects1.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block6Objects2.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block6Objects3.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block7Objects1.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block7Objects2.length = 0;
gdjs.Main_32menuCode.GDMove_95To_95Block7Objects3.length = 0;
gdjs.Main_32menuCode.GDVirus_952Objects1.length = 0;
gdjs.Main_32menuCode.GDVirus_952Objects2.length = 0;
gdjs.Main_32menuCode.GDVirus_952Objects3.length = 0;
gdjs.Main_32menuCode.GDVirus_952_95WallObjects1.length = 0;
gdjs.Main_32menuCode.GDVirus_952_95WallObjects2.length = 0;
gdjs.Main_32menuCode.GDVirus_952_95WallObjects3.length = 0;
gdjs.Main_32menuCode.GDVirus_952_95FlippedObjects1.length = 0;
gdjs.Main_32menuCode.GDVirus_952_95FlippedObjects2.length = 0;
gdjs.Main_32menuCode.GDVirus_952_95FlippedObjects3.length = 0;
gdjs.Main_32menuCode.GDShoot_95FromObjects1.length = 0;
gdjs.Main_32menuCode.GDShoot_95FromObjects2.length = 0;
gdjs.Main_32menuCode.GDShoot_95FromObjects3.length = 0;
gdjs.Main_32menuCode.GDShoot_95From2Objects1.length = 0;
gdjs.Main_32menuCode.GDShoot_95From2Objects2.length = 0;
gdjs.Main_32menuCode.GDShoot_95From2Objects3.length = 0;
gdjs.Main_32menuCode.GDShoot_95From3Objects1.length = 0;
gdjs.Main_32menuCode.GDShoot_95From3Objects2.length = 0;
gdjs.Main_32menuCode.GDShoot_95From3Objects3.length = 0;
gdjs.Main_32menuCode.GDFalling_95WallObjects1.length = 0;
gdjs.Main_32menuCode.GDFalling_95WallObjects2.length = 0;
gdjs.Main_32menuCode.GDFalling_95WallObjects3.length = 0;
gdjs.Main_32menuCode.GDFalling_95Wall_95ChainObjects1.length = 0;
gdjs.Main_32menuCode.GDFalling_95Wall_95ChainObjects2.length = 0;
gdjs.Main_32menuCode.GDFalling_95Wall_95ChainObjects3.length = 0;
gdjs.Main_32menuCode.GDBossObjects1.length = 0;
gdjs.Main_32menuCode.GDBossObjects2.length = 0;
gdjs.Main_32menuCode.GDBossObjects3.length = 0;
gdjs.Main_32menuCode.GDTutorial_95BossObjects1.length = 0;
gdjs.Main_32menuCode.GDTutorial_95BossObjects2.length = 0;
gdjs.Main_32menuCode.GDTutorial_95BossObjects3.length = 0;
gdjs.Main_32menuCode.GDMM_95BGObjects1.length = 0;
gdjs.Main_32menuCode.GDMM_95BGObjects2.length = 0;
gdjs.Main_32menuCode.GDMM_95BGObjects3.length = 0;
gdjs.Main_32menuCode.GDStartObjects1.length = 0;
gdjs.Main_32menuCode.GDStartObjects2.length = 0;
gdjs.Main_32menuCode.GDStartObjects3.length = 0;
gdjs.Main_32menuCode.GDOptionsObjects1.length = 0;
gdjs.Main_32menuCode.GDOptionsObjects2.length = 0;
gdjs.Main_32menuCode.GDOptionsObjects3.length = 0;
gdjs.Main_32menuCode.GDAboutObjects1.length = 0;
gdjs.Main_32menuCode.GDAboutObjects2.length = 0;
gdjs.Main_32menuCode.GDAboutObjects3.length = 0;
gdjs.Main_32menuCode.GDExitObjects1.length = 0;
gdjs.Main_32menuCode.GDExitObjects2.length = 0;
gdjs.Main_32menuCode.GDExitObjects3.length = 0;
gdjs.Main_32menuCode.GDBackObjects1.length = 0;
gdjs.Main_32menuCode.GDBackObjects2.length = 0;
gdjs.Main_32menuCode.GDBackObjects3.length = 0;
gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects1.length = 0;
gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects2.length = 0;
gdjs.Main_32menuCode.GDAre_95you_95sure_95about_95thatObjects3.length = 0;
gdjs.Main_32menuCode.GDYesObjects1.length = 0;
gdjs.Main_32menuCode.GDYesObjects2.length = 0;
gdjs.Main_32menuCode.GDYesObjects3.length = 0;
gdjs.Main_32menuCode.GDNoObjects1.length = 0;
gdjs.Main_32menuCode.GDNoObjects2.length = 0;
gdjs.Main_32menuCode.GDNoObjects3.length = 0;
gdjs.Main_32menuCode.GDBuilding_95BlocksObjects1.length = 0;
gdjs.Main_32menuCode.GDBuilding_95BlocksObjects2.length = 0;
gdjs.Main_32menuCode.GDBuilding_95BlocksObjects3.length = 0;
gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects1.length = 0;
gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects2.length = 0;
gdjs.Main_32menuCode.GDBuilding_95Blocks_951Objects3.length = 0;
gdjs.Main_32menuCode.GDCharacter_95SelectorObjects1.length = 0;
gdjs.Main_32menuCode.GDCharacter_95SelectorObjects2.length = 0;
gdjs.Main_32menuCode.GDCharacter_95SelectorObjects3.length = 0;
gdjs.Main_32menuCode.GDMusic_95ONObjects1.length = 0;
gdjs.Main_32menuCode.GDMusic_95ONObjects2.length = 0;
gdjs.Main_32menuCode.GDMusic_95ONObjects3.length = 0;
gdjs.Main_32menuCode.GDMusic_95OFFObjects1.length = 0;
gdjs.Main_32menuCode.GDMusic_95OFFObjects2.length = 0;
gdjs.Main_32menuCode.GDMusic_95OFFObjects3.length = 0;

gdjs.Main_32menuCode.eventsList10(runtimeScene);

return;

}

gdjs['Main_32menuCode'] = gdjs.Main_32menuCode;

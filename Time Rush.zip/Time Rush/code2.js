gdjs.Level_321Code = {};
gdjs.Level_321Code.GDBossObjects1_2final = [];

gdjs.Level_321Code.GDBossObjects2_2final = [];

gdjs.Level_321Code.GDBulletObjects2_1final = [];

gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final = [];

gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final = [];

gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final = [];

gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final = [];

gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final = [];

gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final = [];

gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final = [];

gdjs.Level_321Code.GDDeathObjects2_1final = [];

gdjs.Level_321Code.GDPlatformObjects2_1final = [];

gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final = [];

gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final = [];

gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final = [];

gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final = [];

gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final = [];

gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final = [];

gdjs.Level_321Code.GDPlayerObjects2_1final = [];

gdjs.Level_321Code.GDPlayerObjects2_2final = [];

gdjs.Level_321Code.GDSpike2Objects2_1final = [];

gdjs.Level_321Code.GDSpike3Objects2_1final = [];

gdjs.Level_321Code.GDSpike4Objects2_1final = [];

gdjs.Level_321Code.GDSpikeObjects2_1final = [];

gdjs.Level_321Code.GDTutorial_95BossObjects2_2final = [];

gdjs.Level_321Code.GDVirus_952Objects2_1final = [];

gdjs.Level_321Code.GDVirus_952_95FlippedObjects2_1final = [];

gdjs.Level_321Code.GDVirus_952_95WallObjects2_1final = [];

gdjs.Level_321Code.GDCursorObjects1= [];
gdjs.Level_321Code.GDCursorObjects2= [];
gdjs.Level_321Code.GDCursorObjects3= [];
gdjs.Level_321Code.GDCursorObjects4= [];
gdjs.Level_321Code.GDBackgroundObjects1= [];
gdjs.Level_321Code.GDBackgroundObjects2= [];
gdjs.Level_321Code.GDBackgroundObjects3= [];
gdjs.Level_321Code.GDBackgroundObjects4= [];
gdjs.Level_321Code.GDFanObjects1= [];
gdjs.Level_321Code.GDFanObjects2= [];
gdjs.Level_321Code.GDFanObjects3= [];
gdjs.Level_321Code.GDFanObjects4= [];
gdjs.Level_321Code.GDDecorationObjects1= [];
gdjs.Level_321Code.GDDecorationObjects2= [];
gdjs.Level_321Code.GDDecorationObjects3= [];
gdjs.Level_321Code.GDDecorationObjects4= [];
gdjs.Level_321Code.GDDecoration2Objects1= [];
gdjs.Level_321Code.GDDecoration2Objects2= [];
gdjs.Level_321Code.GDDecoration2Objects3= [];
gdjs.Level_321Code.GDDecoration2Objects4= [];
gdjs.Level_321Code.GDDecoration1Objects1= [];
gdjs.Level_321Code.GDDecoration1Objects2= [];
gdjs.Level_321Code.GDDecoration1Objects3= [];
gdjs.Level_321Code.GDDecoration1Objects4= [];
gdjs.Level_321Code.GDDecoration3Objects1= [];
gdjs.Level_321Code.GDDecoration3Objects2= [];
gdjs.Level_321Code.GDDecoration3Objects3= [];
gdjs.Level_321Code.GDDecoration3Objects4= [];
gdjs.Level_321Code.GDDecoration4Objects1= [];
gdjs.Level_321Code.GDDecoration4Objects2= [];
gdjs.Level_321Code.GDDecoration4Objects3= [];
gdjs.Level_321Code.GDDecoration4Objects4= [];
gdjs.Level_321Code.GDDecoration5Objects1= [];
gdjs.Level_321Code.GDDecoration5Objects2= [];
gdjs.Level_321Code.GDDecoration5Objects3= [];
gdjs.Level_321Code.GDDecoration5Objects4= [];
gdjs.Level_321Code.GDDecoration6Objects1= [];
gdjs.Level_321Code.GDDecoration6Objects2= [];
gdjs.Level_321Code.GDDecoration6Objects3= [];
gdjs.Level_321Code.GDDecoration6Objects4= [];
gdjs.Level_321Code.GDDecoration7Objects1= [];
gdjs.Level_321Code.GDDecoration7Objects2= [];
gdjs.Level_321Code.GDDecoration7Objects3= [];
gdjs.Level_321Code.GDDecoration7Objects4= [];
gdjs.Level_321Code.GDDecoration8Objects1= [];
gdjs.Level_321Code.GDDecoration8Objects2= [];
gdjs.Level_321Code.GDDecoration8Objects3= [];
gdjs.Level_321Code.GDDecoration8Objects4= [];
gdjs.Level_321Code.GDDecoration9Objects1= [];
gdjs.Level_321Code.GDDecoration9Objects2= [];
gdjs.Level_321Code.GDDecoration9Objects3= [];
gdjs.Level_321Code.GDDecoration9Objects4= [];
gdjs.Level_321Code.GDDecoration10Objects1= [];
gdjs.Level_321Code.GDDecoration10Objects2= [];
gdjs.Level_321Code.GDDecoration10Objects3= [];
gdjs.Level_321Code.GDDecoration10Objects4= [];
gdjs.Level_321Code.GDDecoration11Objects1= [];
gdjs.Level_321Code.GDDecoration11Objects2= [];
gdjs.Level_321Code.GDDecoration11Objects3= [];
gdjs.Level_321Code.GDDecoration11Objects4= [];
gdjs.Level_321Code.GDDecoration12Objects1= [];
gdjs.Level_321Code.GDDecoration12Objects2= [];
gdjs.Level_321Code.GDDecoration12Objects3= [];
gdjs.Level_321Code.GDDecoration12Objects4= [];
gdjs.Level_321Code.GDDecoration13Objects1= [];
gdjs.Level_321Code.GDDecoration13Objects2= [];
gdjs.Level_321Code.GDDecoration13Objects3= [];
gdjs.Level_321Code.GDDecoration13Objects4= [];
gdjs.Level_321Code.GDDecoration14Objects1= [];
gdjs.Level_321Code.GDDecoration14Objects2= [];
gdjs.Level_321Code.GDDecoration14Objects3= [];
gdjs.Level_321Code.GDDecoration14Objects4= [];
gdjs.Level_321Code.GDDecoration15Objects1= [];
gdjs.Level_321Code.GDDecoration15Objects2= [];
gdjs.Level_321Code.GDDecoration15Objects3= [];
gdjs.Level_321Code.GDDecoration15Objects4= [];
gdjs.Level_321Code.GDDecoration16Objects1= [];
gdjs.Level_321Code.GDDecoration16Objects2= [];
gdjs.Level_321Code.GDDecoration16Objects3= [];
gdjs.Level_321Code.GDDecoration16Objects4= [];
gdjs.Level_321Code.GDDecoration17Objects1= [];
gdjs.Level_321Code.GDDecoration17Objects2= [];
gdjs.Level_321Code.GDDecoration17Objects3= [];
gdjs.Level_321Code.GDDecoration17Objects4= [];
gdjs.Level_321Code.GDDecoration18Objects1= [];
gdjs.Level_321Code.GDDecoration18Objects2= [];
gdjs.Level_321Code.GDDecoration18Objects3= [];
gdjs.Level_321Code.GDDecoration18Objects4= [];
gdjs.Level_321Code.GDDecoration19Objects1= [];
gdjs.Level_321Code.GDDecoration19Objects2= [];
gdjs.Level_321Code.GDDecoration19Objects3= [];
gdjs.Level_321Code.GDDecoration19Objects4= [];
gdjs.Level_321Code.GDDecoration20Objects1= [];
gdjs.Level_321Code.GDDecoration20Objects2= [];
gdjs.Level_321Code.GDDecoration20Objects3= [];
gdjs.Level_321Code.GDDecoration20Objects4= [];
gdjs.Level_321Code.GDDecoration22Objects1= [];
gdjs.Level_321Code.GDDecoration22Objects2= [];
gdjs.Level_321Code.GDDecoration22Objects3= [];
gdjs.Level_321Code.GDDecoration22Objects4= [];
gdjs.Level_321Code.GDDecoration24Objects1= [];
gdjs.Level_321Code.GDDecoration24Objects2= [];
gdjs.Level_321Code.GDDecoration24Objects3= [];
gdjs.Level_321Code.GDDecoration24Objects4= [];
gdjs.Level_321Code.GDDecoration25Objects1= [];
gdjs.Level_321Code.GDDecoration25Objects2= [];
gdjs.Level_321Code.GDDecoration25Objects3= [];
gdjs.Level_321Code.GDDecoration25Objects4= [];
gdjs.Level_321Code.GDDecoration28Objects1= [];
gdjs.Level_321Code.GDDecoration28Objects2= [];
gdjs.Level_321Code.GDDecoration28Objects3= [];
gdjs.Level_321Code.GDDecoration28Objects4= [];
gdjs.Level_321Code.GDSpikeObjects1= [];
gdjs.Level_321Code.GDSpikeObjects2= [];
gdjs.Level_321Code.GDSpikeObjects3= [];
gdjs.Level_321Code.GDSpikeObjects4= [];
gdjs.Level_321Code.GDSpike2Objects1= [];
gdjs.Level_321Code.GDSpike2Objects2= [];
gdjs.Level_321Code.GDSpike2Objects3= [];
gdjs.Level_321Code.GDSpike2Objects4= [];
gdjs.Level_321Code.GDSpike3Objects1= [];
gdjs.Level_321Code.GDSpike3Objects2= [];
gdjs.Level_321Code.GDSpike3Objects3= [];
gdjs.Level_321Code.GDSpike3Objects4= [];
gdjs.Level_321Code.GDSpike4Objects1= [];
gdjs.Level_321Code.GDSpike4Objects2= [];
gdjs.Level_321Code.GDSpike4Objects3= [];
gdjs.Level_321Code.GDSpike4Objects4= [];
gdjs.Level_321Code.GDTV_95TUBEObjects1= [];
gdjs.Level_321Code.GDTV_95TUBEObjects2= [];
gdjs.Level_321Code.GDTV_95TUBEObjects3= [];
gdjs.Level_321Code.GDTV_95TUBEObjects4= [];
gdjs.Level_321Code.GDPortalObjects1= [];
gdjs.Level_321Code.GDPortalObjects2= [];
gdjs.Level_321Code.GDPortalObjects3= [];
gdjs.Level_321Code.GDPortalObjects4= [];
gdjs.Level_321Code.GDPlayerObjects1= [];
gdjs.Level_321Code.GDPlayerObjects2= [];
gdjs.Level_321Code.GDPlayerObjects3= [];
gdjs.Level_321Code.GDPlayerObjects4= [];
gdjs.Level_321Code.GDDustObjects1= [];
gdjs.Level_321Code.GDDustObjects2= [];
gdjs.Level_321Code.GDDustObjects3= [];
gdjs.Level_321Code.GDDustObjects4= [];
gdjs.Level_321Code.GDBullet_95EffectObjects1= [];
gdjs.Level_321Code.GDBullet_95EffectObjects2= [];
gdjs.Level_321Code.GDBullet_95EffectObjects3= [];
gdjs.Level_321Code.GDBullet_95EffectObjects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects4= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION12Objects1= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION12Objects2= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION12Objects3= [];
gdjs.Level_321Code.GDCAMERA_95TRANSITION12Objects4= [];
gdjs.Level_321Code.GDterminalObjects1= [];
gdjs.Level_321Code.GDterminalObjects2= [];
gdjs.Level_321Code.GDterminalObjects3= [];
gdjs.Level_321Code.GDterminalObjects4= [];
gdjs.Level_321Code.GDterminal5Objects1= [];
gdjs.Level_321Code.GDterminal5Objects2= [];
gdjs.Level_321Code.GDterminal5Objects3= [];
gdjs.Level_321Code.GDterminal5Objects4= [];
gdjs.Level_321Code.GDterminal3Objects1= [];
gdjs.Level_321Code.GDterminal3Objects2= [];
gdjs.Level_321Code.GDterminal3Objects3= [];
gdjs.Level_321Code.GDterminal3Objects4= [];
gdjs.Level_321Code.GDterminal4Objects1= [];
gdjs.Level_321Code.GDterminal4Objects2= [];
gdjs.Level_321Code.GDterminal4Objects3= [];
gdjs.Level_321Code.GDterminal4Objects4= [];
gdjs.Level_321Code.GDGame_95OverObjects1= [];
gdjs.Level_321Code.GDGame_95OverObjects2= [];
gdjs.Level_321Code.GDGame_95OverObjects3= [];
gdjs.Level_321Code.GDGame_95OverObjects4= [];
gdjs.Level_321Code.GDPlatformObjects1= [];
gdjs.Level_321Code.GDPlatformObjects2= [];
gdjs.Level_321Code.GDPlatformObjects3= [];
gdjs.Level_321Code.GDPlatformObjects4= [];
gdjs.Level_321Code.GDPlatform_95BossObjects1= [];
gdjs.Level_321Code.GDPlatform_95BossObjects2= [];
gdjs.Level_321Code.GDPlatform_95BossObjects3= [];
gdjs.Level_321Code.GDPlatform_95BossObjects4= [];
gdjs.Level_321Code.GDPlatform_95DoorObjects1= [];
gdjs.Level_321Code.GDPlatform_95DoorObjects2= [];
gdjs.Level_321Code.GDPlatform_95DoorObjects3= [];
gdjs.Level_321Code.GDPlatform_95DoorObjects4= [];
gdjs.Level_321Code.GDPlatform_95Door2Objects1= [];
gdjs.Level_321Code.GDPlatform_95Door2Objects2= [];
gdjs.Level_321Code.GDPlatform_95Door2Objects3= [];
gdjs.Level_321Code.GDPlatform_95Door2Objects4= [];
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects1= [];
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2= [];
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3= [];
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects4= [];
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects1= [];
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2= [];
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3= [];
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects4= [];
gdjs.Level_321Code.GDPlatform_95MovingObjects1= [];
gdjs.Level_321Code.GDPlatform_95MovingObjects2= [];
gdjs.Level_321Code.GDPlatform_95MovingObjects3= [];
gdjs.Level_321Code.GDPlatform_95MovingObjects4= [];
gdjs.Level_321Code.GDPlatform_95edgesObjects1= [];
gdjs.Level_321Code.GDPlatform_95edgesObjects2= [];
gdjs.Level_321Code.GDPlatform_95edgesObjects3= [];
gdjs.Level_321Code.GDPlatform_95edgesObjects4= [];
gdjs.Level_321Code.GDGame_95Over_95BGObjects1= [];
gdjs.Level_321Code.GDGame_95Over_95BGObjects2= [];
gdjs.Level_321Code.GDGame_95Over_95BGObjects3= [];
gdjs.Level_321Code.GDGame_95Over_95BGObjects4= [];
gdjs.Level_321Code.GDDeathObjects1= [];
gdjs.Level_321Code.GDDeathObjects2= [];
gdjs.Level_321Code.GDDeathObjects3= [];
gdjs.Level_321Code.GDDeathObjects4= [];
gdjs.Level_321Code.GDText_95Game_95OverObjects1= [];
gdjs.Level_321Code.GDText_95Game_95OverObjects2= [];
gdjs.Level_321Code.GDText_95Game_95OverObjects3= [];
gdjs.Level_321Code.GDText_95Game_95OverObjects4= [];
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects1= [];
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2= [];
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects3= [];
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects4= [];
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects1= [];
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects2= [];
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects3= [];
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects4= [];
gdjs.Level_321Code.GDTimerObjects1= [];
gdjs.Level_321Code.GDTimerObjects2= [];
gdjs.Level_321Code.GDTimerObjects3= [];
gdjs.Level_321Code.GDTimerObjects4= [];
gdjs.Level_321Code.GDShield_95CountObjects1= [];
gdjs.Level_321Code.GDShield_95CountObjects2= [];
gdjs.Level_321Code.GDShield_95CountObjects3= [];
gdjs.Level_321Code.GDShield_95CountObjects4= [];
gdjs.Level_321Code.GDShield_95CapsuleObjects1= [];
gdjs.Level_321Code.GDShield_95CapsuleObjects2= [];
gdjs.Level_321Code.GDShield_95CapsuleObjects3= [];
gdjs.Level_321Code.GDShield_95CapsuleObjects4= [];
gdjs.Level_321Code.GDTime_95CapsuleObjects1= [];
gdjs.Level_321Code.GDTime_95CapsuleObjects2= [];
gdjs.Level_321Code.GDTime_95CapsuleObjects3= [];
gdjs.Level_321Code.GDTime_95CapsuleObjects4= [];
gdjs.Level_321Code.GDLeftObjects1= [];
gdjs.Level_321Code.GDLeftObjects2= [];
gdjs.Level_321Code.GDLeftObjects3= [];
gdjs.Level_321Code.GDLeftObjects4= [];
gdjs.Level_321Code.GDRightObjects1= [];
gdjs.Level_321Code.GDRightObjects2= [];
gdjs.Level_321Code.GDRightObjects3= [];
gdjs.Level_321Code.GDRightObjects4= [];
gdjs.Level_321Code.GDLeft_95ControlObjects1= [];
gdjs.Level_321Code.GDLeft_95ControlObjects2= [];
gdjs.Level_321Code.GDLeft_95ControlObjects3= [];
gdjs.Level_321Code.GDLeft_95ControlObjects4= [];
gdjs.Level_321Code.GDRight_95ControlObjects1= [];
gdjs.Level_321Code.GDRight_95ControlObjects2= [];
gdjs.Level_321Code.GDRight_95ControlObjects3= [];
gdjs.Level_321Code.GDRight_95ControlObjects4= [];
gdjs.Level_321Code.GDBullet_95EnemyObjects1= [];
gdjs.Level_321Code.GDBullet_95EnemyObjects2= [];
gdjs.Level_321Code.GDBullet_95EnemyObjects3= [];
gdjs.Level_321Code.GDBullet_95EnemyObjects4= [];
gdjs.Level_321Code.GDBullet_95Enemy_952Objects1= [];
gdjs.Level_321Code.GDBullet_95Enemy_952Objects2= [];
gdjs.Level_321Code.GDBullet_95Enemy_952Objects3= [];
gdjs.Level_321Code.GDBullet_95Enemy_952Objects4= [];
gdjs.Level_321Code.GDBullet_95Enemy_953Objects1= [];
gdjs.Level_321Code.GDBullet_95Enemy_953Objects2= [];
gdjs.Level_321Code.GDBullet_95Enemy_953Objects3= [];
gdjs.Level_321Code.GDBullet_95Enemy_953Objects4= [];
gdjs.Level_321Code.GDBullet_95Enemy_951Objects1= [];
gdjs.Level_321Code.GDBullet_95Enemy_951Objects2= [];
gdjs.Level_321Code.GDBullet_95Enemy_951Objects3= [];
gdjs.Level_321Code.GDBullet_95Enemy_951Objects4= [];
gdjs.Level_321Code.GDBulletObjects1= [];
gdjs.Level_321Code.GDBulletObjects2= [];
gdjs.Level_321Code.GDBulletObjects3= [];
gdjs.Level_321Code.GDBulletObjects4= [];
gdjs.Level_321Code.GDHealth_95barObjects1= [];
gdjs.Level_321Code.GDHealth_95barObjects2= [];
gdjs.Level_321Code.GDHealth_95barObjects3= [];
gdjs.Level_321Code.GDHealth_95barObjects4= [];
gdjs.Level_321Code.GDG_95ControlObjects1= [];
gdjs.Level_321Code.GDG_95ControlObjects2= [];
gdjs.Level_321Code.GDG_95ControlObjects3= [];
gdjs.Level_321Code.GDG_95ControlObjects4= [];
gdjs.Level_321Code.GDF_95ControlObjects1= [];
gdjs.Level_321Code.GDF_95ControlObjects2= [];
gdjs.Level_321Code.GDF_95ControlObjects3= [];
gdjs.Level_321Code.GDF_95ControlObjects4= [];
gdjs.Level_321Code.GDDown_95ControlObjects1= [];
gdjs.Level_321Code.GDDown_95ControlObjects2= [];
gdjs.Level_321Code.GDDown_95ControlObjects3= [];
gdjs.Level_321Code.GDDown_95ControlObjects4= [];
gdjs.Level_321Code.GDSpace_95ControlObjects1= [];
gdjs.Level_321Code.GDSpace_95ControlObjects2= [];
gdjs.Level_321Code.GDSpace_95ControlObjects3= [];
gdjs.Level_321Code.GDSpace_95ControlObjects4= [];
gdjs.Level_321Code.GDShield_95SkillObjects1= [];
gdjs.Level_321Code.GDShield_95SkillObjects2= [];
gdjs.Level_321Code.GDShield_95SkillObjects3= [];
gdjs.Level_321Code.GDShield_95SkillObjects4= [];
gdjs.Level_321Code.GDMove_95To_95BlockObjects1= [];
gdjs.Level_321Code.GDMove_95To_95BlockObjects2= [];
gdjs.Level_321Code.GDMove_95To_95BlockObjects3= [];
gdjs.Level_321Code.GDMove_95To_95BlockObjects4= [];
gdjs.Level_321Code.GDMove_95To_95Block2Objects1= [];
gdjs.Level_321Code.GDMove_95To_95Block2Objects2= [];
gdjs.Level_321Code.GDMove_95To_95Block2Objects3= [];
gdjs.Level_321Code.GDMove_95To_95Block2Objects4= [];
gdjs.Level_321Code.GDMove_95To_95Block3Objects1= [];
gdjs.Level_321Code.GDMove_95To_95Block3Objects2= [];
gdjs.Level_321Code.GDMove_95To_95Block3Objects3= [];
gdjs.Level_321Code.GDMove_95To_95Block3Objects4= [];
gdjs.Level_321Code.GDMove_95To_95Block4Objects1= [];
gdjs.Level_321Code.GDMove_95To_95Block4Objects2= [];
gdjs.Level_321Code.GDMove_95To_95Block4Objects3= [];
gdjs.Level_321Code.GDMove_95To_95Block4Objects4= [];
gdjs.Level_321Code.GDMove_95To_95Block5Objects1= [];
gdjs.Level_321Code.GDMove_95To_95Block5Objects2= [];
gdjs.Level_321Code.GDMove_95To_95Block5Objects3= [];
gdjs.Level_321Code.GDMove_95To_95Block5Objects4= [];
gdjs.Level_321Code.GDMove_95To_95Block6Objects1= [];
gdjs.Level_321Code.GDMove_95To_95Block6Objects2= [];
gdjs.Level_321Code.GDMove_95To_95Block6Objects3= [];
gdjs.Level_321Code.GDMove_95To_95Block6Objects4= [];
gdjs.Level_321Code.GDMove_95To_95Block7Objects1= [];
gdjs.Level_321Code.GDMove_95To_95Block7Objects2= [];
gdjs.Level_321Code.GDMove_95To_95Block7Objects3= [];
gdjs.Level_321Code.GDMove_95To_95Block7Objects4= [];
gdjs.Level_321Code.GDVirus_952Objects1= [];
gdjs.Level_321Code.GDVirus_952Objects2= [];
gdjs.Level_321Code.GDVirus_952Objects3= [];
gdjs.Level_321Code.GDVirus_952Objects4= [];
gdjs.Level_321Code.GDVirus_952_95WallObjects1= [];
gdjs.Level_321Code.GDVirus_952_95WallObjects2= [];
gdjs.Level_321Code.GDVirus_952_95WallObjects3= [];
gdjs.Level_321Code.GDVirus_952_95WallObjects4= [];
gdjs.Level_321Code.GDVirus_952_95FlippedObjects1= [];
gdjs.Level_321Code.GDVirus_952_95FlippedObjects2= [];
gdjs.Level_321Code.GDVirus_952_95FlippedObjects3= [];
gdjs.Level_321Code.GDVirus_952_95FlippedObjects4= [];
gdjs.Level_321Code.GDShoot_95FromObjects1= [];
gdjs.Level_321Code.GDShoot_95FromObjects2= [];
gdjs.Level_321Code.GDShoot_95FromObjects3= [];
gdjs.Level_321Code.GDShoot_95FromObjects4= [];
gdjs.Level_321Code.GDShoot_95From2Objects1= [];
gdjs.Level_321Code.GDShoot_95From2Objects2= [];
gdjs.Level_321Code.GDShoot_95From2Objects3= [];
gdjs.Level_321Code.GDShoot_95From2Objects4= [];
gdjs.Level_321Code.GDShoot_95From3Objects1= [];
gdjs.Level_321Code.GDShoot_95From3Objects2= [];
gdjs.Level_321Code.GDShoot_95From3Objects3= [];
gdjs.Level_321Code.GDShoot_95From3Objects4= [];
gdjs.Level_321Code.GDFalling_95WallObjects1= [];
gdjs.Level_321Code.GDFalling_95WallObjects2= [];
gdjs.Level_321Code.GDFalling_95WallObjects3= [];
gdjs.Level_321Code.GDFalling_95WallObjects4= [];
gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects1= [];
gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects2= [];
gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects3= [];
gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects4= [];
gdjs.Level_321Code.GDBossObjects1= [];
gdjs.Level_321Code.GDBossObjects2= [];
gdjs.Level_321Code.GDBossObjects3= [];
gdjs.Level_321Code.GDBossObjects4= [];
gdjs.Level_321Code.GDTutorial_95BossObjects1= [];
gdjs.Level_321Code.GDTutorial_95BossObjects2= [];
gdjs.Level_321Code.GDTutorial_95BossObjects3= [];
gdjs.Level_321Code.GDTutorial_95BossObjects4= [];


gdjs.Level_321Code.asyncCallback15880612 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects3[i].setAnimationName("Virus_Idle");
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects3[i].setAnimationName("Virus_Idle");
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects3[i].setAnimationName("Virus_Idle");
}
}}
gdjs.Level_321Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDVirus_952Objects2) asyncObjectsList.addObject("Virus_2", obj);
for (const obj of gdjs.Level_321Code.GDVirus_952_95FlippedObjects2) asyncObjectsList.addObject("Virus_2_Flipped", obj);
for (const obj of gdjs.Level_321Code.GDVirus_952_95WallObjects2) asyncObjectsList.addObject("Virus_2_Wall", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_321Code.asyncCallback15880612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDterminalObjects2Objects = Hashtable.newFrom({"terminal": gdjs.Level_321Code.GDterminalObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDterminal4Objects2Objects = Hashtable.newFrom({"terminal4": gdjs.Level_321Code.GDterminal4Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDterminal3Objects2Objects = Hashtable.newFrom({"terminal3": gdjs.Level_321Code.GDterminal3Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDterminal5Objects2Objects = Hashtable.newFrom({"terminal5": gdjs.Level_321Code.GDterminal5Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTime_9595CapsuleObjects2Objects = Hashtable.newFrom({"Time_Capsule": gdjs.Level_321Code.GDTime_95CapsuleObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShield_9595CapsuleObjects2Objects = Hashtable.newFrom({"Shield_Capsule": gdjs.Level_321Code.GDShield_95CapsuleObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDDeathObjects3Objects = Hashtable.newFrom({"Death": gdjs.Level_321Code.GDDeathObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Level_321Code.GDSpikeObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Level_321Code.GDSpike2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Level_321Code.GDSpike3Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Level_321Code.GDSpike4Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EffectObjects2Objects = Hashtable.newFrom({"Bullet_Effect": gdjs.Level_321Code.GDBullet_95EffectObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EffectObjects2Objects = Hashtable.newFrom({"Bullet_Effect": gdjs.Level_321Code.GDBullet_95EffectObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatformObjects3Objects = Hashtable.newFrom({"Platform": gdjs.Level_321Code.GDPlatformObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595DoorObjects3Objects = Hashtable.newFrom({"Platform_Door": gdjs.Level_321Code.GDPlatform_95DoorObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595Door2Objects3Objects = Hashtable.newFrom({"Platform_Door2": gdjs.Level_321Code.GDPlatform_95Door2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595edgesObjects3Objects = Hashtable.newFrom({"Platform_edges": gdjs.Level_321Code.GDPlatform_95edgesObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects = Hashtable.newFrom({"Platform_that_get_destroyed": gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595JumpThroughObjects3Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595MovingObjects3Objects = Hashtable.newFrom({"Platform_Moving": gdjs.Level_321Code.GDPlatform_95MovingObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Level_321Code.GDSpikeObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Level_321Code.GDSpike2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Level_321Code.GDSpike3Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Level_321Code.GDSpike4Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952Objects3Objects = Hashtable.newFrom({"Virus_2": gdjs.Level_321Code.GDVirus_952Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952_9595WallObjects3Objects = Hashtable.newFrom({"Virus_2_Wall": gdjs.Level_321Code.GDVirus_952_95WallObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952_9595FlippedObjects3Objects = Hashtable.newFrom({"Virus_2_Flipped": gdjs.Level_321Code.GDVirus_952_95FlippedObjects3});
gdjs.Level_321Code.asyncCallback9078052 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects3[i].returnVariable(gdjs.Level_321Code.GDVirus_952Objects3[i].getVariables().get("HP")).sub(1);
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects3[i].returnVariable(gdjs.Level_321Code.GDVirus_952_95WallObjects3[i].getVariables().get("HP")).sub(1);
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects3[i].returnVariable(gdjs.Level_321Code.GDVirus_952_95FlippedObjects3[i].getVariables().get("HP")).sub(1);
}
}}
gdjs.Level_321Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDVirus_952Objects2) asyncObjectsList.addObject("Virus_2", obj);
for (const obj of gdjs.Level_321Code.GDVirus_952_95FlippedObjects2) asyncObjectsList.addObject("Virus_2_Flipped", obj);
for (const obj of gdjs.Level_321Code.GDVirus_952_95WallObjects2) asyncObjectsList.addObject("Virus_2_Wall", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback9078052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Level_321Code.GDTutorial_95BossObjects2});
gdjs.Level_321Code.asyncCallback9078892 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Level_321Code.GDTutorial_95BossObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDTutorial_95BossObjects3[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDTutorial_95BossObjects3[i].returnVariable(gdjs.Level_321Code.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}}
gdjs.Level_321Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDTutorial_95BossObjects2) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback9078892(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBossObjects2Objects = Hashtable.newFrom({"Boss": gdjs.Level_321Code.GDBossObjects2});
gdjs.Level_321Code.asyncCallback11461588 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].returnVariable(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}}
gdjs.Level_321Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback11461588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952Objects2ObjectsGDgdjs_46Level_95321Code_46GDVirus_95952_9595WallObjects2ObjectsGDgdjs_46Level_95321Code_46GDVirus_95952_9595FlippedObjects2Objects = Hashtable.newFrom({"Virus_2": gdjs.Level_321Code.GDVirus_952Objects2, "Virus_2_Wall": gdjs.Level_321Code.GDVirus_952_95WallObjects2, "Virus_2_Flipped": gdjs.Level_321Code.GDVirus_952_95FlippedObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Level_321Code.GDBulletObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Level_321Code.GDTutorial_95BossObjects2});
gdjs.Level_321Code.asyncCallback16651404 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects3);
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EnemyObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EnemyObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_952Objects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_953Objects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Level_321Code.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16651404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Level_321Code.GDSpikeObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Level_321Code.GDSpike2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Level_321Code.GDSpike3Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Level_321Code.GDSpike4Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Level_321Code.GDSpikeObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Level_321Code.GDSpike2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Level_321Code.GDSpike3Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Level_321Code.GDSpike4Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Level_321Code.GDSpikeObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Level_321Code.GDSpike2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Level_321Code.GDSpike3Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Level_321Code.GDSpike4Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.asyncCallback16614740 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.Level_321Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16614740(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.asyncCallback16768372 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.Level_321Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16768372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects3Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Level_321Code.GDTutorial_95BossObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBossObjects3Objects = Hashtable.newFrom({"Boss": gdjs.Level_321Code.GDBossObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.asyncCallback16707164 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.Level_321Code.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16707164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatformObjects3Objects = Hashtable.newFrom({"Platform": gdjs.Level_321Code.GDPlatformObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595DoorObjects3Objects = Hashtable.newFrom({"Platform_Door": gdjs.Level_321Code.GDPlatform_95DoorObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595Door2Objects3Objects = Hashtable.newFrom({"Platform_Door2": gdjs.Level_321Code.GDPlatform_95Door2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595edgesObjects3Objects = Hashtable.newFrom({"Platform_edges": gdjs.Level_321Code.GDPlatform_95edgesObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects = Hashtable.newFrom({"Platform_that_get_destroyed": gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595JumpThroughObjects3Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595MovingObjects3Objects = Hashtable.newFrom({"Platform_Moving": gdjs.Level_321Code.GDPlatform_95MovingObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Level_321Code.GDSpikeObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Level_321Code.GDSpike2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Level_321Code.GDSpike3Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Level_321Code.GDSpike4Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.asyncCallback16728924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.Level_321Code.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16728924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.asyncCallback16716612 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.Level_321Code.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16716612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Level_321Code.GDTutorial_95BossObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.asyncCallback16603620 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.Level_321Code.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16603620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Level_321Code.GDTutorial_95BossObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.asyncCallback16648548 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.Level_321Code.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16648548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITIONObjects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION": gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION2Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION2": gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION3Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION3": gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION4Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION4": gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION5Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION5": gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION6Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION6": gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION7Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION7": gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION8Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION8": gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION9Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION9": gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION10Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION10": gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION11Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION11": gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595JumpThroughObjects2Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595JumpThroughObjects2Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDDustObjects2Objects = Hashtable.newFrom({"Dust": gdjs.Level_321Code.GDDustObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects = Hashtable.newFrom({"Text_Game_Over_Play_again": gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDText_9595Game_9595Over_9595Play_9595againObjects1Objects = Hashtable.newFrom({"Text_Game_Over_Play_again": gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects1});
gdjs.Level_321Code.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Down_Control"), gdjs.Level_321Code.GDDown_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("F_Control"), gdjs.Level_321Code.GDF_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("G_Control"), gdjs.Level_321Code.GDG_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Left_Control"), gdjs.Level_321Code.GDLeft_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Right_Control"), gdjs.Level_321Code.GDRight_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Space_Control"), gdjs.Level_321Code.GDSpace_95ControlObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDG_95ControlObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDG_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDF_95ControlObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDF_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDown_95ControlObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDown_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSpace_95ControlObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpace_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDLeft_95ControlObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDLeft_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDRight_95ControlObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDRight_95ControlObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Level_321Code.GDBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.Level_321Code.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.Level_321Code.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Level_321Code.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Level_321Code.GDHealth_95barObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block"), gdjs.Level_321Code.GDMove_95To_95BlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block2"), gdjs.Level_321Code.GDMove_95To_95Block2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block3"), gdjs.Level_321Code.GDMove_95To_95Block3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block4"), gdjs.Level_321Code.GDMove_95To_95Block4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block5"), gdjs.Level_321Code.GDMove_95To_95Block5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block6"), gdjs.Level_321Code.GDMove_95To_95Block6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block7"), gdjs.Level_321Code.GDMove_95To_95Block7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.Level_321Code.GDShield_95CapsuleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("TV_TUBE"), gdjs.Level_321Code.GDTV_95TUBEObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.Level_321Code.GDTime_95CapsuleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Level_321Code.GDTutorial_95BossObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBackgroundObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBackgroundObjects2[i].setYOffset(gdjs.Level_321Code.GDBackgroundObjects2[i].getYOffset() + (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTV_95TUBEObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTV_95TUBEObjects2[i].setYOffset(gdjs.Level_321Code.GDTV_95TUBEObjects2[i].getYOffset() + (-(50) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95Over_95BGObjects2[i].setXOffset(gdjs.Level_321Code.GDGame_95Over_95BGObjects2[i].getXOffset() + (-(50) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].setHeight(64);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].setWidth(64);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setHeight(64);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setWidth(64);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].setPosition((( gdjs.Level_321Code.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDShield_95SkillObjects2[0].getPointX("Count")),(( gdjs.Level_321Code.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDShield_95SkillObjects2[0].getPointY("Count")));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDHealth_95barObjects2[i].setPosition((( gdjs.Level_321Code.GDTutorial_95BossObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDTutorial_95BossObjects2[0].getPointX("Health_Bar")),(( gdjs.Level_321Code.GDTutorial_95BossObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDTutorial_95BossObjects2[0].getPointY("Health_Bar")));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration14Objects2[i].setOpacity(150);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration15Objects2[i].setOpacity(150);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTime_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTime_95CapsuleObjects2[i].setOpacity(190);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CapsuleObjects2[i].setOpacity(190);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_951Objects2[i].setScale(3);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EnemyObjects2[i].setScale(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_952Objects2[i].setScale(2.5);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_953Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_953Objects2[i].setScale(3.4);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDMove_95To_95BlockObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDMove_95To_95BlockObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDMove_95To_95Block2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDMove_95To_95Block2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDMove_95To_95Block3Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDMove_95To_95Block3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDMove_95To_95Block4Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDMove_95To_95Block4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDMove_95To_95Block5Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDMove_95To_95Block5Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDMove_95To_95Block6Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDMove_95To_95Block6Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDMove_95To_95Block7Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDMove_95To_95Block7Objects2[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Game_Over"), gdjs.Level_321Code.GDGame_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Level_321Code.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Level_321Code.GDHealth_95barObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Level_321Code.GDPortalObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.Level_321Code.GDText_95Game_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again2"), gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects2);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Level_321Code.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPortalObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95OverObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95Over_95BGObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95OverObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPortalObjects2[i].setScale(0);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}{for(var i = 0, len = gdjs.Level_321Code.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDHealth_95barObjects2[i].setOpacity(90);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].setOpacity(50);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952Objects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952Objects2[k] = gdjs.Level_321Code.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952_95WallObjects2[k] = gdjs.Level_321Code.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[k] = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Decoration"), gdjs.Level_321Code.GDDecorationObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration1"), gdjs.Level_321Code.GDDecoration1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration10"), gdjs.Level_321Code.GDDecoration10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration11"), gdjs.Level_321Code.GDDecoration11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration12"), gdjs.Level_321Code.GDDecoration12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration13"), gdjs.Level_321Code.GDDecoration13Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.Level_321Code.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.Level_321Code.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration16"), gdjs.Level_321Code.GDDecoration16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration17"), gdjs.Level_321Code.GDDecoration17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration18"), gdjs.Level_321Code.GDDecoration18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration19"), gdjs.Level_321Code.GDDecoration19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration2"), gdjs.Level_321Code.GDDecoration2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration20"), gdjs.Level_321Code.GDDecoration20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration22"), gdjs.Level_321Code.GDDecoration22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration24"), gdjs.Level_321Code.GDDecoration24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration25"), gdjs.Level_321Code.GDDecoration25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration28"), gdjs.Level_321Code.GDDecoration28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration3"), gdjs.Level_321Code.GDDecoration3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration4"), gdjs.Level_321Code.GDDecoration4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration5"), gdjs.Level_321Code.GDDecoration5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration6"), gdjs.Level_321Code.GDDecoration6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration7"), gdjs.Level_321Code.GDDecoration7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration8"), gdjs.Level_321Code.GDDecoration8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration9"), gdjs.Level_321Code.GDDecoration9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Fan"), gdjs.Level_321Code.GDFanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Level_321Code.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.Level_321Code.GDPlatformObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Level_321Code.GDPlatform_95DoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Level_321Code.GDPlatform_95Door2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Level_321Code.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.Level_321Code.GDPlatform_95edgesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.Level_321Code.GDText_95Game_95OverObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlatformObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatformObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95DoorObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95DoorObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95Door2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95Door2Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95MovingObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95MovingObjects2[i].setColor("37;37;37");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecorationObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecorationObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration1Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration1Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration2Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration3Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration3Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration4Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration4Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration5Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration5Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration6Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration6Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration7Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration7Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration8Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration8Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration9Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration9Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration10Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration10Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration11Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration11Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration12Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration12Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration13Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration13Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration14Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration15Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration16Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration16Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration17Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration17Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration18Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration18Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration19Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration19Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration20Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration20Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration22Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration22Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration24Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration24Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration25Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration25Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration28Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration28Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95Over_95BGObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDFanObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDFanObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95edgesObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95edgesObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95OverObjects2[i].setColor("255;255;255");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9319612);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Level_321Code.GDLeftObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDLeftObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDLeftObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10188980);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Level_321Code.GDLeftObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDLeftObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10162100);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Level_321Code.GDRightObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDRightObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDRightObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDRightObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDRightObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10191852);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Level_321Code.GDRightObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDRightObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDRightObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16727340);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16530996);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8189164);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11185012);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15317900);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "g"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11509604);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15265188);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "f"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14500332);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.Level_321Code.GDterminalObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.Level_321Code.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDterminalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminalObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminalObjects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDterminalObjects2[k] = gdjs.Level_321Code.GDterminalObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminalObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal4Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDterminal4Objects2[k] = gdjs.Level_321Code.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal4Objects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9325508);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Level_321Code.GDPortalObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
/* Reuse gdjs.Level_321Code.GDterminalObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPortalObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPortalObjects2[i].getBehavior("Tween").addObjectScaleTween("Portal", 4, 4, "bouncePast", 800, false, true);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPortalObjects2[i].setAnimationName("Portal");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDterminalObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDterminalObjects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.Level_321Code.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDterminal4Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal4Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDterminal4Objects2[k] = gdjs.Level_321Code.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal4Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16771180);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
/* Reuse gdjs.Level_321Code.GDterminal4Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDterminal4Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDterminal4Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(10);
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Level_321Code.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDterminal3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal3Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDterminal3Objects2[k] = gdjs.Level_321Code.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal3Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16690164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
/* Reuse gdjs.Level_321Code.GDterminal3Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDterminal3Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDterminal3Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.Level_321Code.GDterminal5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDterminal5Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal5Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal5Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDterminal5Objects2[k] = gdjs.Level_321Code.GDterminal5Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal5Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16734308);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
/* Reuse gdjs.Level_321Code.GDterminal5Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDterminal5Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDterminal5Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16757380);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Jump.mp3", false, 50, gdjs.randomFloatInRange(0.8, 1.2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16766460);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getAnimationFrame() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16574668);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getAnimationFrame() == 4 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9330556);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.Level_321Code.GDTime_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTime_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16668596);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.Level_321Code.GDShield_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShield_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16654636);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16732308);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{

gdjs.Level_321Code.GDDeathObjects2.length = 0;

gdjs.Level_321Code.GDPlayerObjects2.length = 0;

gdjs.Level_321Code.GDSpikeObjects2.length = 0;

gdjs.Level_321Code.GDSpike2Objects2.length = 0;

gdjs.Level_321Code.GDSpike3Objects2.length = 0;

gdjs.Level_321Code.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level_321Code.GDDeathObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlayerObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpikeObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpike2Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike3Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.Level_321Code.GDDeathObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDDeathObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDDeathObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDDeathObjects2_1final.indexOf(gdjs.Level_321Code.GDDeathObjects3[j]) === -1 )
            gdjs.Level_321Code.GDDeathObjects2_1final.push(gdjs.Level_321Code.GDDeathObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Level_321Code.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpikeObjects2_1final.indexOf(gdjs.Level_321Code.GDSpikeObjects3[j]) === -1 )
            gdjs.Level_321Code.GDSpikeObjects2_1final.push(gdjs.Level_321Code.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Level_321Code.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike2Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike2Objects2_1final.push(gdjs.Level_321Code.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Level_321Code.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike3Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike3Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike3Objects2_1final.push(gdjs.Level_321Code.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Level_321Code.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike4Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike4Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike4Objects2_1final.push(gdjs.Level_321Code.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDDeathObjects2_1final, gdjs.Level_321Code.GDDeathObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2_1final, gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpikeObjects2_1final, gdjs.Level_321Code.GDSpikeObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike2Objects2_1final, gdjs.Level_321Code.GDSpike2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike3Objects2_1final, gdjs.Level_321Code.GDSpike3Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike4Objects2_1final, gdjs.Level_321Code.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16624556);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 100, 0.8);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.Level_321Code.GDterminalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminalObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminalObjects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDterminalObjects2[k] = gdjs.Level_321Code.GDterminalObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminalObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9059140);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.5, 0.7));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.Level_321Code.GDterminal5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal5Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal5Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDterminal5Objects2[k] = gdjs.Level_321Code.GDterminal5Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal5Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9075196);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.9, 1.1));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Level_321Code.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal3Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDterminal3Objects2[k] = gdjs.Level_321Code.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16689004);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.9, 1.1));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.Level_321Code.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal4Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDterminal4Objects2[k] = gdjs.Level_321Code.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal4Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16728652);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.75, 0.95));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Shoot") > 1.3;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Level_321Code.GDPlayerObjects2[i].isFlippedX()) ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9080164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
gdjs.Level_321Code.GDBullet_95EffectObjects2.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, gdjs.randomFloatInRange(1.2, 1.5));
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDPlayerObjects2[i].getPointX("Shoot")), (gdjs.Level_321Code.GDPlayerObjects2[i].getPointY("Shoot")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, 0, 900, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EffectObjects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointX("Shoot")), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointY("Shoot")), "");
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Shoot") > 1.5;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].isFlippedX() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16593300);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
gdjs.Level_321Code.GDBullet_95EffectObjects2.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, gdjs.randomFloatInRange(1.2, 1.5));
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDPlayerObjects2[i].getPointX("Shoot")), (gdjs.Level_321Code.GDPlayerObjects2[i].getPointY("Shoot")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, -(180), 900, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EffectObjects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointX("Shoot")), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointY("Shoot")), "");
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}}

}


{

gdjs.Level_321Code.GDBulletObjects2.length = 0;

gdjs.Level_321Code.GDPlatformObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95DoorObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95Door2Objects2.length = 0;

gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95MovingObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95edgesObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2.length = 0;

gdjs.Level_321Code.GDSpikeObjects2.length = 0;

gdjs.Level_321Code.GDSpike2Objects2.length = 0;

gdjs.Level_321Code.GDSpike3Objects2.length = 0;

gdjs.Level_321Code.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level_321Code.GDBulletObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatformObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpikeObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpike2Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike3Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.Level_321Code.GDPlatformObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatformObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatformObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatformObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatformObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatformObjects2_1final.push(gdjs.Level_321Code.GDPlatformObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Level_321Code.GDPlatform_95DoorObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595DoorObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95DoorObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95DoorObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95DoorObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Level_321Code.GDPlatform_95Door2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595Door2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95Door2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95Door2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final.push(gdjs.Level_321Code.GDPlatform_95Door2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.Level_321Code.GDPlatform_95edgesObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595edgesObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95edgesObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95edgesObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95edgesObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595JumpThroughObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Level_321Code.GDPlatform_95MovingObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595MovingObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95MovingObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95MovingObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95MovingObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Level_321Code.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpikeObjects2_1final.indexOf(gdjs.Level_321Code.GDSpikeObjects3[j]) === -1 )
            gdjs.Level_321Code.GDSpikeObjects2_1final.push(gdjs.Level_321Code.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Level_321Code.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike2Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike2Objects2_1final.push(gdjs.Level_321Code.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Level_321Code.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike3Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike3Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike3Objects2_1final.push(gdjs.Level_321Code.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Level_321Code.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike4Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike4Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike4Objects2_1final.push(gdjs.Level_321Code.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBulletObjects2_1final, gdjs.Level_321Code.GDBulletObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatformObjects2_1final, gdjs.Level_321Code.GDPlatformObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final, gdjs.Level_321Code.GDPlatform_95DoorObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final, gdjs.Level_321Code.GDPlatform_95Door2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final, gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final, gdjs.Level_321Code.GDPlatform_95MovingObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final, gdjs.Level_321Code.GDPlatform_95edgesObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final, gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpikeObjects2_1final, gdjs.Level_321Code.GDSpikeObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike2Objects2_1final, gdjs.Level_321Code.GDSpike2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike3Objects2_1final, gdjs.Level_321Code.GDSpike3Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike4Objects2_1final, gdjs.Level_321Code.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Level_321Code.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Level_321Code.GDBulletObjects2.length = 0;

gdjs.Level_321Code.GDVirus_952Objects2.length = 0;

gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length = 0;

gdjs.Level_321Code.GDVirus_952_95WallObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level_321Code.GDBulletObjects2_1final.length = 0;
gdjs.Level_321Code.GDVirus_952Objects2_1final.length = 0;
gdjs.Level_321Code.GDVirus_952_95FlippedObjects2_1final.length = 0;
gdjs.Level_321Code.GDVirus_952_95WallObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDVirus_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDVirus_952Objects2_1final.indexOf(gdjs.Level_321Code.GDVirus_952Objects3[j]) === -1 )
            gdjs.Level_321Code.GDVirus_952Objects2_1final.push(gdjs.Level_321Code.GDVirus_952Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952_9595WallObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDVirus_952_95WallObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDVirus_952_95WallObjects2_1final.indexOf(gdjs.Level_321Code.GDVirus_952_95WallObjects3[j]) === -1 )
            gdjs.Level_321Code.GDVirus_952_95WallObjects2_1final.push(gdjs.Level_321Code.GDVirus_952_95WallObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952_9595FlippedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBulletObjects2_1final.indexOf(gdjs.Level_321Code.GDBulletObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBulletObjects2_1final.push(gdjs.Level_321Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDVirus_952_95FlippedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDVirus_952_95FlippedObjects2_1final.indexOf(gdjs.Level_321Code.GDVirus_952_95FlippedObjects3[j]) === -1 )
            gdjs.Level_321Code.GDVirus_952_95FlippedObjects2_1final.push(gdjs.Level_321Code.GDVirus_952_95FlippedObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBulletObjects2_1final, gdjs.Level_321Code.GDBulletObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDVirus_952Objects2_1final, gdjs.Level_321Code.GDVirus_952Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDVirus_952_95FlippedObjects2_1final, gdjs.Level_321Code.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDVirus_952_95WallObjects2_1final, gdjs.Level_321Code.GDVirus_952_95WallObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Level_321Code.GDBullet_95EffectObjects2);
/* Reuse gdjs.Level_321Code.GDVirus_952Objects2 */
/* Reuse gdjs.Level_321Code.GDVirus_952_95FlippedObjects2 */
/* Reuse gdjs.Level_321Code.GDVirus_952_95WallObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].setAnimationName("Virus_Hurt");
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].setAnimationName("Virus_Hurt");
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].setAnimationName("Virus_Hurt");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952Objects2[i].getVariableNumber(gdjs.Level_321Code.GDVirus_952Objects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952Objects2[k] = gdjs.Level_321Code.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getVariableNumber(gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952_95WallObjects2[k] = gdjs.Level_321Code.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getVariableNumber(gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[k] = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16736388);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDVirus_952Objects2 */
/* Reuse gdjs.Level_321Code.GDVirus_952_95FlippedObjects2 */
/* Reuse gdjs.Level_321Code.GDVirus_952_95WallObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Level_321Code.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16710324);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Level_321Code.GDBullet_95EffectObjects2);
/* Reuse gdjs.Level_321Code.GDTutorial_95BossObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTutorial_95BossObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTutorial_95BossObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTutorial_95BossObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTutorial_95BossObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16718084);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBossObjects2 */
/* Reuse gdjs.Level_321Code.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Level_321Code.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952Objects2ObjectsGDgdjs_46Level_95321Code_46GDVirus_95952_9595WallObjects2ObjectsGDgdjs_46Level_95321Code_46GDVirus_95952_9595FlippedObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952Objects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952Objects2[k] = gdjs.Level_321Code.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952_95WallObjects2[k] = gdjs.Level_321Code.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[k] = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16619092);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Level_321Code.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Level_321Code.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBulletObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16761372);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.Level_321Code.GDBullet_95EnemyObjects2.length = 0;

gdjs.Level_321Code.GDSpikeObjects2.length = 0;

gdjs.Level_321Code.GDSpike2Objects2.length = 0;

gdjs.Level_321Code.GDSpike3Objects2.length = 0;

gdjs.Level_321Code.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpikeObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpike2Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike3Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Level_321Code.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.push(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpikeObjects2_1final.indexOf(gdjs.Level_321Code.GDSpikeObjects3[j]) === -1 )
            gdjs.Level_321Code.GDSpikeObjects2_1final.push(gdjs.Level_321Code.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Level_321Code.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.push(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike2Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike2Objects2_1final.push(gdjs.Level_321Code.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Level_321Code.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.push(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike3Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike3Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike3Objects2_1final.push(gdjs.Level_321Code.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Level_321Code.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final.push(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike4Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike4Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike4Objects2_1final.push(gdjs.Level_321Code.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95EnemyObjects2_1final, gdjs.Level_321Code.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpikeObjects2_1final, gdjs.Level_321Code.GDSpikeObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike2Objects2_1final, gdjs.Level_321Code.GDSpike2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike3Objects2_1final, gdjs.Level_321Code.GDSpike3Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike4Objects2_1final, gdjs.Level_321Code.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBullet_95EnemyObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Level_321Code.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.Level_321Code.GDSpikeObjects2.length = 0;

gdjs.Level_321Code.GDSpike2Objects2.length = 0;

gdjs.Level_321Code.GDSpike3Objects2.length = 0;

gdjs.Level_321Code.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpikeObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpike2Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike3Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Level_321Code.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpikeObjects2_1final.indexOf(gdjs.Level_321Code.GDSpikeObjects3[j]) === -1 )
            gdjs.Level_321Code.GDSpikeObjects2_1final.push(gdjs.Level_321Code.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Level_321Code.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike2Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike2Objects2_1final.push(gdjs.Level_321Code.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Level_321Code.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike3Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike3Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike3Objects2_1final.push(gdjs.Level_321Code.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Level_321Code.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike4Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike4Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike4Objects2_1final.push(gdjs.Level_321Code.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_1final, gdjs.Level_321Code.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpikeObjects2_1final, gdjs.Level_321Code.GDSpikeObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike2Objects2_1final, gdjs.Level_321Code.GDSpike2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike3Objects2_1final, gdjs.Level_321Code.GDSpike3Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike4Objects2_1final, gdjs.Level_321Code.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBullet_95Enemy_952Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_952Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Level_321Code.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.Level_321Code.GDSpikeObjects2.length = 0;

gdjs.Level_321Code.GDSpike2Objects2.length = 0;

gdjs.Level_321Code.GDSpike3Objects2.length = 0;

gdjs.Level_321Code.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpikeObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpike2Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike3Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Level_321Code.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpikeObjects2_1final.indexOf(gdjs.Level_321Code.GDSpikeObjects3[j]) === -1 )
            gdjs.Level_321Code.GDSpikeObjects2_1final.push(gdjs.Level_321Code.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Level_321Code.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike2Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike2Objects2_1final.push(gdjs.Level_321Code.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Level_321Code.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike3Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike3Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike3Objects2_1final.push(gdjs.Level_321Code.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Level_321Code.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike4Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike4Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike4Objects2_1final.push(gdjs.Level_321Code.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_1final, gdjs.Level_321Code.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpikeObjects2_1final, gdjs.Level_321Code.GDSpikeObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike2Objects2_1final, gdjs.Level_321Code.GDSpike2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike3Objects2_1final, gdjs.Level_321Code.GDSpike3Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike4Objects2_1final, gdjs.Level_321Code.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBullet_95Enemy_953Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_953Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_953Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.Level_321Code.GDBullet_95EnemyObjects2.length = 0;

gdjs.Level_321Code.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.Level_321Code.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.Level_321Code.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final.length = 0;
gdjs.Level_321Code.GDPlayerObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final.indexOf(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final.push(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_2final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_2final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final.push(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_2final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_2final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final.push(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_2final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_2final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final, gdjs.Level_321Code.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final, gdjs.Level_321Code.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final, gdjs.Level_321Code.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2_2final, gdjs.Level_321Code.GDPlayerObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16632212);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.Level_321Code.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.Level_321Code.GDBullet_95EnemyObjects2.length = 0;

gdjs.Level_321Code.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.Level_321Code.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.Level_321Code.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final.length = 0;
gdjs.Level_321Code.GDPlayerObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final.indexOf(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final.push(gdjs.Level_321Code.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_2final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_2final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final.push(gdjs.Level_321Code.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_2final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_2final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final.push(gdjs.Level_321Code.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_2final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_2final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95EnemyObjects2_2final, gdjs.Level_321Code.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95Enemy_952Objects2_2final, gdjs.Level_321Code.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95Enemy_953Objects2_2final, gdjs.Level_321Code.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2_2final, gdjs.Level_321Code.GDPlayerObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16768236);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBullet_95EnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
/* Reuse gdjs.Level_321Code.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].returnVariable(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.Level_321Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.Level_321Code.GDBossObjects2.length = 0;

gdjs.Level_321Code.GDPlayerObjects2.length = 0;

gdjs.Level_321Code.GDTutorial_95BossObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects2_2final.length = 0;
gdjs.Level_321Code.GDPlayerObjects2_2final.length = 0;
gdjs.Level_321Code.GDTutorial_95BossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Level_321Code.GDTutorial_95BossObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_2final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_2final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Level_321Code.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDTutorial_95BossObjects2_2final.push(gdjs.Level_321Code.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBossObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_2final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_2final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2_2final, gdjs.Level_321Code.GDBossObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2_2final, gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDTutorial_95BossObjects2_2final, gdjs.Level_321Code.GDTutorial_95BossObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16719964);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
/* Reuse gdjs.Level_321Code.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].returnVariable(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.Level_321Code.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.Level_321Code.GDBullet_95Enemy_951Objects2.length = 0;

gdjs.Level_321Code.GDPlatformObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95DoorObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95Door2Objects2.length = 0;

gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95MovingObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95edgesObjects2.length = 0;

gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2.length = 0;

gdjs.Level_321Code.GDSpikeObjects2.length = 0;

gdjs.Level_321Code.GDSpike2Objects2.length = 0;

gdjs.Level_321Code.GDSpike3Objects2.length = 0;

gdjs.Level_321Code.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.length = 0;
gdjs.Level_321Code.GDPlatformObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpikeObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpike2Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike3Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.Level_321Code.GDPlatformObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatformObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatformObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatformObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatformObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatformObjects2_1final.push(gdjs.Level_321Code.GDPlatformObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Level_321Code.GDPlatform_95DoorObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595DoorObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95DoorObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95DoorObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95DoorObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Level_321Code.GDPlatform_95Door2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595Door2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95Door2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95Door2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final.push(gdjs.Level_321Code.GDPlatform_95Door2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.Level_321Code.GDPlatform_95edgesObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595edgesObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95edgesObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95edgesObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95edgesObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595JumpThroughObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Level_321Code.GDPlatform_95MovingObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595MovingObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlatform_95MovingObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final.indexOf(gdjs.Level_321Code.GDPlatform_95MovingObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final.push(gdjs.Level_321Code.GDPlatform_95MovingObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Level_321Code.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpikeObjects2_1final.indexOf(gdjs.Level_321Code.GDSpikeObjects3[j]) === -1 )
            gdjs.Level_321Code.GDSpikeObjects2_1final.push(gdjs.Level_321Code.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Level_321Code.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike2Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike2Objects2_1final.push(gdjs.Level_321Code.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Level_321Code.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike3Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike3Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike3Objects2_1final.push(gdjs.Level_321Code.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Level_321Code.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Level_321Code.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike4Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike4Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike4Objects2_1final.push(gdjs.Level_321Code.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBullet_95Enemy_951Objects2_1final, gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatformObjects2_1final, gdjs.Level_321Code.GDPlatformObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95DoorObjects2_1final, gdjs.Level_321Code.GDPlatform_95DoorObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95Door2Objects2_1final, gdjs.Level_321Code.GDPlatform_95Door2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2_1final, gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95MovingObjects2_1final, gdjs.Level_321Code.GDPlatform_95MovingObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95edgesObjects2_1final, gdjs.Level_321Code.GDPlatform_95edgesObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2_1final, gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpikeObjects2_1final, gdjs.Level_321Code.GDSpikeObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike2Objects2_1final, gdjs.Level_321Code.GDSpike2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike3Objects2_1final, gdjs.Level_321Code.GDSpike3Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike4Objects2_1final, gdjs.Level_321Code.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBullet_95Enemy_951Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16596308);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBullet_95Enemy_951Objects2 */
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.Level_321Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16728780);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDBullet_95Enemy_951Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
/* Reuse gdjs.Level_321Code.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].returnVariable(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.Level_321Code.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Level_321Code.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16743996);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.Level_321Code.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Level_321Code.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTutorial_9595BossObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16735132);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
/* Reuse gdjs.Level_321Code.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].returnVariable(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.Level_321Code.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Level_321Code.GDBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration"), gdjs.Level_321Code.GDDecorationObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration1"), gdjs.Level_321Code.GDDecoration1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration10"), gdjs.Level_321Code.GDDecoration10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration11"), gdjs.Level_321Code.GDDecoration11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration12"), gdjs.Level_321Code.GDDecoration12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.Level_321Code.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.Level_321Code.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration16"), gdjs.Level_321Code.GDDecoration16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration17"), gdjs.Level_321Code.GDDecoration17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration18"), gdjs.Level_321Code.GDDecoration18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration19"), gdjs.Level_321Code.GDDecoration19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration2"), gdjs.Level_321Code.GDDecoration2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration20"), gdjs.Level_321Code.GDDecoration20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration22"), gdjs.Level_321Code.GDDecoration22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration24"), gdjs.Level_321Code.GDDecoration24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration25"), gdjs.Level_321Code.GDDecoration25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration28"), gdjs.Level_321Code.GDDecoration28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration3"), gdjs.Level_321Code.GDDecoration3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration4"), gdjs.Level_321Code.GDDecoration4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration5"), gdjs.Level_321Code.GDDecoration5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration6"), gdjs.Level_321Code.GDDecoration6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration7"), gdjs.Level_321Code.GDDecoration7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration9"), gdjs.Level_321Code.GDDecoration9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Falling_Wall"), gdjs.Level_321Code.GDFalling_95WallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Falling_Wall_Chain"), gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects2);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Level_321Code.GDLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.Level_321Code.GDPlatformObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Boss"), gdjs.Level_321Code.GDPlatform_95BossObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Level_321Code.GDPlatform_95DoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Level_321Code.GDPlatform_95Door2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Level_321Code.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.Level_321Code.GDPlatform_95edgesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Level_321Code.GDRightObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Level_321Code.GDSpikeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Level_321Code.GDSpike2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Level_321Code.GDSpike3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Level_321Code.GDSpike4Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.Level_321Code.GDterminalObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Level_321Code.GDterminal3Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.Level_321Code.GDterminal4Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.Level_321Code.GDterminal5Objects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlatformObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatformObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95DoorObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95DoorObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95Door2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95Door2Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95MovingObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95MovingObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95BossObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95BossObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95edgesObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95edgesObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDFalling_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDFalling_95WallObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSpikeObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpikeObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSpike2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpike2Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSpike3Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpike3Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDSpike4Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDSpike4Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBackgroundObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBackgroundObjects2[i].setZOrder(-(20));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecorationObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecorationObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration1Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration1Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration3Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration3Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration2Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration4Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration4Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration5Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration5Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration6Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration7Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration7Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration9Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration9Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration10Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration10Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration11Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration11Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration12Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration12Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration14Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration15Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration16Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration16Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration17Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration17Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration18Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration18Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration19Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration19Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration20Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration20Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration22Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration22Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration24Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration24Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration25Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration25Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDDecoration28Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDecoration28Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDLeftObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDRightObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDRightObjects2[i].setZOrder(-(1));
}
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{for(var i = 0, len = gdjs.Level_321Code.GDterminalObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDterminalObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDterminal5Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDterminal5Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDterminal3Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDterminal3Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDterminal4Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDterminal4Objects2[i].setZOrder(-(1));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION"), gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITIONObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION2"), gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION3"), gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION4"), gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION4Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION5"), gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION5Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION6"), gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION6Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION7"), gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION7Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION8"), gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION8Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION9"), gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION9Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION10"), gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION10Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION11"), gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION11Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2.length !== 0 ? gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2[0] : null), true, "", 0);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595JumpThroughObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16733588);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2[i].setOpacity(150);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlatform_9595JumpThroughObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9064508);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2[i].setOpacity(255);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Walk - No Weapon");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Walk - No Weapon");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Grab");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isGrabbingPlatform() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16585812);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Grab");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16665284);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16703012);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16646340);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Walk - Pistol");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Walk - Pistol");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Jump - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16770316);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16711660);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16684820);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level_321Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16715956);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16716260);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.Level_321Code.GDDustObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDDustObjects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointX("Dust")), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointY("Dust")), "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Level_321Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayerObjects2[k] = gdjs.Level_321Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16691372);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.Level_321Code.GDDustObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDDustObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDustObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level_321Code.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Level_321Code.GDBullet_95EffectObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.Level_321Code.GDDustObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDDustObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDDustObjects2[i].setPosition((( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointX("Dust")),(( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getPointY("Dust")));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBullet_95EffectObjects2[i].setPosition((( gdjs.Level_321Code.GDBulletObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDBulletObjects2[0].getCenterXInScene()),(( gdjs.Level_321Code.GDBulletObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDBulletObjects2[0].getCenterYInScene()));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16748668);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Level_321Code.GDCursorObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDCursorObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDCursorObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16617756);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Level_321Code.GDCursorObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDCursorObjects2[i].setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11595292);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2[i].setColor("163;163;163");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDText_9595Game_9595Over_9595Play_9595againObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9063012);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects1[i].setColor("255;255;255");
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDDeathObjects3Objects = Hashtable.newFrom({"Death": gdjs.Level_321Code.GDDeathObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Level_321Code.GDSpikeObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Level_321Code.GDSpike2Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Level_321Code.GDSpike3Objects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects3});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Level_321Code.GDSpike4Objects3});
gdjs.Level_321Code.asyncCallback9082204 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}
gdjs.Level_321Code.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback9082204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTime_9595CapsuleObjects2Objects = Hashtable.newFrom({"Time_Capsule": gdjs.Level_321Code.GDTime_95CapsuleObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShield_9595CapsuleObjects2Objects = Hashtable.newFrom({"Shield_Capsule": gdjs.Level_321Code.GDShield_95CapsuleObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShield_9595CountObjects2Objects = Hashtable.newFrom({"Shield_Count": gdjs.Level_321Code.GDShield_95CountObjects2});
gdjs.Level_321Code.eventsList14 = function(runtimeScene) {

{



}


{



}


{



}


{



}


{



}


{



}


{

gdjs.Level_321Code.GDDeathObjects2.length = 0;

gdjs.Level_321Code.GDPlayerObjects2.length = 0;

gdjs.Level_321Code.GDSpikeObjects2.length = 0;

gdjs.Level_321Code.GDSpike2Objects2.length = 0;

gdjs.Level_321Code.GDSpike3Objects2.length = 0;

gdjs.Level_321Code.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level_321Code.GDDeathObjects2_1final.length = 0;
gdjs.Level_321Code.GDPlayerObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpikeObjects2_1final.length = 0;
gdjs.Level_321Code.GDSpike2Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike3Objects2_1final.length = 0;
gdjs.Level_321Code.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.Level_321Code.GDDeathObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDDeathObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDDeathObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDDeathObjects2_1final.indexOf(gdjs.Level_321Code.GDDeathObjects3[j]) === -1 )
            gdjs.Level_321Code.GDDeathObjects2_1final.push(gdjs.Level_321Code.GDDeathObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Level_321Code.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpikeObjects2_1final.indexOf(gdjs.Level_321Code.GDSpikeObjects3[j]) === -1 )
            gdjs.Level_321Code.GDSpikeObjects2_1final.push(gdjs.Level_321Code.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Level_321Code.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike2Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike2Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike2Objects2_1final.push(gdjs.Level_321Code.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Level_321Code.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike3Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike3Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike3Objects2_1final.push(gdjs.Level_321Code.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Level_321Code.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects3Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDPlayerObjects2_1final.indexOf(gdjs.Level_321Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level_321Code.GDPlayerObjects2_1final.push(gdjs.Level_321Code.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Level_321Code.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDSpike4Objects2_1final.indexOf(gdjs.Level_321Code.GDSpike4Objects3[j]) === -1 )
            gdjs.Level_321Code.GDSpike4Objects2_1final.push(gdjs.Level_321Code.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDDeathObjects2_1final, gdjs.Level_321Code.GDDeathObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDPlayerObjects2_1final, gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpikeObjects2_1final, gdjs.Level_321Code.GDSpikeObjects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike2Objects2_1final, gdjs.Level_321Code.GDSpike2Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike3Objects2_1final, gdjs.Level_321Code.GDSpike3Objects2);
gdjs.copyArray(gdjs.Level_321Code.GDSpike4Objects2_1final, gdjs.Level_321Code.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Level_321Code.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over"), gdjs.Level_321Code.GDGame_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Level_321Code.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Level_321Code.GDHealth_95barObjects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.Level_321Code.GDText_95Game_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95OverObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95Over_95BGObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDCursorObjects2[i].hide(false);
}
}{gdjs.evtTools.input.showCursor(runtimeScene);
}
{ //Subevents
gdjs.Level_321Code.eventsList13(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.Level_321Code.GDTime_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDTime_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16591244);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDTime_95CapsuleObjects2 */
{runtimeScene.getScene().getVariables().get("Secs").add(5);
}{for(var i = 0, len = gdjs.Level_321Code.GDTime_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTime_95CapsuleObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.Level_321Code.GDShield_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShield_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16742068);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDShield_95CapsuleObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.Level_321Code.GDShield_95CountObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDShield_9595CountObjects2Objects, (( gdjs.Level_321Code.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDShield_95SkillObjects2[0].getPointX("Count")), (( gdjs.Level_321Code.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDShield_95SkillObjects2[0].getPointY("Count")), "UI");
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].getBehavior("Tween").addObjectOpacityTween("Show", 255, "linear", 1500, false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].returnVariable(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CapsuleObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
/* Reuse gdjs.Level_321Code.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level_321Code.GDShield_95SkillObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_321Code.GDShield_95SkillObjects2[0].getVariables()).getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Level_321Code.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDShield_95SkillObjects2[k] = gdjs.Level_321Code.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
/* Reuse gdjs.Level_321Code.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].setString("0");
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].setOpacity(50);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9081452);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}{/* Unknown object - skipped. */}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects1[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects1});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION5Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION5": gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION10Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION10": gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION6Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION6": gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION7Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION7": gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects = Hashtable.newFrom({"Text_Game_Over_Play_again": gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2});
gdjs.Level_321Code.asyncCallback15763116 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 1", false);
}}
gdjs.Level_321Code.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback15763116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952Objects2Objects = Hashtable.newFrom({"Virus_2": gdjs.Level_321Code.GDVirus_952Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects2});
gdjs.Level_321Code.asyncCallback15928932 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects3);

{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects3[i].setAnimationName("Virus_Idle");
}
}}
gdjs.Level_321Code.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDVirus_952Objects2) asyncObjectsList.addObject("Virus_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback15928932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList17 = function(runtimeScene) {

{

/* Reuse gdjs.Level_321Code.GDVirus_952Objects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952Objects2[i].isCurrentAnimationName("Virus_Idle") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952Objects2[k] = gdjs.Level_321Code.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15418636);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
/* Reuse gdjs.Level_321Code.GDVirus_952Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].getBehavior("Tween").addObjectOpacityTween("Detect", 255, "easeInQuad", 300, false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].setAnimationName("Virus_Shoot");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.5);
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDVirus_952Objects2[i].getPointX("Shoot")), (gdjs.Level_321Code.GDVirus_952Objects2[i].getPointY("Shoot")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterYInScene()), 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952_9595WallObjects2Objects = Hashtable.newFrom({"Virus_2_Wall": gdjs.Level_321Code.GDVirus_952_95WallObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects2});
gdjs.Level_321Code.asyncCallback11244980 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects3[i].setAnimationName("Virus_Idle");
}
}}
gdjs.Level_321Code.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDVirus_952_95WallObjects2) asyncObjectsList.addObject("Virus_2_Wall", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback11244980(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList19 = function(runtimeScene) {

{

/* Reuse gdjs.Level_321Code.GDVirus_952_95WallObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].isCurrentAnimationName("Virus_Idle") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952_95WallObjects2[k] = gdjs.Level_321Code.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952_95WallObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9093300);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
/* Reuse gdjs.Level_321Code.GDVirus_952_95WallObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getBehavior("Tween").addObjectOpacityTween("Detect", 255, "easeInQuad", 300, false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].setAnimationName("Virus_Shoot");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.5);
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getPointX("Shoot")), (gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].getPointY("Shoot")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterYInScene()), 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952_9595FlippedObjects2Objects = Hashtable.newFrom({"Virus_2_Flipped": gdjs.Level_321Code.GDVirus_952_95FlippedObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Level_321Code.GDBullet_95Enemy_951Objects2});
gdjs.Level_321Code.asyncCallback9105100 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects3[i].setAnimationName("Virus_Idle");
}
}}
gdjs.Level_321Code.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDVirus_952_95FlippedObjects2) asyncObjectsList.addObject("Virus_2_Flipped", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback9105100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList21 = function(runtimeScene) {

{

/* Reuse gdjs.Level_321Code.GDVirus_952_95FlippedObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].isCurrentAnimationName("Virus_Idle") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[k] = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9093884);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Level_321Code.GDBullet_95Enemy_951Objects2);
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
/* Reuse gdjs.Level_321Code.GDVirus_952_95FlippedObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getBehavior("Tween").addObjectOpacityTween("Detect", 255, "easeInQuad", 300, false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].setAnimationName("Virus_Shoot");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.5);
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getPointX("Shoot")), (gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].getPointY("Shoot")), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95951Objects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterYInScene()), 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDFalling_9595WallObjects2Objects = Hashtable.newFrom({"Falling_Wall": gdjs.Level_321Code.GDFalling_95WallObjects2});
gdjs.Level_321Code.eventsList22 = function(runtimeScene) {

{

/* Reuse gdjs.Level_321Code.GDFalling_95WallObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDFalling_95WallObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDFalling_95WallObjects2[i].getBehavior("ShakeObject_PositionAngleScale").IsShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDFalling_95WallObjects2[k] = gdjs.Level_321Code.GDFalling_95WallObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDFalling_95WallObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDFalling_95WallObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDFalling_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDFalling_95WallObjects2[i].getBehavior("Tween").addObjectPositionYTween("Slam", (gdjs.RuntimeObject.getVariableNumber(gdjs.Level_321Code.GDFalling_95WallObjects2[i].getVariables().get("Smach_here"))), "easeInQuad", 415, false);
}
}}

}


};gdjs.Level_321Code.asyncCallback15328612 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Platform_Moving"), gdjs.Level_321Code.GDPlatform_95MovingObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95MovingObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95MovingObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", -(832), 512, "linear", 2500, false);
}
}}
gdjs.Level_321Code.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDPlatform_95MovingObjects2) asyncObjectsList.addObject("Platform_Moving", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_321Code.asyncCallback15328612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.asyncCallback16461508 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Platform_Moving"), gdjs.Level_321Code.GDPlatform_95MovingObjects3);

{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95MovingObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95MovingObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", 64, 512, "linear", 2500, false);
}
}}
gdjs.Level_321Code.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDPlatform_95MovingObjects2) asyncObjectsList.addObject("Platform_Moving", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16461508(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.Level_321Code.GDPortalObjects2});
gdjs.Level_321Code.asyncCallback16629092 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Thankyouforplaying", false);
}}
gdjs.Level_321Code.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16629092(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level_321Code.GDPlayerObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION9Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION9": gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2});
gdjs.Level_321Code.asyncCallback7798836 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Level_321Code.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_321Code.asyncCallback7798836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.asyncCallback12774108 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);
{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].getBehavior("Tween").addObjectScaleTween("Spawn", 0.7, 0.7, "bounce", 650, false, false);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_321Code.asyncCallback12774108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Level_321Code.GDBullet_95EnemyObjects4});
gdjs.Level_321Code.asyncCallback15505108 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects4);

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Level_321Code.GDBullet_95EnemyObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.35);
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects, 0, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects, 35, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects, 65, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects, 95, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects, 125, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects, 155, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595EnemyObjects4Objects, 180, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Level_321Code.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level_321Code.GDBossObjects3) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback15505108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16267644);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level_321Code.asyncCallback16465356 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);

gdjs.copyArray(runtimeScene.getObjects("Move_To_Block"), gdjs.Level_321Code.GDMove_95To_95BlockObjects3);
{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Level_321Code.GDMove_95To_95BlockObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95BlockObjects3[0].getCenterXInScene()), (( gdjs.Level_321Code.GDMove_95To_95BlockObjects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95BlockObjects3[0].getCenterYInScene()), "linear", 1500, false);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16465356(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects4});
gdjs.Level_321Code.asyncCallback16434380 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects4);

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.35);
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects, (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterYInScene()), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Level_321Code.eventsList31 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level_321Code.GDBossObjects3) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16434380(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16434284);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList31(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level_321Code.asyncCallback16457444 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);

gdjs.copyArray(runtimeScene.getObjects("Move_To_Block3"), gdjs.Level_321Code.GDMove_95To_95Block3Objects3);
{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Level_321Code.GDMove_95To_95Block3Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block3Objects3[0].getCenterXInScene()), (( gdjs.Level_321Code.GDMove_95To_95Block3Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block3Objects3[0].getCenterYInScene()), "linear", 650, false);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList33 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16457444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects4});
gdjs.Level_321Code.asyncCallback15446084 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects4);

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.35);
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects, (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterYInScene()), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects, (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterYInScene()), 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Level_321Code.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level_321Code.GDBossObjects3) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback15446084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList35 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16458524);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level_321Code.asyncCallback9046172 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);

gdjs.copyArray(runtimeScene.getObjects("Move_To_Block2"), gdjs.Level_321Code.GDMove_95To_95Block2Objects3);
{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Level_321Code.GDMove_95To_95Block2Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block2Objects3[0].getCenterXInScene()), (( gdjs.Level_321Code.GDMove_95To_95Block2Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block2Objects3[0].getCenterYInScene()), "linear", 650, false);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList35(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList36 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback9046172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.asyncCallback16448236 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects4);

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.35);
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, 0, 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, -(30), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, -(60), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, -(90), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, -(120), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, -(150), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, 180, 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Level_321Code.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level_321Code.GDBossObjects3) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16448236(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList38 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16438204);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level_321Code.asyncCallback16422548 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);

gdjs.copyArray(runtimeScene.getObjects("Move_To_Block6"), gdjs.Level_321Code.GDMove_95To_95Block6Objects3);
{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Level_321Code.GDMove_95To_95Block6Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block6Objects3[0].getCenterXInScene()), (( gdjs.Level_321Code.GDMove_95To_95Block6Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block6Objects3[0].getCenterYInScene()), "linear", 650, false);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList38(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16422548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.asyncCallback11521556 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Level_321Code.GDPlatform_95DoorObjects4);
{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95DoorObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95DoorObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Level_321Code.eventsList40 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback11521556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList41 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Level_321Code.eventsList40(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level_321Code.asyncCallback16464860 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);

gdjs.copyArray(runtimeScene.getObjects("Move_To_Block7"), gdjs.Level_321Code.GDMove_95To_95Block7Objects3);
{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Level_321Code.GDMove_95To_95Block7Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block7Objects3[0].getCenterXInScene()), (( gdjs.Level_321Code.GDMove_95To_95Block7Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block7Objects3[0].getCenterYInScene()), "linear", 1500, false);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList41(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList42 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16464860(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBossObjects2Objects = Hashtable.newFrom({"Boss": gdjs.Level_321Code.GDBossObjects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION11Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION11": gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Level_321Code.GDBullet_95Enemy_952Objects4});
gdjs.Level_321Code.asyncCallback16427940 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects4);

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Level_321Code.GDBullet_95Enemy_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.35);
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects, (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterYInScene()), 400, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects, (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterYInScene()), 600, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95952Objects4Objects, (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects4[0].getCenterYInScene()), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Level_321Code.eventsList43 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Boss as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16427940(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList44 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16427636);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList43(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level_321Code.asyncCallback16427476 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Level_321Code.eventsList44(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList45 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16427476(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Level_321Code.GDBullet_95Enemy_953Objects4});
gdjs.Level_321Code.asyncCallback16444708 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects4);

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Level_321Code.GDBullet_95Enemy_953Objects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.35);
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, 180, 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, 160, 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects4.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Level_321Code.GDBossObjects4[i].getCenterXInScene()), (gdjs.Level_321Code.GDBossObjects4[i].getCenterYInScene()), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBullet_9595Enemy_95953Objects4Objects, -(160), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Level_321Code.eventsList46 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level_321Code.GDBossObjects3) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16444708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList47 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16408364);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList46(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level_321Code.asyncCallback16432660 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects3);

gdjs.copyArray(runtimeScene.getObjects("Move_To_Block5"), gdjs.Level_321Code.GDMove_95To_95Block5Objects3);
{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Level_321Code.GDMove_95To_95Block5Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block5Objects3[0].getCenterXInScene()), (( gdjs.Level_321Code.GDMove_95To_95Block5Objects3.length === 0 ) ? 0 :gdjs.Level_321Code.GDMove_95To_95Block5Objects3[0].getCenterYInScene()), "linear", 650, false);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList47(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList48 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16432660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.asyncCallback16421012 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Level_321Code.GDTutorial_95BossObjects3);
{for(var i = 0, len = gdjs.Level_321Code.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Level_321Code.GDTutorial_95BossObjects3[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Level_321Code.eventsList49 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16421012(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.asyncCallback16420812 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);

{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects2[i].getBehavior("Tween").addObjectScaleTween("Spawn", 0, 0, "bounce", 650, false, false);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList49(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_321Code.eventsList50 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_321Code.GDBossObjects1) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16420812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Falling_Wall"), gdjs.Level_321Code.GDFalling_95WallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Falling_Wall_Chain"), gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects2[i].setPosition((( gdjs.Level_321Code.GDFalling_95WallObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDFalling_95WallObjects2[0].getCenterXInScene()),(( gdjs.Level_321Code.GDFalling_95WallObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDFalling_95WallObjects2[0].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION5"), gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION5Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8334252);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects2);
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].setOpacity(150);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION10"), gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION10Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15301364);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].setOpacity(150);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION6"), gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION6Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10194660);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].setOpacity(150);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION7"), gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION7Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9058764);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].setOpacity(150);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2[k] = gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16404436);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList15(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Level_321Code.GDVirus_952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952Objects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterYInScene()), 0, 900, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDVirus_952Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952Objects2[i].playAnimation();
}
}
{ //Subevents
gdjs.Level_321Code.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Level_321Code.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952_9595WallObjects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterYInScene()), 270, 900, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDVirus_952_95WallObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95WallObjects2[i].playAnimation();
}
}
{ //Subevents
gdjs.Level_321Code.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Level_321Code.GDVirus_952_95FlippedObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDVirus_95952_9595FlippedObjects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterYInScene()), 0, 900, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDVirus_952_95FlippedObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDVirus_952_95FlippedObjects2[i].playAnimation();
}
}
{ //Subevents
gdjs.Level_321Code.eventsList21(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Falling_Wall"), gdjs.Level_321Code.GDFalling_95WallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDFalling_9595WallObjects2Objects, (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterXInScene()), (( gdjs.Level_321Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_321Code.GDPlayerObjects2[0].getCenterYInScene()), 270, 500, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDFalling_95WallObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDFalling_95WallObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDFalling_95WallObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_321Code.eventsList22(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Level_321Code.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Level_321Code.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlatform_95MovingObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlatform_95MovingObjects2[i].getX() == 64 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlatform_95MovingObjects2[k] = gdjs.Level_321Code.GDPlatform_95MovingObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlatform_95MovingObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal3Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDterminal3Objects2[k] = gdjs.Level_321Code.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal3Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12768812);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Level_321Code.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Level_321Code.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlatform_95MovingObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlatform_95MovingObjects2[i].getX() == -(832) ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPlatform_95MovingObjects2[k] = gdjs.Level_321Code.GDPlatform_95MovingObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlatform_95MovingObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal3Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDterminal3Objects2[k] = gdjs.Level_321Code.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal3Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16461436);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList24(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.Level_321Code.GDterminal5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDterminal5Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDterminal5Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDterminal5Objects2[k] = gdjs.Level_321Code.GDterminal5Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDterminal5Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15271164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Level_321Code.GDPlatform_95Door2Objects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlatform_95Door2Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlatform_95Door2Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Level_321Code.GDPortalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPortalObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPortalObjects2[i].getScaleY() == 4 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPortalObjects2[k] = gdjs.Level_321Code.GDPortalObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPortalObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPortalObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPortalObjects2[i].getScaleX() == 4 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDPortalObjects2[k] = gdjs.Level_321Code.GDPortalObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPortalObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPortalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects2[i].getVariables().getFromIndex(1)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9332404);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_321Code.eventsList25(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION9"), gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_321Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION9Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10190684);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList27(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleY() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleX() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 20 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 19 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2_2final, gdjs.Level_321Code.GDBossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15290836);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList30(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleY() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleX() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 18 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 17 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2_2final, gdjs.Level_321Code.GDBossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16436812);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList33(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleY() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleX() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 16 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 15 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2_2final, gdjs.Level_321Code.GDBossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9047452);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList36(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleY() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleX() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 14 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 12 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2_2final, gdjs.Level_321Code.GDBossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16428596);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList39(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleY() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleX() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 11 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 10 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2_2final, gdjs.Level_321Code.GDBossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16435260);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);
gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION11"), gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleY() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleX() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDBossObjects2Objects, gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDCAMERA_9595TRANSITION11Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 10 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 9 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 8 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 7 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 6 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2_2final, gdjs.Level_321Code.GDBossObjects2);
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14512700);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList45(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleY() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getScaleX() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 5 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 4 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2, gdjs.Level_321Code.GDBossObjects3);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects3.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects3[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects3[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects3[k] = gdjs.Level_321Code.GDBossObjects3[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects2_2final.indexOf(gdjs.Level_321Code.GDBossObjects3[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects2_2final.push(gdjs.Level_321Code.GDBossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects2_2final, gdjs.Level_321Code.GDBossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16432476);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_321Code.eventsList48(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects1.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects1[i].getScaleY() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects1[k] = gdjs.Level_321Code.GDBossObjects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects1.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects1[i].getScaleX() == 0.7 ) {
        isConditionTrue_1 = true;
        gdjs.Level_321Code.GDBossObjects1[k] = gdjs.Level_321Code.GDBossObjects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Level_321Code.GDBossObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects1, gdjs.Level_321Code.GDBossObjects2);

for (var i = 0, k = 0, l = gdjs.Level_321Code.GDBossObjects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDBossObjects2[i].getVariableNumber(gdjs.Level_321Code.GDBossObjects2[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_2 = true;
        gdjs.Level_321Code.GDBossObjects2[k] = gdjs.Level_321Code.GDBossObjects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDBossObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level_321Code.GDBossObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Level_321Code.GDBossObjects1_2final.indexOf(gdjs.Level_321Code.GDBossObjects2[j]) === -1 )
            gdjs.Level_321Code.GDBossObjects1_2final.push(gdjs.Level_321Code.GDBossObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_321Code.GDBossObjects1_2final, gdjs.Level_321Code.GDBossObjects1);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16443180);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "..\\..\\..\\Game Development\\Game assests\\Time Rush\\Sounds\\Death Test 1.wav", false, 50, 0.5);
}
{ //Subevents
gdjs.Level_321Code.eventsList50(runtimeScene);} //End of subevents
}

}


};gdjs.Level_321Code.eventsList52 = function(runtimeScene) {

};gdjs.Level_321Code.asyncCallback16419788 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Level_321Code.eventsList53 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Level_321Code.asyncCallback16419788(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_321Code.eventsList54 = function(runtimeScene) {

{



}


{


const repeatCount3 = 1;
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Timer") > 1;
if (isConditionTrue_0)
{
{runtimeScene.getScene().getVariables().get("Secs").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Secs")) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Level_321Code.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over"), gdjs.Level_321Code.GDGame_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Level_321Code.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Level_321Code.GDHealth_95barObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Level_321Code.GDShield_95CountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Level_321Code.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.Level_321Code.GDText_95Game_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95OverObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDGame_95Over_95BGObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDCursorObjects2[i].hide(false);
}
}{gdjs.evtTools.input.showCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95CountObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDShield_95SkillObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level_321Code.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDHealth_95barObjects2[i].hide();
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}
{ //Subevents
gdjs.Level_321Code.eventsList53(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Secs")) < 30;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects2);
{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects2[i].setColor("255;0;0");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level_321Code.GDTimerObjects1);
{for(var i = 0, len = gdjs.Level_321Code.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDTimerObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Secs"))));
}
}}

}


};gdjs.Level_321Code.eventsList55 = function(runtimeScene) {

{



}


{


gdjs.Level_321Code.eventsList12(runtimeScene);
}


{


gdjs.Level_321Code.eventsList14(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(1), true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 1;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16442932);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Retro Boss Fight 2.mp3", false, 25, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Level_321Code.GDBossObjects1);
gdjs.Level_321Code.GDPlayerObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_321Code.mapOfGDgdjs_46Level_95321Code_46GDPlayerObjects1Objects, 640, 480, "");
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayerObjects1[i].returnVariable(gdjs.Level_321Code.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{runtimeScene.getScene().getVariables().get("Secs").setNumber(200);
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects1[i].setScale(0);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDBossObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDBossObjects1[i].setZOrder(-(1));
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(1);
}}

}


{



}


{


gdjs.Level_321Code.eventsList51(runtimeScene);
}


{



}


{


gdjs.Level_321Code.eventsList54(runtimeScene);
}


};

gdjs.Level_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_321Code.GDCursorObjects1.length = 0;
gdjs.Level_321Code.GDCursorObjects2.length = 0;
gdjs.Level_321Code.GDCursorObjects3.length = 0;
gdjs.Level_321Code.GDCursorObjects4.length = 0;
gdjs.Level_321Code.GDBackgroundObjects1.length = 0;
gdjs.Level_321Code.GDBackgroundObjects2.length = 0;
gdjs.Level_321Code.GDBackgroundObjects3.length = 0;
gdjs.Level_321Code.GDBackgroundObjects4.length = 0;
gdjs.Level_321Code.GDFanObjects1.length = 0;
gdjs.Level_321Code.GDFanObjects2.length = 0;
gdjs.Level_321Code.GDFanObjects3.length = 0;
gdjs.Level_321Code.GDFanObjects4.length = 0;
gdjs.Level_321Code.GDDecorationObjects1.length = 0;
gdjs.Level_321Code.GDDecorationObjects2.length = 0;
gdjs.Level_321Code.GDDecorationObjects3.length = 0;
gdjs.Level_321Code.GDDecorationObjects4.length = 0;
gdjs.Level_321Code.GDDecoration2Objects1.length = 0;
gdjs.Level_321Code.GDDecoration2Objects2.length = 0;
gdjs.Level_321Code.GDDecoration2Objects3.length = 0;
gdjs.Level_321Code.GDDecoration2Objects4.length = 0;
gdjs.Level_321Code.GDDecoration1Objects1.length = 0;
gdjs.Level_321Code.GDDecoration1Objects2.length = 0;
gdjs.Level_321Code.GDDecoration1Objects3.length = 0;
gdjs.Level_321Code.GDDecoration1Objects4.length = 0;
gdjs.Level_321Code.GDDecoration3Objects1.length = 0;
gdjs.Level_321Code.GDDecoration3Objects2.length = 0;
gdjs.Level_321Code.GDDecoration3Objects3.length = 0;
gdjs.Level_321Code.GDDecoration3Objects4.length = 0;
gdjs.Level_321Code.GDDecoration4Objects1.length = 0;
gdjs.Level_321Code.GDDecoration4Objects2.length = 0;
gdjs.Level_321Code.GDDecoration4Objects3.length = 0;
gdjs.Level_321Code.GDDecoration4Objects4.length = 0;
gdjs.Level_321Code.GDDecoration5Objects1.length = 0;
gdjs.Level_321Code.GDDecoration5Objects2.length = 0;
gdjs.Level_321Code.GDDecoration5Objects3.length = 0;
gdjs.Level_321Code.GDDecoration5Objects4.length = 0;
gdjs.Level_321Code.GDDecoration6Objects1.length = 0;
gdjs.Level_321Code.GDDecoration6Objects2.length = 0;
gdjs.Level_321Code.GDDecoration6Objects3.length = 0;
gdjs.Level_321Code.GDDecoration6Objects4.length = 0;
gdjs.Level_321Code.GDDecoration7Objects1.length = 0;
gdjs.Level_321Code.GDDecoration7Objects2.length = 0;
gdjs.Level_321Code.GDDecoration7Objects3.length = 0;
gdjs.Level_321Code.GDDecoration7Objects4.length = 0;
gdjs.Level_321Code.GDDecoration8Objects1.length = 0;
gdjs.Level_321Code.GDDecoration8Objects2.length = 0;
gdjs.Level_321Code.GDDecoration8Objects3.length = 0;
gdjs.Level_321Code.GDDecoration8Objects4.length = 0;
gdjs.Level_321Code.GDDecoration9Objects1.length = 0;
gdjs.Level_321Code.GDDecoration9Objects2.length = 0;
gdjs.Level_321Code.GDDecoration9Objects3.length = 0;
gdjs.Level_321Code.GDDecoration9Objects4.length = 0;
gdjs.Level_321Code.GDDecoration10Objects1.length = 0;
gdjs.Level_321Code.GDDecoration10Objects2.length = 0;
gdjs.Level_321Code.GDDecoration10Objects3.length = 0;
gdjs.Level_321Code.GDDecoration10Objects4.length = 0;
gdjs.Level_321Code.GDDecoration11Objects1.length = 0;
gdjs.Level_321Code.GDDecoration11Objects2.length = 0;
gdjs.Level_321Code.GDDecoration11Objects3.length = 0;
gdjs.Level_321Code.GDDecoration11Objects4.length = 0;
gdjs.Level_321Code.GDDecoration12Objects1.length = 0;
gdjs.Level_321Code.GDDecoration12Objects2.length = 0;
gdjs.Level_321Code.GDDecoration12Objects3.length = 0;
gdjs.Level_321Code.GDDecoration12Objects4.length = 0;
gdjs.Level_321Code.GDDecoration13Objects1.length = 0;
gdjs.Level_321Code.GDDecoration13Objects2.length = 0;
gdjs.Level_321Code.GDDecoration13Objects3.length = 0;
gdjs.Level_321Code.GDDecoration13Objects4.length = 0;
gdjs.Level_321Code.GDDecoration14Objects1.length = 0;
gdjs.Level_321Code.GDDecoration14Objects2.length = 0;
gdjs.Level_321Code.GDDecoration14Objects3.length = 0;
gdjs.Level_321Code.GDDecoration14Objects4.length = 0;
gdjs.Level_321Code.GDDecoration15Objects1.length = 0;
gdjs.Level_321Code.GDDecoration15Objects2.length = 0;
gdjs.Level_321Code.GDDecoration15Objects3.length = 0;
gdjs.Level_321Code.GDDecoration15Objects4.length = 0;
gdjs.Level_321Code.GDDecoration16Objects1.length = 0;
gdjs.Level_321Code.GDDecoration16Objects2.length = 0;
gdjs.Level_321Code.GDDecoration16Objects3.length = 0;
gdjs.Level_321Code.GDDecoration16Objects4.length = 0;
gdjs.Level_321Code.GDDecoration17Objects1.length = 0;
gdjs.Level_321Code.GDDecoration17Objects2.length = 0;
gdjs.Level_321Code.GDDecoration17Objects3.length = 0;
gdjs.Level_321Code.GDDecoration17Objects4.length = 0;
gdjs.Level_321Code.GDDecoration18Objects1.length = 0;
gdjs.Level_321Code.GDDecoration18Objects2.length = 0;
gdjs.Level_321Code.GDDecoration18Objects3.length = 0;
gdjs.Level_321Code.GDDecoration18Objects4.length = 0;
gdjs.Level_321Code.GDDecoration19Objects1.length = 0;
gdjs.Level_321Code.GDDecoration19Objects2.length = 0;
gdjs.Level_321Code.GDDecoration19Objects3.length = 0;
gdjs.Level_321Code.GDDecoration19Objects4.length = 0;
gdjs.Level_321Code.GDDecoration20Objects1.length = 0;
gdjs.Level_321Code.GDDecoration20Objects2.length = 0;
gdjs.Level_321Code.GDDecoration20Objects3.length = 0;
gdjs.Level_321Code.GDDecoration20Objects4.length = 0;
gdjs.Level_321Code.GDDecoration22Objects1.length = 0;
gdjs.Level_321Code.GDDecoration22Objects2.length = 0;
gdjs.Level_321Code.GDDecoration22Objects3.length = 0;
gdjs.Level_321Code.GDDecoration22Objects4.length = 0;
gdjs.Level_321Code.GDDecoration24Objects1.length = 0;
gdjs.Level_321Code.GDDecoration24Objects2.length = 0;
gdjs.Level_321Code.GDDecoration24Objects3.length = 0;
gdjs.Level_321Code.GDDecoration24Objects4.length = 0;
gdjs.Level_321Code.GDDecoration25Objects1.length = 0;
gdjs.Level_321Code.GDDecoration25Objects2.length = 0;
gdjs.Level_321Code.GDDecoration25Objects3.length = 0;
gdjs.Level_321Code.GDDecoration25Objects4.length = 0;
gdjs.Level_321Code.GDDecoration28Objects1.length = 0;
gdjs.Level_321Code.GDDecoration28Objects2.length = 0;
gdjs.Level_321Code.GDDecoration28Objects3.length = 0;
gdjs.Level_321Code.GDDecoration28Objects4.length = 0;
gdjs.Level_321Code.GDSpikeObjects1.length = 0;
gdjs.Level_321Code.GDSpikeObjects2.length = 0;
gdjs.Level_321Code.GDSpikeObjects3.length = 0;
gdjs.Level_321Code.GDSpikeObjects4.length = 0;
gdjs.Level_321Code.GDSpike2Objects1.length = 0;
gdjs.Level_321Code.GDSpike2Objects2.length = 0;
gdjs.Level_321Code.GDSpike2Objects3.length = 0;
gdjs.Level_321Code.GDSpike2Objects4.length = 0;
gdjs.Level_321Code.GDSpike3Objects1.length = 0;
gdjs.Level_321Code.GDSpike3Objects2.length = 0;
gdjs.Level_321Code.GDSpike3Objects3.length = 0;
gdjs.Level_321Code.GDSpike3Objects4.length = 0;
gdjs.Level_321Code.GDSpike4Objects1.length = 0;
gdjs.Level_321Code.GDSpike4Objects2.length = 0;
gdjs.Level_321Code.GDSpike4Objects3.length = 0;
gdjs.Level_321Code.GDSpike4Objects4.length = 0;
gdjs.Level_321Code.GDTV_95TUBEObjects1.length = 0;
gdjs.Level_321Code.GDTV_95TUBEObjects2.length = 0;
gdjs.Level_321Code.GDTV_95TUBEObjects3.length = 0;
gdjs.Level_321Code.GDTV_95TUBEObjects4.length = 0;
gdjs.Level_321Code.GDPortalObjects1.length = 0;
gdjs.Level_321Code.GDPortalObjects2.length = 0;
gdjs.Level_321Code.GDPortalObjects3.length = 0;
gdjs.Level_321Code.GDPortalObjects4.length = 0;
gdjs.Level_321Code.GDPlayerObjects1.length = 0;
gdjs.Level_321Code.GDPlayerObjects2.length = 0;
gdjs.Level_321Code.GDPlayerObjects3.length = 0;
gdjs.Level_321Code.GDPlayerObjects4.length = 0;
gdjs.Level_321Code.GDDustObjects1.length = 0;
gdjs.Level_321Code.GDDustObjects2.length = 0;
gdjs.Level_321Code.GDDustObjects3.length = 0;
gdjs.Level_321Code.GDDustObjects4.length = 0;
gdjs.Level_321Code.GDBullet_95EffectObjects1.length = 0;
gdjs.Level_321Code.GDBullet_95EffectObjects2.length = 0;
gdjs.Level_321Code.GDBullet_95EffectObjects3.length = 0;
gdjs.Level_321Code.GDBullet_95EffectObjects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITIONObjects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION2Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION3Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION4Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION5Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION6Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION7Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION8Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION9Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION10Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION11Objects4.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION12Objects1.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION12Objects2.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION12Objects3.length = 0;
gdjs.Level_321Code.GDCAMERA_95TRANSITION12Objects4.length = 0;
gdjs.Level_321Code.GDterminalObjects1.length = 0;
gdjs.Level_321Code.GDterminalObjects2.length = 0;
gdjs.Level_321Code.GDterminalObjects3.length = 0;
gdjs.Level_321Code.GDterminalObjects4.length = 0;
gdjs.Level_321Code.GDterminal5Objects1.length = 0;
gdjs.Level_321Code.GDterminal5Objects2.length = 0;
gdjs.Level_321Code.GDterminal5Objects3.length = 0;
gdjs.Level_321Code.GDterminal5Objects4.length = 0;
gdjs.Level_321Code.GDterminal3Objects1.length = 0;
gdjs.Level_321Code.GDterminal3Objects2.length = 0;
gdjs.Level_321Code.GDterminal3Objects3.length = 0;
gdjs.Level_321Code.GDterminal3Objects4.length = 0;
gdjs.Level_321Code.GDterminal4Objects1.length = 0;
gdjs.Level_321Code.GDterminal4Objects2.length = 0;
gdjs.Level_321Code.GDterminal4Objects3.length = 0;
gdjs.Level_321Code.GDterminal4Objects4.length = 0;
gdjs.Level_321Code.GDGame_95OverObjects1.length = 0;
gdjs.Level_321Code.GDGame_95OverObjects2.length = 0;
gdjs.Level_321Code.GDGame_95OverObjects3.length = 0;
gdjs.Level_321Code.GDGame_95OverObjects4.length = 0;
gdjs.Level_321Code.GDPlatformObjects1.length = 0;
gdjs.Level_321Code.GDPlatformObjects2.length = 0;
gdjs.Level_321Code.GDPlatformObjects3.length = 0;
gdjs.Level_321Code.GDPlatformObjects4.length = 0;
gdjs.Level_321Code.GDPlatform_95BossObjects1.length = 0;
gdjs.Level_321Code.GDPlatform_95BossObjects2.length = 0;
gdjs.Level_321Code.GDPlatform_95BossObjects3.length = 0;
gdjs.Level_321Code.GDPlatform_95BossObjects4.length = 0;
gdjs.Level_321Code.GDPlatform_95DoorObjects1.length = 0;
gdjs.Level_321Code.GDPlatform_95DoorObjects2.length = 0;
gdjs.Level_321Code.GDPlatform_95DoorObjects3.length = 0;
gdjs.Level_321Code.GDPlatform_95DoorObjects4.length = 0;
gdjs.Level_321Code.GDPlatform_95Door2Objects1.length = 0;
gdjs.Level_321Code.GDPlatform_95Door2Objects2.length = 0;
gdjs.Level_321Code.GDPlatform_95Door2Objects3.length = 0;
gdjs.Level_321Code.GDPlatform_95Door2Objects4.length = 0;
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects1.length = 0;
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects2.length = 0;
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects3.length = 0;
gdjs.Level_321Code.GDPlatform_95that_95get_95destroyedObjects4.length = 0;
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects1.length = 0;
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects2.length = 0;
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects3.length = 0;
gdjs.Level_321Code.GDPlatform_95JumpThroughObjects4.length = 0;
gdjs.Level_321Code.GDPlatform_95MovingObjects1.length = 0;
gdjs.Level_321Code.GDPlatform_95MovingObjects2.length = 0;
gdjs.Level_321Code.GDPlatform_95MovingObjects3.length = 0;
gdjs.Level_321Code.GDPlatform_95MovingObjects4.length = 0;
gdjs.Level_321Code.GDPlatform_95edgesObjects1.length = 0;
gdjs.Level_321Code.GDPlatform_95edgesObjects2.length = 0;
gdjs.Level_321Code.GDPlatform_95edgesObjects3.length = 0;
gdjs.Level_321Code.GDPlatform_95edgesObjects4.length = 0;
gdjs.Level_321Code.GDGame_95Over_95BGObjects1.length = 0;
gdjs.Level_321Code.GDGame_95Over_95BGObjects2.length = 0;
gdjs.Level_321Code.GDGame_95Over_95BGObjects3.length = 0;
gdjs.Level_321Code.GDGame_95Over_95BGObjects4.length = 0;
gdjs.Level_321Code.GDDeathObjects1.length = 0;
gdjs.Level_321Code.GDDeathObjects2.length = 0;
gdjs.Level_321Code.GDDeathObjects3.length = 0;
gdjs.Level_321Code.GDDeathObjects4.length = 0;
gdjs.Level_321Code.GDText_95Game_95OverObjects1.length = 0;
gdjs.Level_321Code.GDText_95Game_95OverObjects2.length = 0;
gdjs.Level_321Code.GDText_95Game_95OverObjects3.length = 0;
gdjs.Level_321Code.GDText_95Game_95OverObjects4.length = 0;
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects1.length = 0;
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects2.length = 0;
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects3.length = 0;
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95againObjects4.length = 0;
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects1.length = 0;
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects2.length = 0;
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects3.length = 0;
gdjs.Level_321Code.GDText_95Game_95Over_95Play_95again2Objects4.length = 0;
gdjs.Level_321Code.GDTimerObjects1.length = 0;
gdjs.Level_321Code.GDTimerObjects2.length = 0;
gdjs.Level_321Code.GDTimerObjects3.length = 0;
gdjs.Level_321Code.GDTimerObjects4.length = 0;
gdjs.Level_321Code.GDShield_95CountObjects1.length = 0;
gdjs.Level_321Code.GDShield_95CountObjects2.length = 0;
gdjs.Level_321Code.GDShield_95CountObjects3.length = 0;
gdjs.Level_321Code.GDShield_95CountObjects4.length = 0;
gdjs.Level_321Code.GDShield_95CapsuleObjects1.length = 0;
gdjs.Level_321Code.GDShield_95CapsuleObjects2.length = 0;
gdjs.Level_321Code.GDShield_95CapsuleObjects3.length = 0;
gdjs.Level_321Code.GDShield_95CapsuleObjects4.length = 0;
gdjs.Level_321Code.GDTime_95CapsuleObjects1.length = 0;
gdjs.Level_321Code.GDTime_95CapsuleObjects2.length = 0;
gdjs.Level_321Code.GDTime_95CapsuleObjects3.length = 0;
gdjs.Level_321Code.GDTime_95CapsuleObjects4.length = 0;
gdjs.Level_321Code.GDLeftObjects1.length = 0;
gdjs.Level_321Code.GDLeftObjects2.length = 0;
gdjs.Level_321Code.GDLeftObjects3.length = 0;
gdjs.Level_321Code.GDLeftObjects4.length = 0;
gdjs.Level_321Code.GDRightObjects1.length = 0;
gdjs.Level_321Code.GDRightObjects2.length = 0;
gdjs.Level_321Code.GDRightObjects3.length = 0;
gdjs.Level_321Code.GDRightObjects4.length = 0;
gdjs.Level_321Code.GDLeft_95ControlObjects1.length = 0;
gdjs.Level_321Code.GDLeft_95ControlObjects2.length = 0;
gdjs.Level_321Code.GDLeft_95ControlObjects3.length = 0;
gdjs.Level_321Code.GDLeft_95ControlObjects4.length = 0;
gdjs.Level_321Code.GDRight_95ControlObjects1.length = 0;
gdjs.Level_321Code.GDRight_95ControlObjects2.length = 0;
gdjs.Level_321Code.GDRight_95ControlObjects3.length = 0;
gdjs.Level_321Code.GDRight_95ControlObjects4.length = 0;
gdjs.Level_321Code.GDBullet_95EnemyObjects1.length = 0;
gdjs.Level_321Code.GDBullet_95EnemyObjects2.length = 0;
gdjs.Level_321Code.GDBullet_95EnemyObjects3.length = 0;
gdjs.Level_321Code.GDBullet_95EnemyObjects4.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_952Objects1.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_952Objects2.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_952Objects3.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_952Objects4.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_953Objects1.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_953Objects2.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_953Objects3.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_953Objects4.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_951Objects1.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_951Objects2.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_951Objects3.length = 0;
gdjs.Level_321Code.GDBullet_95Enemy_951Objects4.length = 0;
gdjs.Level_321Code.GDBulletObjects1.length = 0;
gdjs.Level_321Code.GDBulletObjects2.length = 0;
gdjs.Level_321Code.GDBulletObjects3.length = 0;
gdjs.Level_321Code.GDBulletObjects4.length = 0;
gdjs.Level_321Code.GDHealth_95barObjects1.length = 0;
gdjs.Level_321Code.GDHealth_95barObjects2.length = 0;
gdjs.Level_321Code.GDHealth_95barObjects3.length = 0;
gdjs.Level_321Code.GDHealth_95barObjects4.length = 0;
gdjs.Level_321Code.GDG_95ControlObjects1.length = 0;
gdjs.Level_321Code.GDG_95ControlObjects2.length = 0;
gdjs.Level_321Code.GDG_95ControlObjects3.length = 0;
gdjs.Level_321Code.GDG_95ControlObjects4.length = 0;
gdjs.Level_321Code.GDF_95ControlObjects1.length = 0;
gdjs.Level_321Code.GDF_95ControlObjects2.length = 0;
gdjs.Level_321Code.GDF_95ControlObjects3.length = 0;
gdjs.Level_321Code.GDF_95ControlObjects4.length = 0;
gdjs.Level_321Code.GDDown_95ControlObjects1.length = 0;
gdjs.Level_321Code.GDDown_95ControlObjects2.length = 0;
gdjs.Level_321Code.GDDown_95ControlObjects3.length = 0;
gdjs.Level_321Code.GDDown_95ControlObjects4.length = 0;
gdjs.Level_321Code.GDSpace_95ControlObjects1.length = 0;
gdjs.Level_321Code.GDSpace_95ControlObjects2.length = 0;
gdjs.Level_321Code.GDSpace_95ControlObjects3.length = 0;
gdjs.Level_321Code.GDSpace_95ControlObjects4.length = 0;
gdjs.Level_321Code.GDShield_95SkillObjects1.length = 0;
gdjs.Level_321Code.GDShield_95SkillObjects2.length = 0;
gdjs.Level_321Code.GDShield_95SkillObjects3.length = 0;
gdjs.Level_321Code.GDShield_95SkillObjects4.length = 0;
gdjs.Level_321Code.GDMove_95To_95BlockObjects1.length = 0;
gdjs.Level_321Code.GDMove_95To_95BlockObjects2.length = 0;
gdjs.Level_321Code.GDMove_95To_95BlockObjects3.length = 0;
gdjs.Level_321Code.GDMove_95To_95BlockObjects4.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block2Objects1.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block2Objects2.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block2Objects3.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block2Objects4.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block3Objects1.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block3Objects2.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block3Objects3.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block3Objects4.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block4Objects1.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block4Objects2.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block4Objects3.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block4Objects4.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block5Objects1.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block5Objects2.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block5Objects3.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block5Objects4.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block6Objects1.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block6Objects2.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block6Objects3.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block6Objects4.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block7Objects1.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block7Objects2.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block7Objects3.length = 0;
gdjs.Level_321Code.GDMove_95To_95Block7Objects4.length = 0;
gdjs.Level_321Code.GDVirus_952Objects1.length = 0;
gdjs.Level_321Code.GDVirus_952Objects2.length = 0;
gdjs.Level_321Code.GDVirus_952Objects3.length = 0;
gdjs.Level_321Code.GDVirus_952Objects4.length = 0;
gdjs.Level_321Code.GDVirus_952_95WallObjects1.length = 0;
gdjs.Level_321Code.GDVirus_952_95WallObjects2.length = 0;
gdjs.Level_321Code.GDVirus_952_95WallObjects3.length = 0;
gdjs.Level_321Code.GDVirus_952_95WallObjects4.length = 0;
gdjs.Level_321Code.GDVirus_952_95FlippedObjects1.length = 0;
gdjs.Level_321Code.GDVirus_952_95FlippedObjects2.length = 0;
gdjs.Level_321Code.GDVirus_952_95FlippedObjects3.length = 0;
gdjs.Level_321Code.GDVirus_952_95FlippedObjects4.length = 0;
gdjs.Level_321Code.GDShoot_95FromObjects1.length = 0;
gdjs.Level_321Code.GDShoot_95FromObjects2.length = 0;
gdjs.Level_321Code.GDShoot_95FromObjects3.length = 0;
gdjs.Level_321Code.GDShoot_95FromObjects4.length = 0;
gdjs.Level_321Code.GDShoot_95From2Objects1.length = 0;
gdjs.Level_321Code.GDShoot_95From2Objects2.length = 0;
gdjs.Level_321Code.GDShoot_95From2Objects3.length = 0;
gdjs.Level_321Code.GDShoot_95From2Objects4.length = 0;
gdjs.Level_321Code.GDShoot_95From3Objects1.length = 0;
gdjs.Level_321Code.GDShoot_95From3Objects2.length = 0;
gdjs.Level_321Code.GDShoot_95From3Objects3.length = 0;
gdjs.Level_321Code.GDShoot_95From3Objects4.length = 0;
gdjs.Level_321Code.GDFalling_95WallObjects1.length = 0;
gdjs.Level_321Code.GDFalling_95WallObjects2.length = 0;
gdjs.Level_321Code.GDFalling_95WallObjects3.length = 0;
gdjs.Level_321Code.GDFalling_95WallObjects4.length = 0;
gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects1.length = 0;
gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects2.length = 0;
gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects3.length = 0;
gdjs.Level_321Code.GDFalling_95Wall_95ChainObjects4.length = 0;
gdjs.Level_321Code.GDBossObjects1.length = 0;
gdjs.Level_321Code.GDBossObjects2.length = 0;
gdjs.Level_321Code.GDBossObjects3.length = 0;
gdjs.Level_321Code.GDBossObjects4.length = 0;
gdjs.Level_321Code.GDTutorial_95BossObjects1.length = 0;
gdjs.Level_321Code.GDTutorial_95BossObjects2.length = 0;
gdjs.Level_321Code.GDTutorial_95BossObjects3.length = 0;
gdjs.Level_321Code.GDTutorial_95BossObjects4.length = 0;

gdjs.Level_321Code.eventsList55(runtimeScene);

return;

}

gdjs['Level_321Code'] = gdjs.Level_321Code;

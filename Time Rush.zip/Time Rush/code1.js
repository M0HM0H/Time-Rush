gdjs.Tutorial_32levelCode = {};
gdjs.Tutorial_32levelCode.GDBossObjects2_2final = [];

gdjs.Tutorial_32levelCode.GDBulletObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final = [];

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final = [];

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final = [];

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final = [];

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final = [];

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final = [];

gdjs.Tutorial_32levelCode.GDDeathObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final = [];

gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final = [];

gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final = [];

gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final = [];

gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final = [];

gdjs.Tutorial_32levelCode.GDVirus_952Objects2_1final = [];

gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2_1final = [];

gdjs.Tutorial_32levelCode.GDCursorObjects1= [];
gdjs.Tutorial_32levelCode.GDCursorObjects2= [];
gdjs.Tutorial_32levelCode.GDCursorObjects3= [];
gdjs.Tutorial_32levelCode.GDCursorObjects4= [];
gdjs.Tutorial_32levelCode.GDCursorObjects5= [];
gdjs.Tutorial_32levelCode.GDBackgroundObjects1= [];
gdjs.Tutorial_32levelCode.GDBackgroundObjects2= [];
gdjs.Tutorial_32levelCode.GDBackgroundObjects3= [];
gdjs.Tutorial_32levelCode.GDBackgroundObjects4= [];
gdjs.Tutorial_32levelCode.GDBackgroundObjects5= [];
gdjs.Tutorial_32levelCode.GDFanObjects1= [];
gdjs.Tutorial_32levelCode.GDFanObjects2= [];
gdjs.Tutorial_32levelCode.GDFanObjects3= [];
gdjs.Tutorial_32levelCode.GDFanObjects4= [];
gdjs.Tutorial_32levelCode.GDFanObjects5= [];
gdjs.Tutorial_32levelCode.GDDecorationObjects1= [];
gdjs.Tutorial_32levelCode.GDDecorationObjects2= [];
gdjs.Tutorial_32levelCode.GDDecorationObjects3= [];
gdjs.Tutorial_32levelCode.GDDecorationObjects4= [];
gdjs.Tutorial_32levelCode.GDDecorationObjects5= [];
gdjs.Tutorial_32levelCode.GDDecoration2Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration2Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration2Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration2Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration2Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration1Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration1Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration1Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration1Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration1Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration3Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration3Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration3Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration3Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration3Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration4Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration4Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration4Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration4Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration4Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration5Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration5Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration5Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration5Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration5Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration6Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration6Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration6Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration6Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration6Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration7Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration7Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration7Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration7Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration7Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration8Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration8Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration8Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration8Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration8Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration9Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration9Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration9Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration9Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration9Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration10Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration10Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration10Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration10Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration10Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration11Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration11Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration11Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration11Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration11Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration12Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration12Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration12Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration12Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration12Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration13Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration13Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration13Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration13Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration13Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration14Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration14Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration14Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration14Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration14Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration15Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration15Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration15Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration15Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration15Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration16Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration16Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration16Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration16Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration16Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration17Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration17Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration17Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration17Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration17Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration18Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration18Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration18Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration18Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration18Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration19Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration19Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration19Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration19Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration19Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration20Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration20Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration20Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration20Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration20Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration22Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration22Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration22Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration22Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration22Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration24Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration24Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration24Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration24Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration24Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration25Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration25Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration25Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration25Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration25Objects5= [];
gdjs.Tutorial_32levelCode.GDDecoration28Objects1= [];
gdjs.Tutorial_32levelCode.GDDecoration28Objects2= [];
gdjs.Tutorial_32levelCode.GDDecoration28Objects3= [];
gdjs.Tutorial_32levelCode.GDDecoration28Objects4= [];
gdjs.Tutorial_32levelCode.GDDecoration28Objects5= [];
gdjs.Tutorial_32levelCode.GDSpikeObjects1= [];
gdjs.Tutorial_32levelCode.GDSpikeObjects2= [];
gdjs.Tutorial_32levelCode.GDSpikeObjects3= [];
gdjs.Tutorial_32levelCode.GDSpikeObjects4= [];
gdjs.Tutorial_32levelCode.GDSpikeObjects5= [];
gdjs.Tutorial_32levelCode.GDSpike2Objects1= [];
gdjs.Tutorial_32levelCode.GDSpike2Objects2= [];
gdjs.Tutorial_32levelCode.GDSpike2Objects3= [];
gdjs.Tutorial_32levelCode.GDSpike2Objects4= [];
gdjs.Tutorial_32levelCode.GDSpike2Objects5= [];
gdjs.Tutorial_32levelCode.GDSpike3Objects1= [];
gdjs.Tutorial_32levelCode.GDSpike3Objects2= [];
gdjs.Tutorial_32levelCode.GDSpike3Objects3= [];
gdjs.Tutorial_32levelCode.GDSpike3Objects4= [];
gdjs.Tutorial_32levelCode.GDSpike3Objects5= [];
gdjs.Tutorial_32levelCode.GDSpike4Objects1= [];
gdjs.Tutorial_32levelCode.GDSpike4Objects2= [];
gdjs.Tutorial_32levelCode.GDSpike4Objects3= [];
gdjs.Tutorial_32levelCode.GDSpike4Objects4= [];
gdjs.Tutorial_32levelCode.GDSpike4Objects5= [];
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects1= [];
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects2= [];
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects3= [];
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects4= [];
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects5= [];
gdjs.Tutorial_32levelCode.GDPortalObjects1= [];
gdjs.Tutorial_32levelCode.GDPortalObjects2= [];
gdjs.Tutorial_32levelCode.GDPortalObjects3= [];
gdjs.Tutorial_32levelCode.GDPortalObjects4= [];
gdjs.Tutorial_32levelCode.GDPortalObjects5= [];
gdjs.Tutorial_32levelCode.GDPlayerObjects1= [];
gdjs.Tutorial_32levelCode.GDPlayerObjects2= [];
gdjs.Tutorial_32levelCode.GDPlayerObjects3= [];
gdjs.Tutorial_32levelCode.GDPlayerObjects4= [];
gdjs.Tutorial_32levelCode.GDPlayerObjects5= [];
gdjs.Tutorial_32levelCode.GDDustObjects1= [];
gdjs.Tutorial_32levelCode.GDDustObjects2= [];
gdjs.Tutorial_32levelCode.GDDustObjects3= [];
gdjs.Tutorial_32levelCode.GDDustObjects4= [];
gdjs.Tutorial_32levelCode.GDDustObjects5= [];
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects1= [];
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2= [];
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects3= [];
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects4= [];
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects5= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects1= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects2= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects3= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects4= [];
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects5= [];
gdjs.Tutorial_32levelCode.GDterminalObjects1= [];
gdjs.Tutorial_32levelCode.GDterminalObjects2= [];
gdjs.Tutorial_32levelCode.GDterminalObjects3= [];
gdjs.Tutorial_32levelCode.GDterminalObjects4= [];
gdjs.Tutorial_32levelCode.GDterminalObjects5= [];
gdjs.Tutorial_32levelCode.GDterminal5Objects1= [];
gdjs.Tutorial_32levelCode.GDterminal5Objects2= [];
gdjs.Tutorial_32levelCode.GDterminal5Objects3= [];
gdjs.Tutorial_32levelCode.GDterminal5Objects4= [];
gdjs.Tutorial_32levelCode.GDterminal5Objects5= [];
gdjs.Tutorial_32levelCode.GDterminal3Objects1= [];
gdjs.Tutorial_32levelCode.GDterminal3Objects2= [];
gdjs.Tutorial_32levelCode.GDterminal3Objects3= [];
gdjs.Tutorial_32levelCode.GDterminal3Objects4= [];
gdjs.Tutorial_32levelCode.GDterminal3Objects5= [];
gdjs.Tutorial_32levelCode.GDterminal4Objects1= [];
gdjs.Tutorial_32levelCode.GDterminal4Objects2= [];
gdjs.Tutorial_32levelCode.GDterminal4Objects3= [];
gdjs.Tutorial_32levelCode.GDterminal4Objects4= [];
gdjs.Tutorial_32levelCode.GDterminal4Objects5= [];
gdjs.Tutorial_32levelCode.GDGame_95OverObjects1= [];
gdjs.Tutorial_32levelCode.GDGame_95OverObjects2= [];
gdjs.Tutorial_32levelCode.GDGame_95OverObjects3= [];
gdjs.Tutorial_32levelCode.GDGame_95OverObjects4= [];
gdjs.Tutorial_32levelCode.GDGame_95OverObjects5= [];
gdjs.Tutorial_32levelCode.GDPlatformObjects1= [];
gdjs.Tutorial_32levelCode.GDPlatformObjects2= [];
gdjs.Tutorial_32levelCode.GDPlatformObjects3= [];
gdjs.Tutorial_32levelCode.GDPlatformObjects4= [];
gdjs.Tutorial_32levelCode.GDPlatformObjects5= [];
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects1= [];
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects2= [];
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects3= [];
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects4= [];
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects5= [];
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects1= [];
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2= [];
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3= [];
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects4= [];
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects5= [];
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects1= [];
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2= [];
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3= [];
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects4= [];
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects5= [];
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects1= [];
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2= [];
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3= [];
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects4= [];
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects5= [];
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects1= [];
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2= [];
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3= [];
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects4= [];
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects5= [];
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects1= [];
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2= [];
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3= [];
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects4= [];
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects5= [];
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects1= [];
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2= [];
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3= [];
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects4= [];
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects5= [];
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects1= [];
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2= [];
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects3= [];
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects4= [];
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects5= [];
gdjs.Tutorial_32levelCode.GDDeathObjects1= [];
gdjs.Tutorial_32levelCode.GDDeathObjects2= [];
gdjs.Tutorial_32levelCode.GDDeathObjects3= [];
gdjs.Tutorial_32levelCode.GDDeathObjects4= [];
gdjs.Tutorial_32levelCode.GDDeathObjects5= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects1= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects3= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects4= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects5= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects1= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects3= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects4= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects5= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects1= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects2= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects3= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects4= [];
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects5= [];
gdjs.Tutorial_32levelCode.GDTimerObjects1= [];
gdjs.Tutorial_32levelCode.GDTimerObjects2= [];
gdjs.Tutorial_32levelCode.GDTimerObjects3= [];
gdjs.Tutorial_32levelCode.GDTimerObjects4= [];
gdjs.Tutorial_32levelCode.GDTimerObjects5= [];
gdjs.Tutorial_32levelCode.GDShield_95CountObjects1= [];
gdjs.Tutorial_32levelCode.GDShield_95CountObjects2= [];
gdjs.Tutorial_32levelCode.GDShield_95CountObjects3= [];
gdjs.Tutorial_32levelCode.GDShield_95CountObjects4= [];
gdjs.Tutorial_32levelCode.GDShield_95CountObjects5= [];
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects1= [];
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2= [];
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects3= [];
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects4= [];
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects5= [];
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects1= [];
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2= [];
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects3= [];
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects4= [];
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects5= [];
gdjs.Tutorial_32levelCode.GDLeftObjects1= [];
gdjs.Tutorial_32levelCode.GDLeftObjects2= [];
gdjs.Tutorial_32levelCode.GDLeftObjects3= [];
gdjs.Tutorial_32levelCode.GDLeftObjects4= [];
gdjs.Tutorial_32levelCode.GDLeftObjects5= [];
gdjs.Tutorial_32levelCode.GDRightObjects1= [];
gdjs.Tutorial_32levelCode.GDRightObjects2= [];
gdjs.Tutorial_32levelCode.GDRightObjects3= [];
gdjs.Tutorial_32levelCode.GDRightObjects4= [];
gdjs.Tutorial_32levelCode.GDRightObjects5= [];
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects1= [];
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects2= [];
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects3= [];
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects4= [];
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects5= [];
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects1= [];
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects2= [];
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects3= [];
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects4= [];
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects5= [];
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects1= [];
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2= [];
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3= [];
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4= [];
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects5= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects1= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects4= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects5= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects1= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects4= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects5= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects1= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects4= [];
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects5= [];
gdjs.Tutorial_32levelCode.GDBulletObjects1= [];
gdjs.Tutorial_32levelCode.GDBulletObjects2= [];
gdjs.Tutorial_32levelCode.GDBulletObjects3= [];
gdjs.Tutorial_32levelCode.GDBulletObjects4= [];
gdjs.Tutorial_32levelCode.GDBulletObjects5= [];
gdjs.Tutorial_32levelCode.GDHealth_95barObjects1= [];
gdjs.Tutorial_32levelCode.GDHealth_95barObjects2= [];
gdjs.Tutorial_32levelCode.GDHealth_95barObjects3= [];
gdjs.Tutorial_32levelCode.GDHealth_95barObjects4= [];
gdjs.Tutorial_32levelCode.GDHealth_95barObjects5= [];
gdjs.Tutorial_32levelCode.GDG_95ControlObjects1= [];
gdjs.Tutorial_32levelCode.GDG_95ControlObjects2= [];
gdjs.Tutorial_32levelCode.GDG_95ControlObjects3= [];
gdjs.Tutorial_32levelCode.GDG_95ControlObjects4= [];
gdjs.Tutorial_32levelCode.GDG_95ControlObjects5= [];
gdjs.Tutorial_32levelCode.GDF_95ControlObjects1= [];
gdjs.Tutorial_32levelCode.GDF_95ControlObjects2= [];
gdjs.Tutorial_32levelCode.GDF_95ControlObjects3= [];
gdjs.Tutorial_32levelCode.GDF_95ControlObjects4= [];
gdjs.Tutorial_32levelCode.GDF_95ControlObjects5= [];
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects1= [];
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects2= [];
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects3= [];
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects4= [];
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects5= [];
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects1= [];
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects2= [];
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects3= [];
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects4= [];
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects5= [];
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects1= [];
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2= [];
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects3= [];
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects4= [];
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects5= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects1= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects2= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects3= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects4= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects5= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects1= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects2= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects3= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects4= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects5= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects1= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects2= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects3= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects4= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects5= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects1= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects2= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects3= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects4= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects5= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects1= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects2= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects3= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects4= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects5= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects1= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects2= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects3= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects4= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects5= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects1= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects2= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects3= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects4= [];
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects5= [];
gdjs.Tutorial_32levelCode.GDVirus_952Objects1= [];
gdjs.Tutorial_32levelCode.GDVirus_952Objects2= [];
gdjs.Tutorial_32levelCode.GDVirus_952Objects3= [];
gdjs.Tutorial_32levelCode.GDVirus_952Objects4= [];
gdjs.Tutorial_32levelCode.GDVirus_952Objects5= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects1= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects4= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects5= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects1= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects4= [];
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects5= [];
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects1= [];
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects2= [];
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects3= [];
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects4= [];
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects5= [];
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects1= [];
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects2= [];
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects3= [];
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects4= [];
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects5= [];
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects1= [];
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects2= [];
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects3= [];
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects4= [];
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects5= [];
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects1= [];
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects2= [];
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects3= [];
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects4= [];
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects5= [];
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects1= [];
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects2= [];
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects3= [];
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects4= [];
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects5= [];
gdjs.Tutorial_32levelCode.GDBossObjects1= [];
gdjs.Tutorial_32levelCode.GDBossObjects2= [];
gdjs.Tutorial_32levelCode.GDBossObjects3= [];
gdjs.Tutorial_32levelCode.GDBossObjects4= [];
gdjs.Tutorial_32levelCode.GDBossObjects5= [];
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects1= [];
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2= [];
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3= [];
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4= [];
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects5= [];
gdjs.Tutorial_32levelCode.GDText_951Objects1= [];
gdjs.Tutorial_32levelCode.GDText_951Objects2= [];
gdjs.Tutorial_32levelCode.GDText_951Objects3= [];
gdjs.Tutorial_32levelCode.GDText_951Objects4= [];
gdjs.Tutorial_32levelCode.GDText_951Objects5= [];
gdjs.Tutorial_32levelCode.GDText_952Objects1= [];
gdjs.Tutorial_32levelCode.GDText_952Objects2= [];
gdjs.Tutorial_32levelCode.GDText_952Objects3= [];
gdjs.Tutorial_32levelCode.GDText_952Objects4= [];
gdjs.Tutorial_32levelCode.GDText_952Objects5= [];
gdjs.Tutorial_32levelCode.GDText_953Objects1= [];
gdjs.Tutorial_32levelCode.GDText_953Objects2= [];
gdjs.Tutorial_32levelCode.GDText_953Objects3= [];
gdjs.Tutorial_32levelCode.GDText_953Objects4= [];
gdjs.Tutorial_32levelCode.GDText_953Objects5= [];
gdjs.Tutorial_32levelCode.GDText_954Objects1= [];
gdjs.Tutorial_32levelCode.GDText_954Objects2= [];
gdjs.Tutorial_32levelCode.GDText_954Objects3= [];
gdjs.Tutorial_32levelCode.GDText_954Objects4= [];
gdjs.Tutorial_32levelCode.GDText_954Objects5= [];
gdjs.Tutorial_32levelCode.GDText_955Objects1= [];
gdjs.Tutorial_32levelCode.GDText_955Objects2= [];
gdjs.Tutorial_32levelCode.GDText_955Objects3= [];
gdjs.Tutorial_32levelCode.GDText_955Objects4= [];
gdjs.Tutorial_32levelCode.GDText_955Objects5= [];
gdjs.Tutorial_32levelCode.GDText_956Objects1= [];
gdjs.Tutorial_32levelCode.GDText_956Objects2= [];
gdjs.Tutorial_32levelCode.GDText_956Objects3= [];
gdjs.Tutorial_32levelCode.GDText_956Objects4= [];
gdjs.Tutorial_32levelCode.GDText_956Objects5= [];
gdjs.Tutorial_32levelCode.GDText_957Objects1= [];
gdjs.Tutorial_32levelCode.GDText_957Objects2= [];
gdjs.Tutorial_32levelCode.GDText_957Objects3= [];
gdjs.Tutorial_32levelCode.GDText_957Objects4= [];
gdjs.Tutorial_32levelCode.GDText_957Objects5= [];
gdjs.Tutorial_32levelCode.GDText_958Objects1= [];
gdjs.Tutorial_32levelCode.GDText_958Objects2= [];
gdjs.Tutorial_32levelCode.GDText_958Objects3= [];
gdjs.Tutorial_32levelCode.GDText_958Objects4= [];
gdjs.Tutorial_32levelCode.GDText_958Objects5= [];
gdjs.Tutorial_32levelCode.GDText_959Objects1= [];
gdjs.Tutorial_32levelCode.GDText_959Objects2= [];
gdjs.Tutorial_32levelCode.GDText_959Objects3= [];
gdjs.Tutorial_32levelCode.GDText_959Objects4= [];
gdjs.Tutorial_32levelCode.GDText_959Objects5= [];
gdjs.Tutorial_32levelCode.GDText_9510Objects1= [];
gdjs.Tutorial_32levelCode.GDText_9510Objects2= [];
gdjs.Tutorial_32levelCode.GDText_9510Objects3= [];
gdjs.Tutorial_32levelCode.GDText_9510Objects4= [];
gdjs.Tutorial_32levelCode.GDText_9510Objects5= [];
gdjs.Tutorial_32levelCode.GDDownObjects1= [];
gdjs.Tutorial_32levelCode.GDDownObjects2= [];
gdjs.Tutorial_32levelCode.GDDownObjects3= [];
gdjs.Tutorial_32levelCode.GDDownObjects4= [];
gdjs.Tutorial_32levelCode.GDDownObjects5= [];
gdjs.Tutorial_32levelCode.GDGObjects1= [];
gdjs.Tutorial_32levelCode.GDGObjects2= [];
gdjs.Tutorial_32levelCode.GDGObjects3= [];
gdjs.Tutorial_32levelCode.GDGObjects4= [];
gdjs.Tutorial_32levelCode.GDGObjects5= [];
gdjs.Tutorial_32levelCode.GDFObjects1= [];
gdjs.Tutorial_32levelCode.GDFObjects2= [];
gdjs.Tutorial_32levelCode.GDFObjects3= [];
gdjs.Tutorial_32levelCode.GDFObjects4= [];
gdjs.Tutorial_32levelCode.GDFObjects5= [];
gdjs.Tutorial_32levelCode.GDSpaceObjects1= [];
gdjs.Tutorial_32levelCode.GDSpaceObjects2= [];
gdjs.Tutorial_32levelCode.GDSpaceObjects3= [];
gdjs.Tutorial_32levelCode.GDSpaceObjects4= [];
gdjs.Tutorial_32levelCode.GDSpaceObjects5= [];
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects1= [];
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects2= [];
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects3= [];
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects4= [];
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects5= [];
gdjs.Tutorial_32levelCode.GDDown_95PollObjects1= [];
gdjs.Tutorial_32levelCode.GDDown_95PollObjects2= [];
gdjs.Tutorial_32levelCode.GDDown_95PollObjects3= [];
gdjs.Tutorial_32levelCode.GDDown_95PollObjects4= [];
gdjs.Tutorial_32levelCode.GDDown_95PollObjects5= [];
gdjs.Tutorial_32levelCode.GDUP_95PollObjects1= [];
gdjs.Tutorial_32levelCode.GDUP_95PollObjects2= [];
gdjs.Tutorial_32levelCode.GDUP_95PollObjects3= [];
gdjs.Tutorial_32levelCode.GDUP_95PollObjects4= [];
gdjs.Tutorial_32levelCode.GDUP_95PollObjects5= [];
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects1= [];
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects2= [];
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects3= [];
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects4= [];
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects5= [];
gdjs.Tutorial_32levelCode.GDRight_95PollObjects1= [];
gdjs.Tutorial_32levelCode.GDRight_95PollObjects2= [];
gdjs.Tutorial_32levelCode.GDRight_95PollObjects3= [];
gdjs.Tutorial_32levelCode.GDRight_95PollObjects4= [];
gdjs.Tutorial_32levelCode.GDRight_95PollObjects5= [];
gdjs.Tutorial_32levelCode.GDPistolObjects1= [];
gdjs.Tutorial_32levelCode.GDPistolObjects2= [];
gdjs.Tutorial_32levelCode.GDPistolObjects3= [];
gdjs.Tutorial_32levelCode.GDPistolObjects4= [];
gdjs.Tutorial_32levelCode.GDPistolObjects5= [];


gdjs.Tutorial_32levelCode.asyncCallback15880612 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2"), gdjs.Tutorial_32levelCode.GDVirus_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Flipped"), gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Wall"), gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952Objects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952Objects3[i].setAnimationName("Virus_Idle");
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3[i].setAnimationName("Virus_Idle");
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3[i].setAnimationName("Virus_Idle");
}
}}
gdjs.Tutorial_32levelCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDVirus_952Objects2) asyncObjectsList.addObject("Virus_2", obj);
for (const obj of gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2) asyncObjectsList.addObject("Virus_2_Flipped", obj);
for (const obj of gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2) asyncObjectsList.addObject("Virus_2_Wall", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback15880612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDterminalObjects2Objects = Hashtable.newFrom({"terminal": gdjs.Tutorial_32levelCode.GDterminalObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDterminal4Objects2Objects = Hashtable.newFrom({"terminal4": gdjs.Tutorial_32levelCode.GDterminal4Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDterminal3Objects2Objects = Hashtable.newFrom({"terminal3": gdjs.Tutorial_32levelCode.GDterminal3Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDterminal5Objects2Objects = Hashtable.newFrom({"terminal5": gdjs.Tutorial_32levelCode.GDterminal5Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTime_9595CapsuleObjects2Objects = Hashtable.newFrom({"Time_Capsule": gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDShield_9595CapsuleObjects2Objects = Hashtable.newFrom({"Shield_Capsule": gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPistolObjects2Objects = Hashtable.newFrom({"Pistol": gdjs.Tutorial_32levelCode.GDPistolObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDDeathObjects3Objects = Hashtable.newFrom({"Death": gdjs.Tutorial_32levelCode.GDDeathObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Tutorial_32levelCode.GDSpikeObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Tutorial_32levelCode.GDSpike2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Tutorial_32levelCode.GDSpike3Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Tutorial_32levelCode.GDSpike4Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EffectObjects2Objects = Hashtable.newFrom({"Bullet_Effect": gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EffectObjects2Objects = Hashtable.newFrom({"Bullet_Effect": gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatformObjects3Objects = Hashtable.newFrom({"Platform": gdjs.Tutorial_32levelCode.GDPlatformObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595DoorObjects3Objects = Hashtable.newFrom({"Platform_Door": gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595Door2Objects3Objects = Hashtable.newFrom({"Platform_Door2": gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595edgesObjects3Objects = Hashtable.newFrom({"Platform_edges": gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects = Hashtable.newFrom({"Platform_that_get_destroyed": gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595JumpThroughObjects3Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595MovingObjects3Objects = Hashtable.newFrom({"Platform_Moving": gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Tutorial_32levelCode.GDSpikeObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Tutorial_32levelCode.GDSpike2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Tutorial_32levelCode.GDSpike3Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Tutorial_32levelCode.GDSpike4Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952Objects3Objects = Hashtable.newFrom({"Virus_2": gdjs.Tutorial_32levelCode.GDVirus_952Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952_9595WallObjects3Objects = Hashtable.newFrom({"Virus_2_Wall": gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952_9595FlippedObjects3Objects = Hashtable.newFrom({"Virus_2_Flipped": gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3});
gdjs.Tutorial_32levelCode.asyncCallback9078052 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2"), gdjs.Tutorial_32levelCode.GDVirus_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Flipped"), gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Wall"), gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952Objects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952Objects3[i].returnVariable(gdjs.Tutorial_32levelCode.GDVirus_952Objects3[i].getVariables().get("HP")).sub(1);
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3[i].returnVariable(gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3[i].getVariables().get("HP")).sub(1);
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3[i].returnVariable(gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3[i].getVariables().get("HP")).sub(1);
}
}}
gdjs.Tutorial_32levelCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDVirus_952Objects2) asyncObjectsList.addObject("Virus_2", obj);
for (const obj of gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2) asyncObjectsList.addObject("Virus_2_Flipped", obj);
for (const obj of gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2) asyncObjectsList.addObject("Virus_2_Wall", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback9078052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2});
gdjs.Tutorial_32levelCode.asyncCallback9078892 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].returnVariable(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}}
gdjs.Tutorial_32levelCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback9078892(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBossObjects2Objects = Hashtable.newFrom({"Boss": gdjs.Tutorial_32levelCode.GDBossObjects2});
gdjs.Tutorial_32levelCode.asyncCallback11461588 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.Tutorial_32levelCode.GDBossObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBossObjects3[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBossObjects3[i].returnVariable(gdjs.Tutorial_32levelCode.GDBossObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}}
gdjs.Tutorial_32levelCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback11461588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952Objects2ObjectsGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952_9595WallObjects2ObjectsGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952_9595FlippedObjects2Objects = Hashtable.newFrom({"Virus_2": gdjs.Tutorial_32levelCode.GDVirus_952Objects2, "Virus_2_Wall": gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2, "Virus_2_Flipped": gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Tutorial_32levelCode.GDBulletObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2});
gdjs.Tutorial_32levelCode.asyncCallback16651404 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Tutorial_32levelCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16651404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Tutorial_32levelCode.GDSpikeObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Tutorial_32levelCode.GDSpike2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Tutorial_32levelCode.GDSpike3Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Tutorial_32levelCode.GDSpike4Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Tutorial_32levelCode.GDSpikeObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Tutorial_32levelCode.GDSpike2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Tutorial_32levelCode.GDSpike3Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Tutorial_32levelCode.GDSpike4Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Tutorial_32levelCode.GDSpikeObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Tutorial_32levelCode.GDSpike2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Tutorial_32levelCode.GDSpike3Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Tutorial_32levelCode.GDSpike4Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.asyncCallback16614740 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.Tutorial_32levelCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16614740(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.asyncCallback16768372 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.Tutorial_32levelCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16768372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects3Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBossObjects3Objects = Hashtable.newFrom({"Boss": gdjs.Tutorial_32levelCode.GDBossObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.asyncCallback16707164 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.Tutorial_32levelCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16707164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatformObjects3Objects = Hashtable.newFrom({"Platform": gdjs.Tutorial_32levelCode.GDPlatformObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595DoorObjects3Objects = Hashtable.newFrom({"Platform_Door": gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595Door2Objects3Objects = Hashtable.newFrom({"Platform_Door2": gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595edgesObjects3Objects = Hashtable.newFrom({"Platform_edges": gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects = Hashtable.newFrom({"Platform_that_get_destroyed": gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595JumpThroughObjects3Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595MovingObjects3Objects = Hashtable.newFrom({"Platform_Moving": gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Tutorial_32levelCode.GDSpikeObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Tutorial_32levelCode.GDSpike2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Tutorial_32levelCode.GDSpike3Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Tutorial_32levelCode.GDSpike4Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.asyncCallback16728924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.Tutorial_32levelCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16728924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.asyncCallback16716612 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.Tutorial_32levelCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16716612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.asyncCallback16603620 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.Tutorial_32levelCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16603620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.asyncCallback16648548 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.Tutorial_32levelCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16648548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITIONObjects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION2Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION2": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION3Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION3": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION4Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION4": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION5Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION5": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION6Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION6": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION7Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION7": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION8Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION8": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION9Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION9": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION10Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION10": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION11Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION11": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595JumpThroughObjects2Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595JumpThroughObjects2Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDDustObjects2Objects = Hashtable.newFrom({"Dust": gdjs.Tutorial_32levelCode.GDDustObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects = Hashtable.newFrom({"Text_Game_Over_Play_again": gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDText_9595Game_9595Over_9595Play_9595againObjects1Objects = Hashtable.newFrom({"Text_Game_Over_Play_again": gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects1});
gdjs.Tutorial_32levelCode.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Down_Control"), gdjs.Tutorial_32levelCode.GDDown_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("F_Control"), gdjs.Tutorial_32levelCode.GDF_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("G_Control"), gdjs.Tutorial_32levelCode.GDG_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Left_Control"), gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Right_Control"), gdjs.Tutorial_32levelCode.GDRight_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Space_Control"), gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDG_95ControlObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDG_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDF_95ControlObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDF_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDown_95ControlObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDown_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDRight_95ControlObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDRight_95ControlObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Tutorial_32levelCode.GDBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.Tutorial_32levelCode.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.Tutorial_32levelCode.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Tutorial_32levelCode.GDHealth_95barObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block"), gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block2"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block3"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block4"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block5"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block6"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block7"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("TV_TUBE"), gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBackgroundObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBackgroundObjects2[i].setYOffset(gdjs.Tutorial_32levelCode.GDBackgroundObjects2[i].getYOffset() + (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects2[i].setYOffset(gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects2[i].getYOffset() + (-(50) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2[i].setXOffset(gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2[i].getXOffset() + (-(50) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBulletObjects2[i].setHeight(64);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBulletObjects2[i].setWidth(64);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setHeight(64);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setWidth(64);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].setPosition((( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[0].getPointX("Count")),(( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[0].getPointY("Count")));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDHealth_95barObjects2[i].setPosition((( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[0].getPointX("Health_Bar")),(( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[0].getPointY("Health_Bar")));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration14Objects2[i].setOpacity(150);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration15Objects2[i].setOpacity(150);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2[i].setOpacity(190);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2[i].setOpacity(190);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2[i].setScale(3);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2[i].setScale(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2[i].setScale(2.5);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2[i].setScale(3.4);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects2[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Game_Over"), gdjs.Tutorial_32levelCode.GDGame_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Tutorial_32levelCode.GDHealth_95barObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Tutorial_32levelCode.GDPortalObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again2"), gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects2);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPortalObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95OverObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPortalObjects2[i].setScale(0);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDHealth_95barObjects2[i].setOpacity(90);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].setOpacity(50);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Tutorial_32levelCode.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952Objects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Decoration"), gdjs.Tutorial_32levelCode.GDDecorationObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration1"), gdjs.Tutorial_32levelCode.GDDecoration1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration10"), gdjs.Tutorial_32levelCode.GDDecoration10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration11"), gdjs.Tutorial_32levelCode.GDDecoration11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration12"), gdjs.Tutorial_32levelCode.GDDecoration12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration13"), gdjs.Tutorial_32levelCode.GDDecoration13Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.Tutorial_32levelCode.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.Tutorial_32levelCode.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration16"), gdjs.Tutorial_32levelCode.GDDecoration16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration17"), gdjs.Tutorial_32levelCode.GDDecoration17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration18"), gdjs.Tutorial_32levelCode.GDDecoration18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration19"), gdjs.Tutorial_32levelCode.GDDecoration19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration2"), gdjs.Tutorial_32levelCode.GDDecoration2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration20"), gdjs.Tutorial_32levelCode.GDDecoration20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration22"), gdjs.Tutorial_32levelCode.GDDecoration22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration24"), gdjs.Tutorial_32levelCode.GDDecoration24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration25"), gdjs.Tutorial_32levelCode.GDDecoration25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration28"), gdjs.Tutorial_32levelCode.GDDecoration28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration3"), gdjs.Tutorial_32levelCode.GDDecoration3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration4"), gdjs.Tutorial_32levelCode.GDDecoration4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration5"), gdjs.Tutorial_32levelCode.GDDecoration5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration6"), gdjs.Tutorial_32levelCode.GDDecoration6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration7"), gdjs.Tutorial_32levelCode.GDDecoration7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration8"), gdjs.Tutorial_32levelCode.GDDecoration8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration9"), gdjs.Tutorial_32levelCode.GDDecoration9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Fan"), gdjs.Tutorial_32levelCode.GDFanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.Tutorial_32levelCode.GDPlatformObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatformObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatformObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[i].setColor("37;37;37");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecorationObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecorationObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration1Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration1Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration2Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration2Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration3Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration3Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration4Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration4Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration5Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration5Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration6Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration6Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration7Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration7Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration8Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration8Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration9Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration9Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration10Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration10Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration11Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration11Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration12Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration12Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration13Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration13Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration14Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration15Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration16Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration16Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration17Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration17Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration18Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration18Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration19Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration19Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration20Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration20Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration22Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration22Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration24Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration24Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration25Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration25Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration28Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration28Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDFanObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDFanObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2[i].setColor("255;255;255");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9319612);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Tutorial_32levelCode.GDLeftObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDLeftObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDLeftObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10188980);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Tutorial_32levelCode.GDLeftObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDLeftObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10162100);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Tutorial_32levelCode.GDRightObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDRightObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDRightObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10191852);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Tutorial_32levelCode.GDRightObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDRightObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16727340);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Tutorial_32levelCode.GDDownObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDownObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDownObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDownObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDownObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16530996);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Tutorial_32levelCode.GDDownObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDownObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDownObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8189164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Space"), gdjs.Tutorial_32levelCode.GDSpaceObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpaceObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpaceObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpaceObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpaceObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11185012);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Space"), gdjs.Tutorial_32levelCode.GDSpaceObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpaceObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpaceObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15317900);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("G"), gdjs.Tutorial_32levelCode.GDGObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "g"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11509604);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("G"), gdjs.Tutorial_32levelCode.GDGObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15265188);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("F"), gdjs.Tutorial_32levelCode.GDFObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDFObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDFObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDFObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDFObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "f"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14500332);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("F"), gdjs.Tutorial_32levelCode.GDFObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDFObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDFObjects2[i].setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.Tutorial_32levelCode.GDterminalObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.Tutorial_32levelCode.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDterminalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminalObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminalObjects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDterminalObjects2[k] = gdjs.Tutorial_32levelCode.GDterminalObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminalObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal4Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDterminal4Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal4Objects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9325508);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Tutorial_32levelCode.GDPortalObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDterminalObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPortalObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPortalObjects2[i].getBehavior("Tween").addObjectScaleTween("Portal", 4, 4, "bouncePast", 800, false, true);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPortalObjects2[i].setAnimationName("Portal");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDterminalObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDterminalObjects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.Tutorial_32levelCode.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDterminal4Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal4Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDterminal4Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal4Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16771180);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDterminal4Objects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDterminal4Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDterminal4Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(10);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Tutorial_32levelCode.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDterminal3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal3Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDterminal3Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal3Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16690164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDterminal3Objects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDterminal3Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDterminal3Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.Tutorial_32levelCode.GDterminal5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDterminal5Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal5Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal5Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDterminal5Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal5Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal5Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16734308);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDterminal5Objects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDterminal5Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDterminal5Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16757380);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Jump.mp3", false, 50, gdjs.randomFloatInRange(0.8, 1.2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16766460);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getAnimationFrame() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16574668);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getAnimationFrame() == 4 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9330556);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTime_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16668596);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDShield_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16654636);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pistol"), gdjs.Tutorial_32levelCode.GDPistolObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPistolObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16732308);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{

gdjs.Tutorial_32levelCode.GDDeathObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpikeObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike3Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Tutorial_32levelCode.GDDeathObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.Tutorial_32levelCode.GDDeathObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDDeathObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDDeathObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDDeathObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDDeathObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDDeathObjects2_1final.push(gdjs.Tutorial_32levelCode.GDDeathObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Tutorial_32levelCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.push(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Tutorial_32levelCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Tutorial_32levelCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Tutorial_32levelCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDDeathObjects2_1final, gdjs.Tutorial_32levelCode.GDDeathObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final, gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final, gdjs.Tutorial_32levelCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16624556);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 100, 0.8);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.Tutorial_32levelCode.GDterminalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminalObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminalObjects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDterminalObjects2[k] = gdjs.Tutorial_32levelCode.GDterminalObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminalObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9059140);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.5, 0.7));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.Tutorial_32levelCode.GDterminal5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal5Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal5Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDterminal5Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal5Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal5Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9075196);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.9, 1.1));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Tutorial_32levelCode.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal3Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDterminal3Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16689004);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.9, 1.1));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.Tutorial_32levelCode.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal4Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDterminal4Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal4Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16728652);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.75, 0.95));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Shoot") > 1.3;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].isFlippedX()) ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9080164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, gdjs.randomFloatInRange(1.2, 1.5));
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getPointX("Shoot")), (gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getPointY("Shoot")), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects, 0, 900, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EffectObjects2Objects, (( gdjs.Tutorial_32levelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDPlayerObjects2[0].getPointX("Shoot")), (( gdjs.Tutorial_32levelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDPlayerObjects2[0].getPointY("Shoot")), "");
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Shoot") > 1.5;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].isFlippedX() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16593300);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, gdjs.randomFloatInRange(1.2, 1.5));
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getPointX("Shoot")), (gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getPointY("Shoot")), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects, -(180), 900, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EffectObjects2Objects, (( gdjs.Tutorial_32levelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDPlayerObjects2[0].getPointX("Shoot")), (( gdjs.Tutorial_32levelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDPlayerObjects2[0].getPointY("Shoot")), "");
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}}

}


{

gdjs.Tutorial_32levelCode.GDBulletObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatformObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpikeObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike3Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.Tutorial_32levelCode.GDPlatformObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatformObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatformObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatformObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatformObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595DoorObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595Door2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595edgesObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595JumpThroughObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595MovingObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Tutorial_32levelCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.push(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Tutorial_32levelCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Tutorial_32levelCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Tutorial_32levelCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBulletObjects2_1final, gdjs.Tutorial_32levelCode.GDBulletObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatformObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final, gdjs.Tutorial_32levelCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Tutorial_32levelCode.GDBulletObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Tutorial_32levelCode.GDVirus_952Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDVirus_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDVirus_952Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDVirus_952Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDVirus_952Objects2_1final.push(gdjs.Tutorial_32levelCode.GDVirus_952Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952_9595WallObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2_1final.push(gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952_9595FlippedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBulletObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2_1final.push(gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBulletObjects2_1final, gdjs.Tutorial_32levelCode.GDBulletObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDVirus_952Objects2_1final, gdjs.Tutorial_32levelCode.GDVirus_952Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2_1final, gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2_1final, gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDVirus_952Objects2 */
/* Reuse gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2 */
/* Reuse gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i].setAnimationName("Virus_Hurt");
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i].setAnimationName("Virus_Hurt");
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i].setAnimationName("Virus_Hurt");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Tutorial_32levelCode.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952Objects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16736388);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDVirus_952Objects2 */
/* Reuse gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2 */
/* Reuse gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
for(var i = 0, len = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16710324);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Tutorial_32levelCode.GDBossObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16718084);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBossObjects2 */
/* Reuse gdjs.Tutorial_32levelCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBossObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBossObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBossObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBossObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.Tutorial_32levelCode.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952Objects2ObjectsGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952_9595WallObjects2ObjectsGDgdjs_46Tutorial_9532levelCode_46GDVirus_95952_9595FlippedObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952Objects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[k] = gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16619092);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBulletObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16761372);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpikeObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike3Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Tutorial_32levelCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.push(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Tutorial_32levelCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Tutorial_32levelCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Tutorial_32levelCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_1final, gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final, gdjs.Tutorial_32levelCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpikeObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike3Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Tutorial_32levelCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.push(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Tutorial_32levelCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Tutorial_32levelCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Tutorial_32levelCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_1final, gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final, gdjs.Tutorial_32levelCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpikeObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike3Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Tutorial_32levelCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.push(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Tutorial_32levelCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Tutorial_32levelCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Tutorial_32levelCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_1final, gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final, gdjs.Tutorial_32levelCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final.push(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final, gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final, gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final, gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final, gdjs.Tutorial_32levelCode.GDPlayerObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16632212);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2);
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final.push(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2_2final, gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2_2final, gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2_2final, gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final, gdjs.Tutorial_32levelCode.GDPlayerObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16768236);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.Tutorial_32levelCode.GDBossObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Tutorial_32levelCode.GDBossObjects2_2final.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.length = 0;
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.Tutorial_32levelCode.GDBossObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBossObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDBossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDBossObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBossObjects2_2final, gdjs.Tutorial_32levelCode.GDBossObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlayerObjects2_2final, gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16719964);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatformObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpikeObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike3Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.Tutorial_32levelCode.GDPlatformObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatformObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatformObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatformObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatformObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595DoorObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595Door2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595edgesObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595JumpThroughObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595MovingObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Tutorial_32levelCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.push(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Tutorial_32levelCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Tutorial_32levelCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Tutorial_32levelCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2_1final, gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatformObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatformObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2_1final, gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final, gdjs.Tutorial_32levelCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16596308);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2 */
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595Enemy_95951Objects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16728780);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16743996);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTutorial_9595BossObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16735132);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Tutorial_32levelCode.GDBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration"), gdjs.Tutorial_32levelCode.GDDecorationObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration1"), gdjs.Tutorial_32levelCode.GDDecoration1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration10"), gdjs.Tutorial_32levelCode.GDDecoration10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration11"), gdjs.Tutorial_32levelCode.GDDecoration11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration12"), gdjs.Tutorial_32levelCode.GDDecoration12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.Tutorial_32levelCode.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.Tutorial_32levelCode.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration16"), gdjs.Tutorial_32levelCode.GDDecoration16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration17"), gdjs.Tutorial_32levelCode.GDDecoration17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration18"), gdjs.Tutorial_32levelCode.GDDecoration18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration19"), gdjs.Tutorial_32levelCode.GDDecoration19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration2"), gdjs.Tutorial_32levelCode.GDDecoration2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration20"), gdjs.Tutorial_32levelCode.GDDecoration20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration22"), gdjs.Tutorial_32levelCode.GDDecoration22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration24"), gdjs.Tutorial_32levelCode.GDDecoration24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration25"), gdjs.Tutorial_32levelCode.GDDecoration25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration28"), gdjs.Tutorial_32levelCode.GDDecoration28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration3"), gdjs.Tutorial_32levelCode.GDDecoration3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration4"), gdjs.Tutorial_32levelCode.GDDecoration4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration5"), gdjs.Tutorial_32levelCode.GDDecoration5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration6"), gdjs.Tutorial_32levelCode.GDDecoration6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration7"), gdjs.Tutorial_32levelCode.GDDecoration7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration9"), gdjs.Tutorial_32levelCode.GDDecoration9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Tutorial_32levelCode.GDDownObjects2);
gdjs.copyArray(runtimeScene.getObjects("F"), gdjs.Tutorial_32levelCode.GDFObjects2);
gdjs.copyArray(runtimeScene.getObjects("Falling_Wall"), gdjs.Tutorial_32levelCode.GDFalling_95WallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Falling_Wall_Chain"), gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects2);
gdjs.copyArray(runtimeScene.getObjects("G"), gdjs.Tutorial_32levelCode.GDGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Tutorial_32levelCode.GDLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.Tutorial_32levelCode.GDPlatformObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Boss"), gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Tutorial_32levelCode.GDRightObjects2);
gdjs.copyArray(runtimeScene.getObjects("Space"), gdjs.Tutorial_32levelCode.GDSpaceObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Tutorial_32levelCode.GDSpikeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Tutorial_32levelCode.GDSpike2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Tutorial_32levelCode.GDSpike3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Tutorial_32levelCode.GDSpike4Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.Tutorial_32levelCode.GDterminalObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Tutorial_32levelCode.GDterminal3Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.Tutorial_32levelCode.GDterminal4Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.Tutorial_32levelCode.GDterminal5Objects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatformObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatformObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDFalling_95WallObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDFalling_95WallObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpikeObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpikeObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpike2Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpike2Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpike3Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpike3Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpike4Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpike4Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBackgroundObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBackgroundObjects2[i].setZOrder(-(20));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecorationObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecorationObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration1Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration1Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration3Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration3Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration2Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration2Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration4Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration4Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration5Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration5Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration6Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration7Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration7Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration9Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration9Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration10Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration10Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration11Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration11Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration12Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration12Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration14Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration15Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration16Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration16Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration17Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration17Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration18Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration18Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration19Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration19Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration20Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration20Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration22Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration22Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration24Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration24Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration25Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration25Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDecoration28Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDecoration28Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDLeftObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDRightObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDownObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDownObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDSpaceObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDSpaceObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDFObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDFObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDterminalObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDterminalObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDterminal5Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDterminal5Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDterminal3Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDterminal3Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDterminal4Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDterminal4Objects2[i].setZOrder(-(1));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITIONObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION2"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION3"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION4"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION4Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION5"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION5Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION6"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION6Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION7"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION7Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION8"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION8Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION9"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION9Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION10"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION10Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION11"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION11Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects2.length !== 0 ? gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects2[0] : null), true, "", 0);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595JumpThroughObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16733588);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2[i].setOpacity(150);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlatform_9595JumpThroughObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9064508);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2[i].setOpacity(255);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Walk - No Weapon");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Walk - No Weapon");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Grab");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isGrabbingPlatform() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16585812);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Grab");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16665284);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16703012);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16646340);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Walk - Pistol");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Walk - Pistol");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Jump - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16770316);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16711660);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16684820);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16715956);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16716260);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
gdjs.Tutorial_32levelCode.GDDustObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDDustObjects2Objects, (( gdjs.Tutorial_32levelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDPlayerObjects2[0].getPointX("Dust")), (( gdjs.Tutorial_32levelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDPlayerObjects2[0].getPointY("Dust")), "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDPlayerObjects2[k] = gdjs.Tutorial_32levelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16691372);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.Tutorial_32levelCode.GDDustObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDustObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDustObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Tutorial_32levelCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.Tutorial_32levelCode.GDDustObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDDustObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDDustObjects2[i].setPosition((( gdjs.Tutorial_32levelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDPlayerObjects2[0].getPointX("Dust")),(( gdjs.Tutorial_32levelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDPlayerObjects2[0].getPointY("Dust")));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2[i].setPosition((( gdjs.Tutorial_32levelCode.GDBulletObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDBulletObjects2[0].getCenterXInScene()),(( gdjs.Tutorial_32levelCode.GDBulletObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDBulletObjects2[0].getCenterYInScene()));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16748668);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Tutorial_32levelCode.GDCursorObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDCursorObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDCursorObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16617756);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Tutorial_32levelCode.GDCursorObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDCursorObjects2[i].setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11595292);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2[i].setColor("163;163;163");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDText_9595Game_9595Over_9595Play_9595againObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9063012);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects1 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects1.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects1[i].setColor("255;255;255");
}
}}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDDeathObjects3Objects = Hashtable.newFrom({"Death": gdjs.Tutorial_32levelCode.GDDeathObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.Tutorial_32levelCode.GDSpikeObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.Tutorial_32levelCode.GDSpike2Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.Tutorial_32levelCode.GDSpike3Objects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects3});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.Tutorial_32levelCode.GDSpike4Objects3});
gdjs.Tutorial_32levelCode.asyncCallback9082204 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}
gdjs.Tutorial_32levelCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback9082204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTime_9595CapsuleObjects2Objects = Hashtable.newFrom({"Time_Capsule": gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDShield_9595CapsuleObjects2Objects = Hashtable.newFrom({"Shield_Capsule": gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDShield_9595CountObjects2Objects = Hashtable.newFrom({"Shield_Count": gdjs.Tutorial_32levelCode.GDShield_95CountObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPistolObjects2Objects = Hashtable.newFrom({"Pistol": gdjs.Tutorial_32levelCode.GDPistolObjects2});
gdjs.Tutorial_32levelCode.eventsList14 = function(runtimeScene) {

{



}


{



}


{



}


{



}


{



}


{



}


{

gdjs.Tutorial_32levelCode.GDDeathObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpikeObjects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike2Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike3Objects2.length = 0;

gdjs.Tutorial_32levelCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Tutorial_32levelCode.GDDeathObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.Tutorial_32levelCode.GDDeathObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDDeathObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDDeathObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDDeathObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDDeathObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDDeathObjects2_1final.push(gdjs.Tutorial_32levelCode.GDDeathObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Tutorial_32levelCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final.push(gdjs.Tutorial_32levelCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.Tutorial_32levelCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.Tutorial_32levelCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.Tutorial_32levelCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects3Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final.push(gdjs.Tutorial_32levelCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.indexOf(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final.push(gdjs.Tutorial_32levelCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDDeathObjects2_1final, gdjs.Tutorial_32levelCode.GDDeathObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDPlayerObjects2_1final, gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpikeObjects2_1final, gdjs.Tutorial_32levelCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike2Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike3Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDSpike4Objects2_1final, gdjs.Tutorial_32levelCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Tutorial_32levelCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over"), gdjs.Tutorial_32levelCode.GDGame_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Tutorial_32levelCode.GDHealth_95barObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95OverObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDCursorObjects2[i].hide(false);
}
}{gdjs.evtTools.input.showCursor(runtimeScene);
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList13(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDTime_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16591244);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2 */
{runtimeScene.getScene().getVariables().get("Secs").add(5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDShield_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16742068);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDShield_9595CountObjects2Objects, (( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[0].getPointX("Count")), (( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[0].getPointY("Count")), "UI");
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getBehavior("Tween").addObjectOpacityTween("Show", 255, "linear", 1500, false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[0].getVariables()).getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[k] = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].setString("0");
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].setOpacity(50);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pistol"), gdjs.Tutorial_32levelCode.GDPistolObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPistolObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9081452);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPistolObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPistolObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPistolObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects1[i].returnVariable(gdjs.Tutorial_32levelCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects1});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects = Hashtable.newFrom({"Text_Game_Over_Play_again": gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2});
gdjs.Tutorial_32levelCode.asyncCallback16263204 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial level", false);
}}
gdjs.Tutorial_32levelCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16263204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16273612 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Tutorial_32levelCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16273612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16275188 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Tutorial_32levelCode.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16275188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects2});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION10Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION10": gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2});
gdjs.Tutorial_32levelCode.asyncCallback16277308 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Tutorial_32levelCode.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16277308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16276732 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getBehavior("Tween").addObjectScaleTween("Spawn", 2, 2, "bounce", 650, false, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Tutorial_32levelCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16276732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4});
gdjs.Tutorial_32levelCode.asyncCallback16277748 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4);

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getPointX("Shoot_Left")), (gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getPointY("Shoot_Left")), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects4Objects, 0, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Tutorial_32levelCode.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16277748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16280532);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16277884 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block2"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects3);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects3.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects3[0].getCenterXInScene()), (( gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects3.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects3[0].getCenterYInScene()), "linear", 650, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList21(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Tutorial_32levelCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16277884(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4});
gdjs.Tutorial_32levelCode.asyncCallback16280772 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4);

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getPointX("Shoot_Right")), (gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getPointY("Shoot_Right")), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects4Objects, -(180), 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Tutorial_32levelCode.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16280772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16284572);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16283524 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block3"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects3);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects3.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects3[0].getCenterXInScene()), (( gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects3.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects3[0].getCenterYInScene()), "linear", 650, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Tutorial_32levelCode.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16283524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4});
gdjs.Tutorial_32levelCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16288508);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4);

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getPointX("Shoot_Right")), (gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getPointY("Shoot_Right")), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects4Objects, -(180), 600, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Tutorial_32levelCode.asyncCallback16287564 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Tutorial_32levelCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16287564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16286972 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block"), gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects3.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects3[0].getCenterXInScene()), (( gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects3.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects3[0].getCenterYInScene()), "linear", 650, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Tutorial_32levelCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16286972(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects4Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4});
gdjs.Tutorial_32levelCode.asyncCallback16289796 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4);

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, 0.5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getBehavior("FireBullet").Fire((gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getPointX("Shoot_Right")), (gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].getPointY("Shoot_Right")), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDBullet_9595EnemyObjects4Objects, -(180), 800, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.Tutorial_32levelCode.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16289796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.eventsList30 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16292572);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16290972 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block4"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects3);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getBehavior("Tween").addObjectPositionTween("Move", (( gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects3.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects3[0].getCenterXInScene()), (( gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects3.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects3[0].getCenterYInScene()), "linear", 650, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList30(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Tutorial_32levelCode.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16290972(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16296356 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects5);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects5.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects5[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Tutorial_32levelCode.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16296356(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16293700 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Tutorial_32levelCode.GDHealth_95barObjects4);
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDHealth_95barObjects4.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDHealth_95barObjects4[i].hide();
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Tutorial_32levelCode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16293700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.asyncCallback16294516 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getBehavior("Tween").addObjectScaleTween("Spawn", 0, 0, "bounce", 650, false, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Tutorial_32levelCode.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16294516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Tutorial_32levelCode.GDPlayerObjects1});
gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPortalObjects1Objects = Hashtable.newFrom({"Portal": gdjs.Tutorial_32levelCode.GDPortalObjects1});
gdjs.Tutorial_32levelCode.asyncCallback16298044 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 1", false);
}}
gdjs.Tutorial_32levelCode.eventsList36 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16298044(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2[k] = gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16262300);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(1), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16271004);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Retro Boss Fight 1.mp3", false, 30, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block"), gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block2"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block3"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block4"), gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2[i].setScale(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Tutorial_32levelCode.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[i].getX() == 1600 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[k] = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal3Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDterminal3Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal3Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16273500);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[i].getBehavior("Tween").addObjectPositionTween("Move", 1984, 704, "linear", 1500, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.Tutorial_32levelCode.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[i].getX() == 1984 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[k] = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal3Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDterminal3Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal3Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16274964);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2[i].getBehavior("Tween").addObjectPositionTween("Move", 1600, 704, "linear", 1500, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.Tutorial_32levelCode.GDterminal5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDterminal5Objects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDterminal5Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDterminal5Objects2[k] = gdjs.Tutorial_32levelCode.GDterminal5Objects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDterminal5Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16275924);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2[i].getBehavior("Tween").addObjectScaleYTween("Open", -(1856), "linear", 3000, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION10"), gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects2Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDCAMERA_9595TRANSITION10Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16276636);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getScaleY() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getScaleX() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)) == 8 ) {
        isConditionTrue_2 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)) == 7 ) {
        isConditionTrue_2 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16279180);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getScaleY() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getScaleX() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)) == 6 ) {
        isConditionTrue_2 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)) == 5 ) {
        isConditionTrue_2 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16283204);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList25(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getScaleY() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getScaleX() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)) == 4 ) {
        isConditionTrue_2 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_2 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16287084);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getScaleY() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getScaleX() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_2 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3);

for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_2 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final.push(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2_2final, gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16291084);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Tutorial_32levelCode.eventsList31(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getVariableNumber(gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getVariables().getFromIndex(1)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[k] = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16292756);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2);
/* Reuse gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "..\\..\\..\\Game Development\\Game assests\\Time Rush\\Sounds\\Death Test 1.wav", false, 50, 0.5);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2[i].getBehavior("Tween").addObjectScaleTween("Spawn", 3.5, 3.5, "bounce", 1000, false, false);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList35(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Tutorial_32levelCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Tutorial_32levelCode.GDPortalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPortalObjects1.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPortalObjects1[i].getScaleY() == 4 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPortalObjects1[k] = gdjs.Tutorial_32levelCode.GDPortalObjects1[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPortalObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Tutorial_32levelCode.GDPortalObjects1.length;i<l;++i) {
    if ( gdjs.Tutorial_32levelCode.GDPortalObjects1[i].getScaleX() == 4 ) {
        isConditionTrue_1 = true;
        gdjs.Tutorial_32levelCode.GDPortalObjects1[k] = gdjs.Tutorial_32levelCode.GDPortalObjects1[i];
        ++k;
    }
}
gdjs.Tutorial_32levelCode.GDPortalObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects1Objects, gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPortalObjects1Objects, false, runtimeScene, false);
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16297700);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Tutorial_32levelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.Tutorial_32levelCode.eventsList38 = function(runtimeScene) {

};gdjs.Tutorial_32levelCode.asyncCallback16301948 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Tutorial_32levelCode.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Tutorial_32levelCode.asyncCallback16301948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Tutorial_32levelCode.eventsList40 = function(runtimeScene) {

{



}


{


const repeatCount3 = 1;
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Timer") > 1;
if (isConditionTrue_0)
{
{runtimeScene.getScene().getVariables().get("Secs").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Secs")) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Tutorial_32levelCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over"), gdjs.Tutorial_32levelCode.GDGame_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.Tutorial_32levelCode.GDHealth_95barObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.Tutorial_32levelCode.GDShield_95CountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95OverObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDCursorObjects2[i].hide(false);
}
}{gdjs.evtTools.input.showCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95CountObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDHealth_95barObjects2[i].hide();
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}
{ //Subevents
gdjs.Tutorial_32levelCode.eventsList39(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Secs")) < 30;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects2[i].setColor("255;0;0");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Tutorial_32levelCode.GDTimerObjects1);
{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTimerObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Secs"))));
}
}}

}


};gdjs.Tutorial_32levelCode.eventsList41 = function(runtimeScene) {

{



}


{


gdjs.Tutorial_32levelCode.eventsList12(runtimeScene);
}


{


gdjs.Tutorial_32levelCode.eventsList14(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(1), true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15298764);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Retro Boss Fight 1.mp3", false, 25, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block"), gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects1);
gdjs.Tutorial_32levelCode.GDPlayerObjects1.length = 0;

{runtimeScene.getScene().getVariables().get("Secs").setNumber(145);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Tutorial_32levelCode.mapOfGDgdjs_46Tutorial_9532levelCode_46GDPlayerObjects1Objects, 160, 640, "");
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects1.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects1[i].setScale(0);
}
}{for(var i = 0, len = gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects1.length ;i < len;++i) {
    gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects1[i].setPosition((( gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects1.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects1[0].getCenterXInScene()),(( gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects1.length === 0 ) ? 0 :gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects1[0].getCenterYInScene()));
}
}}

}


{



}


{


gdjs.Tutorial_32levelCode.eventsList37(runtimeScene);
}


{



}


{


gdjs.Tutorial_32levelCode.eventsList40(runtimeScene);
}


};

gdjs.Tutorial_32levelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Tutorial_32levelCode.GDCursorObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDCursorObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDCursorObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDCursorObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDCursorObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDBackgroundObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDBackgroundObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDBackgroundObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDBackgroundObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDBackgroundObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDFanObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDFanObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDFanObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDFanObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDFanObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecorationObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecorationObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecorationObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecorationObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecorationObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration2Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration2Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration2Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration2Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration2Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration1Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration1Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration1Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration1Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration1Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration3Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration3Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration3Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration3Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration3Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration4Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration4Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration4Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration4Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration4Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration5Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration5Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration5Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration5Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration5Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration6Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration6Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration6Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration6Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration6Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration7Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration7Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration7Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration7Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration7Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration8Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration8Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration8Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration8Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration8Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration9Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration9Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration9Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration9Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration9Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration10Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration10Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration10Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration10Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration10Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration11Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration11Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration11Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration11Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration11Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration12Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration12Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration12Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration12Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration12Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration13Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration13Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration13Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration13Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration13Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration14Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration14Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration14Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration14Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration14Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration15Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration15Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration15Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration15Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration15Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration16Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration16Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration16Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration16Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration16Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration17Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration17Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration17Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration17Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration17Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration18Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration18Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration18Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration18Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration18Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration19Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration19Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration19Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration19Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration19Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration20Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration20Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration20Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration20Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration20Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration22Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration22Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration22Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration22Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration22Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration24Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration24Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration24Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration24Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration24Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration25Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration25Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration25Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration25Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration25Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration28Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration28Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration28Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration28Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDDecoration28Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDSpikeObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDSpike2Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDSpike3Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDSpike4Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDTV_95TUBEObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPortalObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPortalObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPortalObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPortalObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPortalObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlayerObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDDustObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDDustObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDDustObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDDustObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDDustObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EffectObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITIONObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION2Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION3Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION4Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION5Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION6Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION7Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION8Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION9Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION10Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION11Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDCAMERA_95TRANSITION12Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDterminalObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDterminalObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDterminalObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDterminalObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDterminalObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDterminal5Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDterminal5Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDterminal5Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDterminal5Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDterminal5Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDterminal3Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDterminal3Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDterminal3Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDterminal3Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDterminal3Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDterminal4Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDterminal4Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDterminal4Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDterminal4Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDterminal4Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95OverObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95OverObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95OverObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95OverObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95OverObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlatformObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlatformObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlatformObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlatformObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlatformObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95BossObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95DoorObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95Door2Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95that_95get_95destroyedObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95JumpThroughObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95MovingObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPlatform_95edgesObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDGame_95Over_95BGObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDDeathObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDDeathObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDDeathObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDDeathObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDDeathObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95OverObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95againObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_95Game_95Over_95Play_95again2Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDTimerObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDTimerObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDTimerObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDTimerObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDTimerObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CountObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CountObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CountObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CountObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CountObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95CapsuleObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDTime_95CapsuleObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDLeftObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDLeftObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDLeftObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDLeftObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDLeftObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDRightObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDRightObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDRightObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDRightObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDRightObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95ControlObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95ControlObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95EnemyObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_952Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_953Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDBullet_95Enemy_951Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDBulletObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDBulletObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDBulletObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDBulletObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDBulletObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDHealth_95barObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDHealth_95barObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDHealth_95barObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDHealth_95barObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDHealth_95barObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDG_95ControlObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDG_95ControlObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDG_95ControlObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDG_95ControlObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDG_95ControlObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDF_95ControlObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDF_95ControlObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDF_95ControlObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDF_95ControlObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDF_95ControlObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95ControlObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDSpace_95ControlObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDShield_95SkillObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95BlockObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block2Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block3Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block4Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block5Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block6Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDMove_95To_95Block7Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95WallObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDVirus_952_95FlippedObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95FromObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From2Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDShoot_95From3Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95WallObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDFalling_95Wall_95ChainObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDBossObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDBossObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDBossObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDBossObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDBossObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDTutorial_95BossObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_951Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_951Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_951Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_951Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_951Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_952Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_952Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_952Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_952Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_952Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_953Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_953Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_953Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_953Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_953Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_954Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_954Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_954Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_954Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_954Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_955Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_955Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_955Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_955Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_955Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_956Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_956Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_956Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_956Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_956Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_957Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_957Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_957Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_957Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_957Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_958Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_958Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_958Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_958Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_958Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_959Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_959Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_959Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_959Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_959Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDText_9510Objects1.length = 0;
gdjs.Tutorial_32levelCode.GDText_9510Objects2.length = 0;
gdjs.Tutorial_32levelCode.GDText_9510Objects3.length = 0;
gdjs.Tutorial_32levelCode.GDText_9510Objects4.length = 0;
gdjs.Tutorial_32levelCode.GDText_9510Objects5.length = 0;
gdjs.Tutorial_32levelCode.GDDownObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDDownObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDDownObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDDownObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDDownObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDGObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDGObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDGObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDGObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDGObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDFObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDFObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDFObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDFObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDFObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDSpaceObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDSpaceObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDSpaceObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDSpaceObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDSpaceObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDDeath_95PollObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95PollObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95PollObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95PollObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95PollObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDDown_95PollObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDUP_95PollObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDUP_95PollObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDUP_95PollObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDUP_95PollObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDUP_95PollObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDLeft_95PollObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95PollObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95PollObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95PollObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95PollObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDRight_95PollObjects5.length = 0;
gdjs.Tutorial_32levelCode.GDPistolObjects1.length = 0;
gdjs.Tutorial_32levelCode.GDPistolObjects2.length = 0;
gdjs.Tutorial_32levelCode.GDPistolObjects3.length = 0;
gdjs.Tutorial_32levelCode.GDPistolObjects4.length = 0;
gdjs.Tutorial_32levelCode.GDPistolObjects5.length = 0;

gdjs.Tutorial_32levelCode.eventsList41(runtimeScene);

return;

}

gdjs['Tutorial_32levelCode'] = gdjs.Tutorial_32levelCode;

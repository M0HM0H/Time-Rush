gdjs.ThankyouforplayingCode = {};
gdjs.ThankyouforplayingCode.GDBossObjects2_2final = [];

gdjs.ThankyouforplayingCode.GDBulletObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final = [];

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final = [];

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final = [];

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final = [];

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final = [];

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final = [];

gdjs.ThankyouforplayingCode.GDDeathObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final = [];

gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final = [];

gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final = [];

gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final = [];

gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2_2final = [];

gdjs.ThankyouforplayingCode.GDVirus_952Objects2_1final = [];

gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2_1final = [];

gdjs.ThankyouforplayingCode.GDCursorObjects1= [];
gdjs.ThankyouforplayingCode.GDCursorObjects2= [];
gdjs.ThankyouforplayingCode.GDCursorObjects3= [];
gdjs.ThankyouforplayingCode.GDBackgroundObjects1= [];
gdjs.ThankyouforplayingCode.GDBackgroundObjects2= [];
gdjs.ThankyouforplayingCode.GDBackgroundObjects3= [];
gdjs.ThankyouforplayingCode.GDFanObjects1= [];
gdjs.ThankyouforplayingCode.GDFanObjects2= [];
gdjs.ThankyouforplayingCode.GDFanObjects3= [];
gdjs.ThankyouforplayingCode.GDDecorationObjects1= [];
gdjs.ThankyouforplayingCode.GDDecorationObjects2= [];
gdjs.ThankyouforplayingCode.GDDecorationObjects3= [];
gdjs.ThankyouforplayingCode.GDDecoration2Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration2Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration2Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration1Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration1Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration1Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration3Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration3Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration3Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration4Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration4Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration4Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration5Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration5Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration5Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration6Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration6Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration6Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration7Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration7Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration7Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration8Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration8Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration8Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration9Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration9Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration9Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration10Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration10Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration10Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration11Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration11Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration11Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration12Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration12Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration12Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration13Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration13Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration13Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration14Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration14Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration14Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration15Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration15Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration15Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration16Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration16Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration16Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration17Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration17Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration17Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration18Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration18Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration18Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration19Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration19Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration19Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration20Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration20Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration20Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration22Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration22Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration22Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration24Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration24Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration24Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration25Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration25Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration25Objects3= [];
gdjs.ThankyouforplayingCode.GDDecoration28Objects1= [];
gdjs.ThankyouforplayingCode.GDDecoration28Objects2= [];
gdjs.ThankyouforplayingCode.GDDecoration28Objects3= [];
gdjs.ThankyouforplayingCode.GDSpikeObjects1= [];
gdjs.ThankyouforplayingCode.GDSpikeObjects2= [];
gdjs.ThankyouforplayingCode.GDSpikeObjects3= [];
gdjs.ThankyouforplayingCode.GDSpike2Objects1= [];
gdjs.ThankyouforplayingCode.GDSpike2Objects2= [];
gdjs.ThankyouforplayingCode.GDSpike2Objects3= [];
gdjs.ThankyouforplayingCode.GDSpike3Objects1= [];
gdjs.ThankyouforplayingCode.GDSpike3Objects2= [];
gdjs.ThankyouforplayingCode.GDSpike3Objects3= [];
gdjs.ThankyouforplayingCode.GDSpike4Objects1= [];
gdjs.ThankyouforplayingCode.GDSpike4Objects2= [];
gdjs.ThankyouforplayingCode.GDSpike4Objects3= [];
gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects1= [];
gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects2= [];
gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects3= [];
gdjs.ThankyouforplayingCode.GDPortalObjects1= [];
gdjs.ThankyouforplayingCode.GDPortalObjects2= [];
gdjs.ThankyouforplayingCode.GDPortalObjects3= [];
gdjs.ThankyouforplayingCode.GDPlayerObjects1= [];
gdjs.ThankyouforplayingCode.GDPlayerObjects2= [];
gdjs.ThankyouforplayingCode.GDPlayerObjects3= [];
gdjs.ThankyouforplayingCode.GDDustObjects1= [];
gdjs.ThankyouforplayingCode.GDDustObjects2= [];
gdjs.ThankyouforplayingCode.GDDustObjects3= [];
gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects1= [];
gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2= [];
gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects3= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION12Objects1= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION12Objects2= [];
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION12Objects3= [];
gdjs.ThankyouforplayingCode.GDterminalObjects1= [];
gdjs.ThankyouforplayingCode.GDterminalObjects2= [];
gdjs.ThankyouforplayingCode.GDterminalObjects3= [];
gdjs.ThankyouforplayingCode.GDterminal5Objects1= [];
gdjs.ThankyouforplayingCode.GDterminal5Objects2= [];
gdjs.ThankyouforplayingCode.GDterminal5Objects3= [];
gdjs.ThankyouforplayingCode.GDterminal3Objects1= [];
gdjs.ThankyouforplayingCode.GDterminal3Objects2= [];
gdjs.ThankyouforplayingCode.GDterminal3Objects3= [];
gdjs.ThankyouforplayingCode.GDterminal4Objects1= [];
gdjs.ThankyouforplayingCode.GDterminal4Objects2= [];
gdjs.ThankyouforplayingCode.GDterminal4Objects3= [];
gdjs.ThankyouforplayingCode.GDGame_95OverObjects1= [];
gdjs.ThankyouforplayingCode.GDGame_95OverObjects2= [];
gdjs.ThankyouforplayingCode.GDGame_95OverObjects3= [];
gdjs.ThankyouforplayingCode.GDPlatformObjects1= [];
gdjs.ThankyouforplayingCode.GDPlatformObjects2= [];
gdjs.ThankyouforplayingCode.GDPlatformObjects3= [];
gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects1= [];
gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects2= [];
gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects3= [];
gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects1= [];
gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2= [];
gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3= [];
gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects1= [];
gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2= [];
gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3= [];
gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects1= [];
gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2= [];
gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3= [];
gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects1= [];
gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2= [];
gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3= [];
gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects1= [];
gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2= [];
gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3= [];
gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects1= [];
gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2= [];
gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3= [];
gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects1= [];
gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2= [];
gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects3= [];
gdjs.ThankyouforplayingCode.GDDeathObjects1= [];
gdjs.ThankyouforplayingCode.GDDeathObjects2= [];
gdjs.ThankyouforplayingCode.GDDeathObjects3= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects1= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects3= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects1= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects3= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects1= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects2= [];
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects3= [];
gdjs.ThankyouforplayingCode.GDTimerObjects1= [];
gdjs.ThankyouforplayingCode.GDTimerObjects2= [];
gdjs.ThankyouforplayingCode.GDTimerObjects3= [];
gdjs.ThankyouforplayingCode.GDShield_95CountObjects1= [];
gdjs.ThankyouforplayingCode.GDShield_95CountObjects2= [];
gdjs.ThankyouforplayingCode.GDShield_95CountObjects3= [];
gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects1= [];
gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2= [];
gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects3= [];
gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects1= [];
gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2= [];
gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects3= [];
gdjs.ThankyouforplayingCode.GDLeftObjects1= [];
gdjs.ThankyouforplayingCode.GDLeftObjects2= [];
gdjs.ThankyouforplayingCode.GDLeftObjects3= [];
gdjs.ThankyouforplayingCode.GDRightObjects1= [];
gdjs.ThankyouforplayingCode.GDRightObjects2= [];
gdjs.ThankyouforplayingCode.GDRightObjects3= [];
gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects1= [];
gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects2= [];
gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects3= [];
gdjs.ThankyouforplayingCode.GDRight_95ControlObjects1= [];
gdjs.ThankyouforplayingCode.GDRight_95ControlObjects2= [];
gdjs.ThankyouforplayingCode.GDRight_95ControlObjects3= [];
gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects1= [];
gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2= [];
gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects1= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects1= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects1= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2= [];
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3= [];
gdjs.ThankyouforplayingCode.GDBulletObjects1= [];
gdjs.ThankyouforplayingCode.GDBulletObjects2= [];
gdjs.ThankyouforplayingCode.GDBulletObjects3= [];
gdjs.ThankyouforplayingCode.GDHealth_95barObjects1= [];
gdjs.ThankyouforplayingCode.GDHealth_95barObjects2= [];
gdjs.ThankyouforplayingCode.GDHealth_95barObjects3= [];
gdjs.ThankyouforplayingCode.GDG_95ControlObjects1= [];
gdjs.ThankyouforplayingCode.GDG_95ControlObjects2= [];
gdjs.ThankyouforplayingCode.GDG_95ControlObjects3= [];
gdjs.ThankyouforplayingCode.GDF_95ControlObjects1= [];
gdjs.ThankyouforplayingCode.GDF_95ControlObjects2= [];
gdjs.ThankyouforplayingCode.GDF_95ControlObjects3= [];
gdjs.ThankyouforplayingCode.GDDown_95ControlObjects1= [];
gdjs.ThankyouforplayingCode.GDDown_95ControlObjects2= [];
gdjs.ThankyouforplayingCode.GDDown_95ControlObjects3= [];
gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects1= [];
gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects2= [];
gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects3= [];
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects1= [];
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2= [];
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects3= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects1= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects2= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects3= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects1= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects2= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects3= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects1= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects2= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects3= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects1= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects2= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects3= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects1= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects2= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects3= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects1= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects2= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects3= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects1= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects2= [];
gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects3= [];
gdjs.ThankyouforplayingCode.GDVirus_952Objects1= [];
gdjs.ThankyouforplayingCode.GDVirus_952Objects2= [];
gdjs.ThankyouforplayingCode.GDVirus_952Objects3= [];
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects1= [];
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2= [];
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3= [];
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects1= [];
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2= [];
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3= [];
gdjs.ThankyouforplayingCode.GDShoot_95FromObjects1= [];
gdjs.ThankyouforplayingCode.GDShoot_95FromObjects2= [];
gdjs.ThankyouforplayingCode.GDShoot_95FromObjects3= [];
gdjs.ThankyouforplayingCode.GDShoot_95From2Objects1= [];
gdjs.ThankyouforplayingCode.GDShoot_95From2Objects2= [];
gdjs.ThankyouforplayingCode.GDShoot_95From2Objects3= [];
gdjs.ThankyouforplayingCode.GDShoot_95From3Objects1= [];
gdjs.ThankyouforplayingCode.GDShoot_95From3Objects2= [];
gdjs.ThankyouforplayingCode.GDShoot_95From3Objects3= [];
gdjs.ThankyouforplayingCode.GDFalling_95WallObjects1= [];
gdjs.ThankyouforplayingCode.GDFalling_95WallObjects2= [];
gdjs.ThankyouforplayingCode.GDFalling_95WallObjects3= [];
gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects1= [];
gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects2= [];
gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects3= [];
gdjs.ThankyouforplayingCode.GDBossObjects1= [];
gdjs.ThankyouforplayingCode.GDBossObjects2= [];
gdjs.ThankyouforplayingCode.GDBossObjects3= [];
gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects1= [];
gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2= [];
gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3= [];
gdjs.ThankyouforplayingCode.GDNewTextObjects1= [];
gdjs.ThankyouforplayingCode.GDNewTextObjects2= [];
gdjs.ThankyouforplayingCode.GDNewTextObjects3= [];
gdjs.ThankyouforplayingCode.GDBackObjects1= [];
gdjs.ThankyouforplayingCode.GDBackObjects2= [];
gdjs.ThankyouforplayingCode.GDBackObjects3= [];


gdjs.ThankyouforplayingCode.asyncCallback15880612 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2"), gdjs.ThankyouforplayingCode.GDVirus_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Flipped"), gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Wall"), gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952Objects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952Objects3[i].setAnimationName("Virus_Idle");
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3[i].setAnimationName("Virus_Idle");
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3[i].setAnimationName("Virus_Idle");
}
}}
gdjs.ThankyouforplayingCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDVirus_952Objects2) asyncObjectsList.addObject("Virus_2", obj);
for (const obj of gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2) asyncObjectsList.addObject("Virus_2_Flipped", obj);
for (const obj of gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2) asyncObjectsList.addObject("Virus_2_Wall", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback15880612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDterminalObjects2Objects = Hashtable.newFrom({"terminal": gdjs.ThankyouforplayingCode.GDterminalObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDterminal4Objects2Objects = Hashtable.newFrom({"terminal4": gdjs.ThankyouforplayingCode.GDterminal4Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDterminal3Objects2Objects = Hashtable.newFrom({"terminal3": gdjs.ThankyouforplayingCode.GDterminal3Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDterminal5Objects2Objects = Hashtable.newFrom({"terminal5": gdjs.ThankyouforplayingCode.GDterminal5Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTime_9595CapsuleObjects2Objects = Hashtable.newFrom({"Time_Capsule": gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDShield_9595CapsuleObjects2Objects = Hashtable.newFrom({"Shield_Capsule": gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDDeathObjects3Objects = Hashtable.newFrom({"Death": gdjs.ThankyouforplayingCode.GDDeathObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.ThankyouforplayingCode.GDSpikeObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.ThankyouforplayingCode.GDSpike2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.ThankyouforplayingCode.GDSpike3Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.ThankyouforplayingCode.GDSpike4Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EffectObjects2Objects = Hashtable.newFrom({"Bullet_Effect": gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EffectObjects2Objects = Hashtable.newFrom({"Bullet_Effect": gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatformObjects3Objects = Hashtable.newFrom({"Platform": gdjs.ThankyouforplayingCode.GDPlatformObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595DoorObjects3Objects = Hashtable.newFrom({"Platform_Door": gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595Door2Objects3Objects = Hashtable.newFrom({"Platform_Door2": gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595edgesObjects3Objects = Hashtable.newFrom({"Platform_edges": gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects = Hashtable.newFrom({"Platform_that_get_destroyed": gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595JumpThroughObjects3Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595MovingObjects3Objects = Hashtable.newFrom({"Platform_Moving": gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.ThankyouforplayingCode.GDSpikeObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.ThankyouforplayingCode.GDSpike2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.ThankyouforplayingCode.GDSpike3Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.ThankyouforplayingCode.GDSpike4Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDVirus_95952Objects3Objects = Hashtable.newFrom({"Virus_2": gdjs.ThankyouforplayingCode.GDVirus_952Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDVirus_95952_9595WallObjects3Objects = Hashtable.newFrom({"Virus_2_Wall": gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDVirus_95952_9595FlippedObjects3Objects = Hashtable.newFrom({"Virus_2_Flipped": gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3});
gdjs.ThankyouforplayingCode.asyncCallback9078052 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Virus_2"), gdjs.ThankyouforplayingCode.GDVirus_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Flipped"), gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Virus_2_Wall"), gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952Objects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952Objects3[i].returnVariable(gdjs.ThankyouforplayingCode.GDVirus_952Objects3[i].getVariables().get("HP")).sub(1);
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3[i].returnVariable(gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3[i].getVariables().get("HP")).sub(1);
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3[i].returnVariable(gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3[i].getVariables().get("HP")).sub(1);
}
}}
gdjs.ThankyouforplayingCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDVirus_952Objects2) asyncObjectsList.addObject("Virus_2", obj);
for (const obj of gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2) asyncObjectsList.addObject("Virus_2_Flipped", obj);
for (const obj of gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2) asyncObjectsList.addObject("Virus_2_Wall", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback9078052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2});
gdjs.ThankyouforplayingCode.asyncCallback9078892 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Tutorial_Boss"), gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3[i].returnVariable(gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}}
gdjs.ThankyouforplayingCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2) asyncObjectsList.addObject("Tutorial_Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback9078892(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBossObjects2Objects = Hashtable.newFrom({"Boss": gdjs.ThankyouforplayingCode.GDBossObjects2});
gdjs.ThankyouforplayingCode.asyncCallback11461588 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Boss"), gdjs.ThankyouforplayingCode.GDBossObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBossObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBossObjects3[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBossObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBossObjects3[i].returnVariable(gdjs.ThankyouforplayingCode.GDBossObjects3[i].getVariables().getFromIndex(1)).sub(1);
}
}}
gdjs.ThankyouforplayingCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDBossObjects2) asyncObjectsList.addObject("Boss", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback11461588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDVirus_95952Objects2ObjectsGDgdjs_46ThankyouforplayingCode_46GDVirus_95952_9595WallObjects2ObjectsGDgdjs_46ThankyouforplayingCode_46GDVirus_95952_9595FlippedObjects2Objects = Hashtable.newFrom({"Virus_2": gdjs.ThankyouforplayingCode.GDVirus_952Objects2, "Virus_2_Wall": gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2, "Virus_2_Flipped": gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ThankyouforplayingCode.GDBulletObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2});
gdjs.ThankyouforplayingCode.asyncCallback16651404 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[i].deleteFromScene(runtimeScene);
}
}}
gdjs.ThankyouforplayingCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback16651404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.ThankyouforplayingCode.GDSpikeObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.ThankyouforplayingCode.GDSpike2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.ThankyouforplayingCode.GDSpike3Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.ThankyouforplayingCode.GDSpike4Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.ThankyouforplayingCode.GDSpikeObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.ThankyouforplayingCode.GDSpike2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.ThankyouforplayingCode.GDSpike3Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.ThankyouforplayingCode.GDSpike4Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.ThankyouforplayingCode.GDSpikeObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.ThankyouforplayingCode.GDSpike2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.ThankyouforplayingCode.GDSpike3Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.ThankyouforplayingCode.GDSpike4Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.asyncCallback16614740 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.ThankyouforplayingCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback16614740(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects = Hashtable.newFrom({"Bullet_Enemy": gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_2": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_3": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.asyncCallback16768372 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.ThankyouforplayingCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback16768372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects3Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBossObjects3Objects = Hashtable.newFrom({"Boss": gdjs.ThankyouforplayingCode.GDBossObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.asyncCallback16707164 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.ThankyouforplayingCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback16707164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatformObjects3Objects = Hashtable.newFrom({"Platform": gdjs.ThankyouforplayingCode.GDPlatformObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595DoorObjects3Objects = Hashtable.newFrom({"Platform_Door": gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595Door2Objects3Objects = Hashtable.newFrom({"Platform_Door2": gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595edgesObjects3Objects = Hashtable.newFrom({"Platform_edges": gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects = Hashtable.newFrom({"Platform_that_get_destroyed": gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595JumpThroughObjects3Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595MovingObjects3Objects = Hashtable.newFrom({"Platform_Moving": gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.ThankyouforplayingCode.GDSpikeObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.ThankyouforplayingCode.GDSpike2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.ThankyouforplayingCode.GDSpike3Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.ThankyouforplayingCode.GDSpike4Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.asyncCallback16728924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.ThankyouforplayingCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback16728924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects2Objects = Hashtable.newFrom({"Bullet_Enemy_1": gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.asyncCallback16716612 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.ThankyouforplayingCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback16716612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.asyncCallback16603620 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects3[i].setColor("173;173;173");
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.ThankyouforplayingCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDTimerObjects2) asyncObjectsList.addObject("Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback16603620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects2Objects = Hashtable.newFrom({"Tutorial_Boss": gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.asyncCallback16648548 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects3);

{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects3.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects3[i].setColor("255;255;255");
}
}}
gdjs.ThankyouforplayingCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ThankyouforplayingCode.GDShield_95CountObjects2) asyncObjectsList.addObject("Shield_Count", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback16648548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITIONObjects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION2Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION2": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION3Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION3": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION4Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION4": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION5Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION5": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION6Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION6": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION7Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION7": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION8Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION8": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION9Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION9": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION10Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION10": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION11Objects2Objects = Hashtable.newFrom({"CAMERA_TRANSITION11": gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595JumpThroughObjects2Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595JumpThroughObjects2Objects = Hashtable.newFrom({"Platform_JumpThrough": gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDDustObjects2Objects = Hashtable.newFrom({"Dust": gdjs.ThankyouforplayingCode.GDDustObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects = Hashtable.newFrom({"Text_Game_Over_Play_again": gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDText_9595Game_9595Over_9595Play_9595againObjects1Objects = Hashtable.newFrom({"Text_Game_Over_Play_again": gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects1});
gdjs.ThankyouforplayingCode.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Down_Control"), gdjs.ThankyouforplayingCode.GDDown_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("F_Control"), gdjs.ThankyouforplayingCode.GDF_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("G_Control"), gdjs.ThankyouforplayingCode.GDG_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Left_Control"), gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Right_Control"), gdjs.ThankyouforplayingCode.GDRight_95ControlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Space_Control"), gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDG_95ControlObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDG_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDF_95ControlObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDF_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDown_95ControlObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDown_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDRight_95ControlObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDRight_95ControlObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.ThankyouforplayingCode.GDBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.ThankyouforplayingCode.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.ThankyouforplayingCode.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.ThankyouforplayingCode.GDHealth_95barObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block"), gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block2"), gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block3"), gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block4"), gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block5"), gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block6"), gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Move_To_Block7"), gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("TV_TUBE"), gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBackgroundObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBackgroundObjects2[i].setYOffset(gdjs.ThankyouforplayingCode.GDBackgroundObjects2[i].getYOffset() + (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects2[i].setYOffset(gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects2[i].getYOffset() + (-(50) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2[i].setXOffset(gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2[i].getXOffset() + (-(50) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBulletObjects2[i].setHeight(64);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBulletObjects2[i].setWidth(64);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setHeight(64);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setWidth(64);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects2[i].setPosition((( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[0].getPointX("Count")),(( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[0].getPointY("Count")));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDHealth_95barObjects2[i].setPosition((( gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2[0].getPointX("Health_Bar")),(( gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2[0].getPointY("Health_Bar")));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration14Objects2[i].setOpacity(150);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration15Objects2[i].setOpacity(150);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2[i].setOpacity(190);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2[i].setOpacity(190);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2[i].setScale(3);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2[i].setScale(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2[i].setScale(2.5);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2[i].setScale(3.4);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects2[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Game_Over"), gdjs.ThankyouforplayingCode.GDGame_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.ThankyouforplayingCode.GDHealth_95barObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.ThankyouforplayingCode.GDPortalObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again2"), gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects2);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPortalObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDGame_95OverObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPortalObjects2[i].setScale(0);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDHealth_95barObjects2[i].setOpacity(90);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].setOpacity(50);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.ThankyouforplayingCode.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952Objects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i].isCurrentAnimationName("Virus_Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.ThankyouforplayingCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Decoration"), gdjs.ThankyouforplayingCode.GDDecorationObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration1"), gdjs.ThankyouforplayingCode.GDDecoration1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration10"), gdjs.ThankyouforplayingCode.GDDecoration10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration11"), gdjs.ThankyouforplayingCode.GDDecoration11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration12"), gdjs.ThankyouforplayingCode.GDDecoration12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration13"), gdjs.ThankyouforplayingCode.GDDecoration13Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.ThankyouforplayingCode.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.ThankyouforplayingCode.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration16"), gdjs.ThankyouforplayingCode.GDDecoration16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration17"), gdjs.ThankyouforplayingCode.GDDecoration17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration18"), gdjs.ThankyouforplayingCode.GDDecoration18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration19"), gdjs.ThankyouforplayingCode.GDDecoration19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration2"), gdjs.ThankyouforplayingCode.GDDecoration2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration20"), gdjs.ThankyouforplayingCode.GDDecoration20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration22"), gdjs.ThankyouforplayingCode.GDDecoration22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration24"), gdjs.ThankyouforplayingCode.GDDecoration24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration25"), gdjs.ThankyouforplayingCode.GDDecoration25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration28"), gdjs.ThankyouforplayingCode.GDDecoration28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration3"), gdjs.ThankyouforplayingCode.GDDecoration3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration4"), gdjs.ThankyouforplayingCode.GDDecoration4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration5"), gdjs.ThankyouforplayingCode.GDDecoration5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration6"), gdjs.ThankyouforplayingCode.GDDecoration6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration7"), gdjs.ThankyouforplayingCode.GDDecoration7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration8"), gdjs.ThankyouforplayingCode.GDDecoration8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration9"), gdjs.ThankyouforplayingCode.GDDecoration9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Fan"), gdjs.ThankyouforplayingCode.GDFanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.ThankyouforplayingCode.GDPlatformObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatformObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatformObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2[i].setColor("37;37;37");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecorationObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecorationObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration1Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration1Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration2Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration2Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration3Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration3Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration4Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration4Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration5Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration5Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration6Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration6Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration7Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration7Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration8Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration8Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration9Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration9Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration10Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration10Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration11Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration11Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration12Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration12Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration13Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration13Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration14Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration15Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration16Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration16Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration17Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration17Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration18Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration18Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration19Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration19Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration20Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration20Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration22Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration22Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration24Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration24Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration25Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration25Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration28Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration28Objects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDFanObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDFanObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2[i].setColor("255;255;255");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9319612);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.ThankyouforplayingCode.GDLeftObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDLeftObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDLeftObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10188980);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.ThankyouforplayingCode.GDLeftObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDLeftObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10162100);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.ThankyouforplayingCode.GDRightObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDRightObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDRightObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10191852);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.ThankyouforplayingCode.GDRightObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDRightObjects2[i].setAnimationName("Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16727340);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16530996);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8189164);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11185012);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15317900);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "g"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11509604);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15265188);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "f"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14500332);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.ThankyouforplayingCode.GDterminalObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.ThankyouforplayingCode.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDterminalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminalObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminalObjects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDterminalObjects2[k] = gdjs.ThankyouforplayingCode.GDterminalObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminalObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminal4Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDterminal4Objects2[k] = gdjs.ThankyouforplayingCode.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminal4Objects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9325508);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.ThankyouforplayingCode.GDPortalObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDterminalObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPortalObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPortalObjects2[i].getBehavior("Tween").addObjectScaleTween("Portal", 4, 4, "bouncePast", 800, false, true);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPortalObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPortalObjects2[i].setAnimationName("Portal");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDterminalObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDterminalObjects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.ThankyouforplayingCode.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDterminal4Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminal4Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDterminal4Objects2[k] = gdjs.ThankyouforplayingCode.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminal4Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16771180);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDterminal4Objects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDterminal4Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDterminal4Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(10);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.ThankyouforplayingCode.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDterminal3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminal3Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDterminal3Objects2[k] = gdjs.ThankyouforplayingCode.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminal3Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16690164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDterminal3Objects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDterminal3Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDterminal3Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.ThankyouforplayingCode.GDterminal5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDterminal5Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminal5Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminal5Objects2[i].isCurrentAnimationName("Terminal Off") ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDterminal5Objects2[k] = gdjs.ThankyouforplayingCode.GDterminal5Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminal5Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16734308);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDterminal5Objects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDterminal5Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDterminal5Objects2[i].setAnimationName("Terminal On");
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16757380);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Jump.mp3", false, 50, gdjs.randomFloatInRange(0.8, 1.2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16766460);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getAnimationFrame() == 2 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16574668);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getAnimationFrame() == 4 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9330556);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Walk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTime_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16668596);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDShield_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16654636);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16732308);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Pick_Up.wav", false, 50, 1);
}}

}


{

gdjs.ThankyouforplayingCode.GDDeathObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpikeObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike3Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.ThankyouforplayingCode.GDDeathObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.ThankyouforplayingCode.GDDeathObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDDeathObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDDeathObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDDeathObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDDeathObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDDeathObjects2_1final.push(gdjs.ThankyouforplayingCode.GDDeathObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.ThankyouforplayingCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.push(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.ThankyouforplayingCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.ThankyouforplayingCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.ThankyouforplayingCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDDeathObjects2_1final, gdjs.ThankyouforplayingCode.GDDeathObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final, gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final, gdjs.ThankyouforplayingCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16624556);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 100, 0.8);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.ThankyouforplayingCode.GDterminalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminalObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminalObjects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDterminalObjects2[k] = gdjs.ThankyouforplayingCode.GDterminalObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminalObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9059140);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.5, 0.7));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.ThankyouforplayingCode.GDterminal5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminal5Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminal5Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDterminal5Objects2[k] = gdjs.ThankyouforplayingCode.GDterminal5Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminal5Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9075196);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.9, 1.1));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.ThankyouforplayingCode.GDterminal3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminal3Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminal3Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDterminal3Objects2[k] = gdjs.ThankyouforplayingCode.GDterminal3Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminal3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16689004);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.9, 1.1));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.ThankyouforplayingCode.GDterminal4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDterminal4Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDterminal4Objects2[i].isCurrentAnimationName("Terminal On") ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDterminal4Objects2[k] = gdjs.ThankyouforplayingCode.GDterminal4Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDterminal4Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16728652);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Turn ON.wav", false, 100, gdjs.randomFloatInRange(0.75, 0.95));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Shoot") > 1.3;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].isFlippedX()) ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9080164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, gdjs.randomFloatInRange(1.2, 1.5));
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getPointX("Shoot")), (gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getPointY("Shoot")), gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects, 0, 900, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EffectObjects2Objects, (( gdjs.ThankyouforplayingCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDPlayerObjects2[0].getPointX("Shoot")), (( gdjs.ThankyouforplayingCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDPlayerObjects2[0].getPointY("Shoot")), "");
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Shoot") > 1.5;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].isFlippedX() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16593300);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Bullet.mp3", false, 50, gdjs.randomFloatInRange(1.2, 1.5));
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getPointX("Shoot")), (gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getPointY("Shoot")), gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects, -(180), 900, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EffectObjects2Objects, (( gdjs.ThankyouforplayingCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDPlayerObjects2[0].getPointX("Shoot")), (( gdjs.ThankyouforplayingCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDPlayerObjects2[0].getPointY("Shoot")), "");
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Shoot");
}}

}


{

gdjs.ThankyouforplayingCode.GDBulletObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatformObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpikeObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike3Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.ThankyouforplayingCode.GDPlatformObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatformObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatformObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatformObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatformObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595DoorObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595Door2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595edgesObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595JumpThroughObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595MovingObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.ThankyouforplayingCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.push(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.ThankyouforplayingCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.ThankyouforplayingCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.ThankyouforplayingCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBulletObjects2_1final, gdjs.ThankyouforplayingCode.GDBulletObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatformObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final, gdjs.ThankyouforplayingCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.ThankyouforplayingCode.GDBulletObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.ThankyouforplayingCode.GDVirus_952Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDVirus_95952Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDVirus_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDVirus_952Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDVirus_952Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDVirus_952Objects2_1final.push(gdjs.ThankyouforplayingCode.GDVirus_952Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDVirus_95952_9595WallObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2_1final.push(gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDVirus_95952_9595FlippedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBulletObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2_1final.push(gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBulletObjects2_1final, gdjs.ThankyouforplayingCode.GDBulletObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDVirus_952Objects2_1final, gdjs.ThankyouforplayingCode.GDVirus_952Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2_1final, gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2_1final, gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDVirus_952Objects2 */
/* Reuse gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2 */
/* Reuse gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i].setAnimationName("Virus_Hurt");
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i].setAnimationName("Virus_Hurt");
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i].setAnimationName("Virus_Hurt");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.ThankyouforplayingCode.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952Objects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i].getVariables().get("HP")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16736388);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDVirus_952Objects2 */
/* Reuse gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2 */
/* Reuse gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
for(var i = 0, len = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i].getBehavior("Tween").addObjectOpacityTween("Death", 0, "linear", 700, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16710324);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.ThankyouforplayingCode.GDBossObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16718084);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBossObjects2 */
/* Reuse gdjs.ThankyouforplayingCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBossObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBossObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBossObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBossObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2"), gdjs.ThankyouforplayingCode.GDVirus_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Flipped"), gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Virus_2_Wall"), gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDVirus_95952Objects2ObjectsGDgdjs_46ThankyouforplayingCode_46GDVirus_95952_9595WallObjects2ObjectsGDgdjs_46ThankyouforplayingCode_46GDVirus_95952_9595FlippedObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952Objects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952Objects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[k] = gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16619092);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBulletObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16761372);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.ThankyouforplayingCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpikeObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike3Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.ThankyouforplayingCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.push(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.ThankyouforplayingCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.ThankyouforplayingCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.ThankyouforplayingCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_1final, gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final, gdjs.ThankyouforplayingCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpikeObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike3Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.ThankyouforplayingCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.push(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.ThankyouforplayingCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.ThankyouforplayingCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.ThankyouforplayingCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_1final, gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final, gdjs.ThankyouforplayingCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpikeObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike3Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.ThankyouforplayingCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.push(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.ThankyouforplayingCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.ThankyouforplayingCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.ThankyouforplayingCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_1final, gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final, gdjs.ThankyouforplayingCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final.length = 0;
gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final.push(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final, gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final, gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final, gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final, gdjs.ThankyouforplayingCode.GDPlayerObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16632212);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2);
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final.length = 0;
gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595EnemyObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final.push(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_2"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95952Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_3"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95953Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2_2final, gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2_2final, gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2_2final, gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final, gdjs.ThankyouforplayingCode.GDPlayerObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16768236);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.ThankyouforplayingCode.GDBossObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.ThankyouforplayingCode.GDBossObjects2_2final.length = 0;
gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.length = 0;
gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2_2final.push(gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.ThankyouforplayingCode.GDBossObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBossObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBossObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBossObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDBossObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBossObjects2_2final.push(gdjs.ThankyouforplayingCode.GDBossObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBossObjects2_2final, gdjs.ThankyouforplayingCode.GDBossObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlayerObjects2_2final, gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2_2final, gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16719964);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy"), gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatformObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpikeObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike3Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.ThankyouforplayingCode.GDPlatformObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatformObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatformObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatformObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatformObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595DoorObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595Door2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595edgesObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595that_9595get_9595destroyedObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595JumpThroughObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595MovingObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.ThankyouforplayingCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.push(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.ThankyouforplayingCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.ThankyouforplayingCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.ThankyouforplayingCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final.push(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2_1final, gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatformObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatformObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2_1final, gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final, gdjs.ThankyouforplayingCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16596308);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2 */
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBullet_9595Enemy_95951Objects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16728780);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16743996);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].setColor("255;0;0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().get("Secs").sub(5);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.2);
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_Boss"), gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTutorial_9595BossObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16735132);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet_Enemy_1"), gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects2[i].setColor("255;0;0");
}
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.ThankyouforplayingCode.GDBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration"), gdjs.ThankyouforplayingCode.GDDecorationObjects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration1"), gdjs.ThankyouforplayingCode.GDDecoration1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration10"), gdjs.ThankyouforplayingCode.GDDecoration10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration11"), gdjs.ThankyouforplayingCode.GDDecoration11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration12"), gdjs.ThankyouforplayingCode.GDDecoration12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration14"), gdjs.ThankyouforplayingCode.GDDecoration14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration15"), gdjs.ThankyouforplayingCode.GDDecoration15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration16"), gdjs.ThankyouforplayingCode.GDDecoration16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration17"), gdjs.ThankyouforplayingCode.GDDecoration17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration18"), gdjs.ThankyouforplayingCode.GDDecoration18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration19"), gdjs.ThankyouforplayingCode.GDDecoration19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration2"), gdjs.ThankyouforplayingCode.GDDecoration2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration20"), gdjs.ThankyouforplayingCode.GDDecoration20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration22"), gdjs.ThankyouforplayingCode.GDDecoration22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration24"), gdjs.ThankyouforplayingCode.GDDecoration24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration25"), gdjs.ThankyouforplayingCode.GDDecoration25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration28"), gdjs.ThankyouforplayingCode.GDDecoration28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration3"), gdjs.ThankyouforplayingCode.GDDecoration3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration4"), gdjs.ThankyouforplayingCode.GDDecoration4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration5"), gdjs.ThankyouforplayingCode.GDDecoration5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration6"), gdjs.ThankyouforplayingCode.GDDecoration6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration7"), gdjs.ThankyouforplayingCode.GDDecoration7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Decoration9"), gdjs.ThankyouforplayingCode.GDDecoration9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Falling_Wall"), gdjs.ThankyouforplayingCode.GDFalling_95WallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Falling_Wall_Chain"), gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects2);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.ThankyouforplayingCode.GDLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.ThankyouforplayingCode.GDPlatformObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Boss"), gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door"), gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Door2"), gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_Moving"), gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_edges"), gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Platform_that_get_destroyed"), gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.ThankyouforplayingCode.GDRightObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.ThankyouforplayingCode.GDSpikeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.ThankyouforplayingCode.GDSpike2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.ThankyouforplayingCode.GDSpike3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.ThankyouforplayingCode.GDSpike4Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal"), gdjs.ThankyouforplayingCode.GDterminalObjects2);
gdjs.copyArray(runtimeScene.getObjects("terminal3"), gdjs.ThankyouforplayingCode.GDterminal3Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal4"), gdjs.ThankyouforplayingCode.GDterminal4Objects2);
gdjs.copyArray(runtimeScene.getObjects("terminal5"), gdjs.ThankyouforplayingCode.GDterminal5Objects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatformObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatformObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDFalling_95WallObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDFalling_95WallObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDSpikeObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDSpikeObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDSpike2Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDSpike2Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDSpike3Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDSpike3Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDSpike4Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDSpike4Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBackgroundObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBackgroundObjects2[i].setZOrder(-(20));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecorationObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecorationObjects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration1Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration1Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration3Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration3Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration2Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration2Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration4Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration4Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration5Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration5Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration6Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration6Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration7Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration7Objects2[i].setZOrder(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration9Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration9Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration10Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration10Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration11Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration11Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration12Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration12Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration14Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration14Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration15Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration15Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration16Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration16Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration17Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration17Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration18Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration18Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration19Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration19Objects2[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration20Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration20Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration22Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration22Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration24Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration24Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration25Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration25Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDecoration28Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDecoration28Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDLeftObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDRightObjects2[i].setZOrder(-(1));
}
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDterminalObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDterminalObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDterminal5Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDterminal5Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDterminal3Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDterminal3Objects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDterminal4Objects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDterminal4Objects2[i].setZOrder(-(1));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITIONObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION2"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION3"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION4"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION4Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION5"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION5Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION6"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION6Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION7"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION7Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION8"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION8Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION9"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION9Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION10"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION10Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects2[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CAMERA_TRANSITION11"), gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDCAMERA_9595TRANSITION11Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects2 */
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects2.length !== 0 ? gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects2[0] : null), true, "", 0);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595JumpThroughObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16733588);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2[i].setOpacity(150);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_JumpThrough"), gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlatform_9595JumpThroughObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9064508);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2[i].setOpacity(255);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Walk - No Weapon");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Walk - No Weapon");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Grab");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isGrabbingPlatform() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16585812);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Grab");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16665284);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16703012);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16646340);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Idle - No Weapon");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Walk - Pistol");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Walk - Pistol");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Jump - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16770316);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16711660);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16684820);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_1 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16715956);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].setAnimationName("Idle - Pistol");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16716260);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
gdjs.ThankyouforplayingCode.GDDustObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDDustObjects2Objects, (( gdjs.ThankyouforplayingCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDPlayerObjects2[0].getPointX("Dust")), (( gdjs.ThankyouforplayingCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDPlayerObjects2[0].getPointY("Dust")), "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDPlayerObjects2[k] = gdjs.ThankyouforplayingCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16691372);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.ThankyouforplayingCode.GDDustObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDustObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDustObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ThankyouforplayingCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet_Effect"), gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.ThankyouforplayingCode.GDDustObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDDustObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDDustObjects2[i].setPosition((( gdjs.ThankyouforplayingCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDPlayerObjects2[0].getPointX("Dust")),(( gdjs.ThankyouforplayingCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDPlayerObjects2[0].getPointY("Dust")));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2[i].setPosition((( gdjs.ThankyouforplayingCode.GDBulletObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDBulletObjects2[0].getCenterXInScene()),(( gdjs.ThankyouforplayingCode.GDBulletObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDBulletObjects2[0].getCenterYInScene()));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16748668);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.ThankyouforplayingCode.GDCursorObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDCursorObjects2[i].setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDCursorObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16617756);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.ThankyouforplayingCode.GDCursorObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDCursorObjects2[i].setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDText_9595Game_9595Over_9595Play_9595againObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11595292);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2[i].setColor("163;163;163");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDText_9595Game_9595Over_9595Play_9595againObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9063012);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects1 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects1.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects1[i].setColor("255;255;255");
}
}}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDDeathObjects3Objects = Hashtable.newFrom({"Death": gdjs.ThankyouforplayingCode.GDDeathObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects = Hashtable.newFrom({"Spike": gdjs.ThankyouforplayingCode.GDSpikeObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects = Hashtable.newFrom({"Spike2": gdjs.ThankyouforplayingCode.GDSpike2Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects = Hashtable.newFrom({"Spike3": gdjs.ThankyouforplayingCode.GDSpike3Objects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects3});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects = Hashtable.newFrom({"Spike4": gdjs.ThankyouforplayingCode.GDSpike4Objects3});
gdjs.ThankyouforplayingCode.asyncCallback9082204 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}
gdjs.ThankyouforplayingCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback9082204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTime_9595CapsuleObjects2Objects = Hashtable.newFrom({"Time_Capsule": gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ThankyouforplayingCode.GDPlayerObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDShield_9595CapsuleObjects2Objects = Hashtable.newFrom({"Shield_Capsule": gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2});
gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDShield_9595CountObjects2Objects = Hashtable.newFrom({"Shield_Count": gdjs.ThankyouforplayingCode.GDShield_95CountObjects2});
gdjs.ThankyouforplayingCode.eventsList14 = function(runtimeScene) {

{



}


{



}


{



}


{



}


{



}


{



}


{

gdjs.ThankyouforplayingCode.GDDeathObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpikeObjects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike2Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike3Objects2.length = 0;

gdjs.ThankyouforplayingCode.GDSpike4Objects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.ThankyouforplayingCode.GDDeathObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.ThankyouforplayingCode.GDDeathObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDDeathObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDDeathObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDDeathObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDDeathObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDDeathObjects2_1final.push(gdjs.ThankyouforplayingCode.GDDeathObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.ThankyouforplayingCode.GDSpikeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpikeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpikeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final.push(gdjs.ThankyouforplayingCode.GDSpikeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike2"), gdjs.ThankyouforplayingCode.GDSpike2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike3"), gdjs.ThankyouforplayingCode.GDSpike3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spike4"), gdjs.ThankyouforplayingCode.GDSpike4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects3Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDSpike4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final.push(gdjs.ThankyouforplayingCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.ThankyouforplayingCode.GDSpike4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.indexOf(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]) === -1 )
            gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final.push(gdjs.ThankyouforplayingCode.GDSpike4Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDDeathObjects2_1final, gdjs.ThankyouforplayingCode.GDDeathObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDPlayerObjects2_1final, gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpikeObjects2_1final, gdjs.ThankyouforplayingCode.GDSpikeObjects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike2Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike2Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike3Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike3Objects2);
gdjs.copyArray(gdjs.ThankyouforplayingCode.GDSpike4Objects2_1final, gdjs.ThankyouforplayingCode.GDSpike4Objects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.ThankyouforplayingCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over"), gdjs.ThankyouforplayingCode.GDGame_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Game_Over_BG"), gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2);
gdjs.copyArray(runtimeScene.getObjects("Health_bar"), gdjs.ThankyouforplayingCode.GDHealth_95barObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over"), gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Text_Game_Over_Play_again"), gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.ThankyouforplayingCode.GDTimerObjects2);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDGame_95OverObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTimerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDHealth_95barObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDHealth_95barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDGame_95OverObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDGame_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDCursorObjects2[i].hide(false);
}
}{gdjs.evtTools.input.showCursor(runtimeScene);
}
{ //Subevents
gdjs.ThankyouforplayingCode.eventsList13(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Time_Capsule"), gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDTime_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16591244);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2 */
{runtimeScene.getScene().getVariables().get("Secs").add(5);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shield_Capsule"), gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDPlayerObjects2Objects, gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDShield_9595CapsuleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16742068);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);
gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDShield_9595CountObjects2Objects, (( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[0].getPointX("Count")), (( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length === 0 ) ? 0 :gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[0].getPointY("Count")), "UI");
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getBehavior("Tween").addObjectOpacityTween("Show", 255, "linear", 1500, false);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 2.5, 2.5, 2.5, 2.5, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].returnVariable(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[0].getVariables()).getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield_Skill"), gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length;i<l;++i) {
    if ( gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariableNumber(gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[k] = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i];
        ++k;
    }
}
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shield_Count"), gdjs.ThankyouforplayingCode.GDShield_95CountObjects2);
/* Reuse gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2 */
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95CountObjects2[i].setString("0");
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2[i].setOpacity(50);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9081452);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}{/* Unknown object - skipped. */}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ThankyouforplayingCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDPlayerObjects1[i].returnVariable(gdjs.ThankyouforplayingCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs.ThankyouforplayingCode.GDBackObjects1});
gdjs.ThankyouforplayingCode.asyncCallback8119556 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main menu", false);
}}
gdjs.ThankyouforplayingCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.ThankyouforplayingCode.asyncCallback8119556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ThankyouforplayingCode.eventsList16 = function(runtimeScene) {

{



}


{


gdjs.ThankyouforplayingCode.eventsList12(runtimeScene);
}


{


gdjs.ThankyouforplayingCode.eventsList14(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.ThankyouforplayingCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("TV_TUBE"), gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects1);
{gdjs.evtTools.input.showCursor(runtimeScene);
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDBackgroundObjects1[i].setYOffset(gdjs.ThankyouforplayingCode.GDBackgroundObjects1[i].getYOffset() + (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects1.length ;i < len;++i) {
    gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects1[i].setYOffset(gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects1[i].getYOffset() + (-(50) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.ThankyouforplayingCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ThankyouforplayingCode.mapOfGDgdjs_46ThankyouforplayingCode_46GDBackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.ThankyouforplayingCode.eventsList15(runtimeScene);} //End of subevents
}

}


};

gdjs.ThankyouforplayingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ThankyouforplayingCode.GDCursorObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDCursorObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDCursorObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDBackgroundObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDBackgroundObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDBackgroundObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDFanObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDFanObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDFanObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecorationObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecorationObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecorationObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration2Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration2Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration2Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration1Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration1Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration1Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration3Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration3Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration3Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration4Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration4Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration4Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration5Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration5Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration5Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration6Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration6Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration6Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration7Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration7Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration7Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration8Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration8Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration8Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration9Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration9Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration9Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration10Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration10Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration10Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration11Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration11Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration11Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration12Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration12Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration12Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration13Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration13Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration13Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration14Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration14Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration14Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration15Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration15Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration15Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration16Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration16Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration16Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration17Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration17Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration17Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration18Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration18Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration18Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration19Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration19Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration19Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration20Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration20Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration20Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration22Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration22Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration22Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration24Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration24Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration24Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration25Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration25Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration25Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration28Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration28Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDDecoration28Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDSpikeObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDSpike2Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDSpike3Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDSpike4Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDTV_95TUBEObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPortalObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPortalObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPortalObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlayerObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlayerObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlayerObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDDustObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDDustObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDDustObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95EffectObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITIONObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION2Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION3Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION4Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION5Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION6Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION7Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION8Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION9Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION10Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION11Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION12Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION12Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDCAMERA_95TRANSITION12Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDterminalObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDterminalObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDterminalObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDterminal5Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDterminal5Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDterminal5Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDterminal3Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDterminal3Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDterminal3Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDterminal4Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDterminal4Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDterminal4Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDGame_95OverObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDGame_95OverObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDGame_95OverObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlatformObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlatformObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlatformObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95BossObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95DoorObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95Door2Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95that_95get_95destroyedObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95JumpThroughObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95MovingObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDPlatform_95edgesObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDGame_95Over_95BGObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDDeathObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDDeathObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDDeathObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95OverObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95againObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDText_95Game_95Over_95Play_95again2Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDTimerObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDTimerObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDTimerObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95CountObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95CountObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95CountObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95CapsuleObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDTime_95CapsuleObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDLeftObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDLeftObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDLeftObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDRightObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDRightObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDRightObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDLeft_95ControlObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDRight_95ControlObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDRight_95ControlObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDRight_95ControlObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95EnemyObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_952Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_953Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDBullet_95Enemy_951Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDBulletObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDBulletObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDBulletObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDHealth_95barObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDHealth_95barObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDHealth_95barObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDG_95ControlObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDG_95ControlObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDG_95ControlObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDF_95ControlObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDF_95ControlObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDF_95ControlObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDDown_95ControlObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDDown_95ControlObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDDown_95ControlObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDSpace_95ControlObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDShield_95SkillObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95BlockObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block2Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block3Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block4Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block5Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block6Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDMove_95To_95Block7Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952_95WallObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDVirus_952_95FlippedObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95FromObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95FromObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95FromObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95From2Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95From2Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95From2Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95From3Objects1.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95From3Objects2.length = 0;
gdjs.ThankyouforplayingCode.GDShoot_95From3Objects3.length = 0;
gdjs.ThankyouforplayingCode.GDFalling_95WallObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDFalling_95WallObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDFalling_95WallObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDFalling_95Wall_95ChainObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDBossObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDBossObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDBossObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDTutorial_95BossObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDNewTextObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDNewTextObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDNewTextObjects3.length = 0;
gdjs.ThankyouforplayingCode.GDBackObjects1.length = 0;
gdjs.ThankyouforplayingCode.GDBackObjects2.length = 0;
gdjs.ThankyouforplayingCode.GDBackObjects3.length = 0;

gdjs.ThankyouforplayingCode.eventsList16(runtimeScene);

return;

}

gdjs['ThankyouforplayingCode'] = gdjs.ThankyouforplayingCode;
